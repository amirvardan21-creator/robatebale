<?php

use SecretMeetingRoom;

class ChatController
{
    private Bale $bale;

    public function __construct(Bale $bale)
    {
        $this->bale = $bale;
    }

    public function showMatches(array $user): void
    {
        $chatId = (int) $user['bale_id'];
        if ($user['step'] === 'chatting') {
            User::updateStep($user['id'], 'idle');
        }
        $matches = MatchModel::getUserMatches($user['id']);

        if (empty($matches)) {
            $this->bale->sendMessage($chatId, "💔 هنوز مچی ندارید.\nبرای پیدا کردن دوست از منوی 🕶 استفاده کنید.", $this->bale->mainMenuKeyboard());
            return;
        }

        $buttons = [];
        foreach ($matches as $match) {
            $buttons[] = [['text' => "💬 {$match['partner_name']} ({$match['age']} ساله، {$match['city']})", 'callback_data' => 'chat_open_' . $match['id']]];
        }
        $this->bale->sendMessage($chatId, "💬 *گفتگوهای شما:*", $this->bale->inlineKeyboard($buttons));
    }

    public function startChatSession(array $user, int $partnerId): bool
    {
        $partner = User::findById($partnerId);
        if (!$partner) {
            return false;
        }

        $matchId = MatchModel::createMatch($user['id'], $partnerId);
        Database::execute('UPDATE matches SET is_active = 1 WHERE id = ?', [$matchId]);

        $partnerProfile = Profile::findByUserId($partnerId);
        $myProfile = Profile::findByUserId($user['id']);

        User::updateStep($user['id'], 'chatting', ['match_id' => $matchId, 'partner_id' => $partnerId]);
        User::updateStep($partnerId, 'chatting', ['match_id' => $matchId, 'partner_id' => $user['id']]);

        $myKeyboard = $this->bale->inlineKeyboard([[
            ['text' => '🚫 بلاک کردن', 'callback_data' => 'chat_block_' . $partnerId],
            ['text' => '🗑 حذف مچ', 'callback_data' => 'chat_delete_' . $matchId],
            ['text' => '🔙 بازگشت', 'callback_data' => 'chat_back'],
        ]]);

        $partnerKeyboard = $this->bale->inlineKeyboard([[
            ['text' => '🚫 بلاک کردن', 'callback_data' => 'chat_block_' . $user['id']],
            ['text' => '🗑 حذف مچ', 'callback_data' => 'chat_delete_' . $matchId],
            ['text' => '🔙 بازگشت', 'callback_data' => 'chat_back'],
        ]]);

        $this->bale->sendMessage(
            (int) $user['bale_id'],
            "✅ کاربری پیدا شد!\n\n💬 *گفتگو با {$partnerProfile['name']}*\n\nپیام خود را بنویسید:",
            $myKeyboard
        );
        $this->bale->sendMessage(
            (int) $partner['bale_id'],
            "✅ کاربری پیدا شد!\n\n💬 *گفتگو با {$myProfile['name']}*\n\nپیام خود را بنویسید:",
            $partnerKeyboard
        );

        return true;
    }

    public function openChat(array $user, string $callbackId, int $matchId): void
    {
        $chatId = (int) $user['bale_id'];
        $match = Database::fetch('SELECT * FROM matches WHERE id = ? AND (user1_id = ? OR user2_id = ?) AND is_active = 1', [$matchId, $user['id'], $user['id']]);

        if (!$match) {
            $this->bale->answerCallbackQuery($callbackId, '❌ این گفتگو یافت نشد.', true);
            return;
        }

        $partnerId = ($match['user1_id'] == $user['id']) ? $match['user2_id'] : $match['user1_id'];
        $partnerProfile = Profile::findByUserId($partnerId);

        User::updateStep($user['id'], 'chatting', ['match_id' => $matchId, 'partner_id' => $partnerId]);
        $this->bale->answerCallbackQuery($callbackId);

        $keyboard = $this->bale->inlineKeyboard([[
            ['text' => '🚫 بلاک کردن', 'callback_data' => 'chat_block_' . $partnerId],
            ['text' => '🗑 حذف مچ', 'callback_data' => 'chat_delete_' . $matchId],
            ['text' => '🔙 بازگشت', 'callback_data' => 'chat_back'],
        ]]);

        $this->bale->sendMessage(
            $chatId,
            "💬 *گفتگو با {$partnerProfile['name']}*\n\nپیام خود را بنویسید:",
            $keyboard
        );
    }

    public function sendChatMessage(array $user, string $text): void
    {
        $chatId = (int) $user['bale_id'];

        if ($text === '' || str_starts_with($text, '/')) {
            $this->bale->sendMessage($chatId, 'لطفاً یک پیام متنی بنویسید.');
            return;
        }

        $stepData = User::getStepData($user);

        // Determine if the user is in a secret meeting or a regular match
        $conversationType = null;
        $conversationId = null;
        $partnerId = null;

        if ($user['current_status'] === 'in_secret_meeting' && !empty($user['current_secret_meeting_room_id'])) {
            $room = SecretMeetingRoom::getRoomById($user['current_secret_meeting_room_id']);
            if ($room && $room['status'] === 'active') {
                $conversationType = 'secret_meeting';
                $conversationId = $room['id'];
                $partnerId = ($room['user1_id'] == $user['id']) ? $room['user2_id'] : $room['user1_id'];
            }
        } elseif ($stepData && !empty($stepData['match_id'])) { // Regular match
            $conversationType = 'match';
            $conversationId = $stepData['match_id'];
            $partnerId = $stepData['partner_id'];
        }

        if (!$conversationType || !$conversationId || !$partnerId) {
            User::updateStep($user['id'], 'idle');
            User::updateUserStatus($user['id'], 'idle');
            $this->bale->sendMessage($chatId, '❌ خطا در گفتگو. وضعیت چت نامشخص است.', $this->bale->mainMenuKeyboard());
            return;
        }

        if (BlockReport::isBlockedEither($user['id'], $partnerId)) {
            $this->bale->sendMessage($chatId, '🚫 امکان ارسال پیام وجود ندارد.', $this->bale->mainMenuKeyboard());
            User::updateStep($user['id'], 'idle');
            User::updateUserStatus($user['id'], 'idle');
            return;
        }

        $partnerUser = User::findById($partnerId);
        if (!$partnerUser) {
            User::updateStep($user['id'], 'idle');
            User::updateUserStatus($user['id'], 'idle');
            $this->bale->sendMessage($chatId, '❌ کاربر مقابل یافت نشد.', $this->bale->mainMenuKeyboard());
            return;
        }

        // Reject if partner is blocked
        if (User::isBlocked($partnerId)) {
            $this->bale->sendMessage($chatId, '🚫 کاربر مقابل در دسترس نیست.', $this->bale->mainMenuKeyboard());
            User::updateStep($user['id'], 'idle');
            User::updateUserStatus($user['id'], 'idle');
            return;
        }

        $myProfile = Profile::findByUserId($user['id']);

        // Save message using the new conversation_type and conversation_id
        MatchModel::saveMessage($conversationId, $user['id'], htmlspecialchars($text), 'text', $conversationType);

        // Auto-transition partner to chatting step if they are idle (fixes one-way chat bug)
        $this->ensurePartnerInChatStep($partnerUser, $user, $conversationType, $conversationId);

        // Build keyboard for partner based on conversation type
        if ($conversationType === 'secret_meeting') {
            $partnerKeyboard = $this->bale->secretMeetingChatKeyboard($user['id'], $conversationId);
        } else {
            $partnerKeyboard = $this->bale->inlineKeyboard([[
                ['text' => '🚫 بلاک کردن', 'callback_data' => 'chat_block_' . $user['id']],
                ['text' => '🗑 حذف مچ', 'callback_data' => 'chat_delete_' . $conversationId],
                ['text' => '🔙 بازگشت', 'callback_data' => 'chat_back'],
            ]]);
        }

        // پیام خالی و بدون پیشوند به کاربر مقابل ارسال می‌شود
        // تا مکالمه طبیعی و بی‌وقفه باشد (مثل چت معمولی Bale).
        $this->bale->sendMessage(
            (int) $partnerUser['bale_id'],
            $text,
            $partnerKeyboard
        );
    }

    /**
     * اگر طرف مقابل idle هست و پیامی براش میاد، اتوماتیک step او را به chatting تنظیم کن
     * تا بتونه جواب بده (فیکس باگ چت یک‌طرفه)
     */
    private function ensurePartnerInChatStep(array $partner, array $sender, string $conversationType, int $conversationId): void
    {
        // فقط اگر partner در حالت idle است یا در حالت دیگری که گفتگو را متوقف می‌کند، transition کن
        $partnerStep = $partner['step'] ?? 'idle';
        $interruptible = in_array($partnerStep, ['idle', 'chatting'], true);

        // اگر در حال ثبت‌نام یا ویرایش پروفایل است، مزاحم نشو
        if (str_starts_with($partnerStep, 'register_') || str_starts_with($partnerStep, 'editing_')) {
            return;
        }

        if (!$interruptible) {
            return;
        }

        if ($conversationType === 'secret_meeting') {
            // partner باید در حالت in_secret_meeting باشد
            if (($partner['current_status'] ?? 'idle') !== 'in_secret_meeting') {
                User::updateUserStatus($partner['id'], 'in_secret_meeting', $conversationId);
            }
        } else {
            // regular match: ذخیره match_id و partner_id در step_data
            $existingStepData = User::getStepData($partner) ?? [];
            if (empty($existingStepData['match_id']) || (int)$existingStepData['match_id'] !== $conversationId) {
                User::updateStep($partner['id'], 'chatting', [
                    'match_id'   => $conversationId,
                    'partner_id' => $sender['id'],
                ]);
            } elseif ($partnerStep !== 'chatting') {
                User::updateStep($partner['id'], 'chatting', $existingStepData);
            }
        }
    }

    public function handleCallback(array $user, string $callbackId, string $data): void
    {
        $chatId = (int) $user['bale_id'];

        try {
            if (str_starts_with($data, 'chat_open_')) {
                $matchId = (int) substr($data, 10);
                $this->openChat($user, $callbackId, $matchId);
            } elseif (str_starts_with($data, 'chat_block_')) {
                $targetId = (int) substr($data, 11);
                BlockReport::block($user['id'], $targetId);
                User::updateStep($user['id'], 'idle');
                User::updateUserStatus($user['id'], 'idle');
                $this->bale->answerCallbackQuery($callbackId, '🚫 کاربر بلاک شد.', true);
                $this->bale->sendMessage($chatId, '🚫 کاربر بلاک شد.', $this->bale->mainMenuKeyboard());
            } elseif (str_starts_with($data, 'chat_delete_')) {
                $matchId = (int) substr($data, 12);
                MatchModel::deleteMatch($matchId, $user['id']);
                User::updateStep($user['id'], 'idle');
                User::updateUserStatus($user['id'], 'idle');
                $this->bale->answerCallbackQuery($callbackId, '🗑 مچ حذف شد.', true);
                $this->bale->sendMessage($chatId, '🗑 مچ حذف شد.', $this->bale->mainMenuKeyboard());
            } elseif ($data === 'chat_back') {
                User::updateStep($user['id'], 'idle');
                User::updateUserStatus($user['id'], 'idle');
                $this->bale->answerCallbackQuery($callbackId);
                $this->bale->sendMessage($chatId, 'بازگشت به منو.', $this->bale->mainMenuKeyboard());
            } elseif (str_starts_with($data, 'sm_view_profile_')) {
                $partnerId = (int) substr($data, 16);
                $this->handleViewProfile($user, $callbackId, $partnerId);
            } elseif (str_starts_with($data, 'sm_gift_')) {
                $partnerId = (int) substr($data, 8);
                $this->handleGiveGift($user, $callbackId, $partnerId);
            } elseif (str_starts_with($data, 'sm_end_chat_')) {
                $roomId = (int) substr($data, 12);
                $this->handleEndChat($user, $callbackId, $roomId);
            } elseif (str_starts_with($data, 'sm_delete_messages_')) {
                $roomId = (int) substr($data, 19);
                $this->handleDeleteMessages($user, $callbackId, $roomId);
            } elseif (str_starts_with($data, 'sm_report_user_')) {
                $partnerId = (int) substr($data, 15);
                $this->handleReportUser($user, $callbackId, $partnerId);
            } else {
                $this->bale->answerCallbackQuery($callbackId);
            }
        } catch (Throwable $e) {
            Logger::error('ChatController::handleCallback failed (user=' . $user['id'] . ', data=' . $data . '): ' . $e->getMessage()
                . ' in ' . $e->getFile() . ':' . $e->getLine()
                . "\nTrace: " . $e->getTraceAsString());
            try {
                $this->bale->answerCallbackQuery($callbackId, '❌ خطایی رخ داد.', true);
            } catch (Throwable) {}
            // اگر کاربر در چت فعال است، کیبورد چت را حفظ کن تا از چت خارج نشود
            $partnerId = 0;
            try {
                if (($user['current_status'] ?? 'idle') === 'in_secret_meeting'
                    && !empty($user['current_secret_meeting_room_id'])) {
                    $room = SecretMeetingRoom::getRoomById((int) $user['current_secret_meeting_room_id']);
                    if ($room && $room['status'] === 'active') {
                        $partnerId = ((int) $room['user1_id'] === (int) $user['id'])
                            ? (int) $room['user2_id']
                            : (int) $room['user1_id'];
                    }
                }
            } catch (Throwable $kbdErr) {
                Logger::error('ChatController::handleCallback: failed to resolve partner for error keyboard: ' . $kbdErr->getMessage());
            }
            try {
                $errorKeyboard = $this->resolveActiveChatKeyboard($user, $partnerId);
            } catch (Throwable $kbdErr) {
                Logger::error('ChatController::handleCallback: resolveActiveChatKeyboard failed: ' . $kbdErr->getMessage());
                $errorKeyboard = $this->bale->mainMenuKeyboard();
            }
            // این sendMessage هم در try-catch تا اگر خودش هم شکست خورد، تبدیل به err_ نشود
            try {
                $this->bale->sendMessage(
                    $chatId,
                    '❌ یک خطا رخ داد. لطفاً دوباره تلاش کنید.',
                    $errorKeyboard
                );
            } catch (Throwable $sendErr) {
                Logger::error('ChatController::handleCallback: failed to send error message to user ' . $user['id'] . ': ' . $sendErr->getMessage());
            }
        }
    }

    private function handleViewProfile(array $user, string $callbackId, int $partnerId): void
    {
        $chatId = (int) $user['bale_id'];
        Logger::info("handleViewProfile start: user={$user['id']}, partnerId=$partnerId, chatId=$chatId");

        // مرحله ۱: پیدا کردن partner
        try {
            $partner = User::findById($partnerId);
        } catch (Throwable $e) {
            Logger::error("handleViewProfile: User::findById($partnerId) threw: " . $e->getMessage());
            throw $e;
        }
        if (!$partner) {
            Logger::warning("handleViewProfile: partner $partnerId not found in users table");
            $this->bale->answerCallbackQuery($callbackId, '❌ کاربر یافت نشد.', true);
            return;
        }

        // مرحله ۲: پیدا کردن پروفایل partner
        try {
            $partnerProfile = Profile::findByUserId($partnerId);
        } catch (Throwable $e) {
            Logger::error("handleViewProfile: Profile::findByUserId($partnerId) threw: " . $e->getMessage());
            throw $e;
        }
        if (!$partnerProfile) {
            Logger::warning("handleViewProfile: profile for user_id=$partnerId not found");
            $this->bale->answerCallbackQuery($callbackId, '❌ پروفایل این کاربر وجود ندارد.', true);
            return;
        }

        // مرحله ۳: پاسخ به callback (برای بستن spinner)
        try {
            $this->bale->answerCallbackQuery($callbackId);
        } catch (Throwable $e) {
            Logger::warning("handleViewProfile: answerCallbackQuery failed (non-fatal): " . $e->getMessage());
            // ادامه می‌دهیم — این خطا نباید جریان را متوقف کند
        }

        // مرحله ۴: ساختن کیبورد چت (اگر کاربر در ملاقات مخفیانه است)
        $replyMarkup = [];
        $roomId = 0;
        try {
            if (($user['current_status'] ?? 'idle') === 'in_secret_meeting'
                && !empty($user['current_secret_meeting_room_id'])) {
                $roomId = (int) $user['current_secret_meeting_room_id'];
                $room = SecretMeetingRoom::getRoomById($roomId);
                if ($room && $room['status'] === 'active') {
                    $replyMarkup = $this->bale->secretMeetingChatKeyboard($partnerId, $roomId);
                } else {
                    Logger::warning("handleViewProfile: room $roomId not active (status=" . ($room['status'] ?? 'null') . ")");
                }
            }
        } catch (Throwable $e) {
            Logger::error("handleViewProfile: keyboard build failed: " . $e->getMessage());
            // ادامه با replyMarkup خالی
        }

        // مرحله ۵: ساختن متن کارت پروفایل (null-safe)
        try {
            $cardText = Profile::formatCard($partnerProfile);
        } catch (Throwable $e) {
            Logger::error("handleViewProfile: formatCard threw: " . $e->getMessage() . " | profile keys: " . json_encode(array_keys($partnerProfile)));
            // fallback: متن ساده
            $cardText = "👤 " . ($partnerProfile['name'] ?? 'کاربر ناشناس');
        }

        // مرحله ۶: ارسال عکس یا پیام
        // اگر عکس موجود است، ابتدا sendPhoto را امتحان کن؛ اگر شکست خورد، به sendMessage fallback کن
        $photoFileId = $partnerProfile['photo_file_id'] ?? '';
        $photoSent = false;

        if (!empty($photoFileId)) {
            try {
                $result = $this->bale->sendPhoto($chatId, $photoFileId, $cardText, $replyMarkup);
                if ($result !== null) {
                    $photoSent = true;
                    Logger::info("handleViewProfile: sendPhoto OK for user={$user['id']}");
                } else {
                    Logger::warning("handleViewProfile: sendPhoto returned null (API error) — falling back to sendMessage");
                }
            } catch (Throwable $e) {
                Logger::error("handleViewProfile: sendPhoto threw: " . $e->getMessage() . " — falling back to sendMessage");
            }
        }

        if (!$photoSent) {
            try {
                $this->bale->sendMessage($chatId, $cardText, $replyMarkup);
                Logger::info("handleViewProfile: sendMessage OK for user={$user['id']}");
            } catch (Throwable $e) {
                Logger::error("handleViewProfile: sendMessage also failed: " . $e->getMessage());
                throw $e;
            }
        }

        // مرحله ۷: اطلاع‌رسانی به طرف مقابل که پرونده‌اش را دیده‌اند
        // (با حفظ کیبورد چت کاربر مقابل تا از گفتگو خارج نشود)
        try {
            $partnerBaleId = (int) ($partner['bale_id'] ?? 0);
            if ($partnerBaleId > 0) {
                // کیبورد چت فعلی کاربر مقابل را می‌سازیم تا از گفتگو خارج نشود
                $partnerChatKeyboard = $this->resolveActiveChatKeyboard($partner, (int) $user['id']);
                $this->bale->sendMessage(
                    $partnerBaleId,
                    '🕵️ مخاطب پرونده تان را چک کرد، مافیایی',
                    $partnerChatKeyboard
                );
                Logger::info("handleViewProfile: notified partner {$partnerId} that their profile was viewed by user={$user['id']}");
            }
        } catch (Throwable $e) {
            // اگر ارسال اطلاع‌رسانی شکست خورد، جریان نمایش پرونده را خراب نکن
            Logger::warning("handleViewProfile: failed to notify partner {$partnerId} (non-fatal): " . $e->getMessage());
        }
    }

    private function handleGiveGift(array $user, string $callbackId, int $partnerId): void
    {
        $chatId = (int) $user['bale_id'];
        $giftCost = 10; // Example fixed cost for a gift

        $partner = User::findById($partnerId);
        if (!$partner) {
            $this->bale->answerCallbackQuery($callbackId, '❌ کاربر یافت نشد.', true);
            return;
        }

        $myProfile = Profile::findByUserId($user['id']);
        if (!$myProfile) {
            $this->bale->answerCallbackQuery($callbackId, '❌ پروفایل شما یافت نشد.', true);
            return;
        }

        if (Coin::getBalance($user['id']) < $giftCost) {
            $this->bale->answerCallbackQuery($callbackId, '⚠️ سکه کافی برای ارسال هدیه ندارید.', true);
            return;
        }

        if (Coin::deduct($user['id'], $giftCost, 'ارسال هدیه به ' . $partnerId)) {
            $partnerBaleId = (int) $partner['bale_id'];

            $this->bale->answerCallbackQuery($callbackId, '🎁 هدیه ارسال شد.', false);

            // برای کاربر فرستنده: کیبورد چت را حفظ کن (اگر در secret meeting است)
            $senderKeyboard = $this->resolveActiveChatKeyboard($user, $partnerId);
            $this->bale->sendMessage($chatId, "🎁 شما یک هدیه ارسال کردید.", $senderKeyboard);

            // برای کاربر گیرنده: کیبورد چت خودش را بفرست
            $receiverKeyboard = $this->resolveActiveChatKeyboard($partner, $user['id']);
            $this->bale->sendMessage(
                $partnerBaleId,
                "🎁 شما از {$myProfile['name']} یک هدیه دریافت کردید!",
                $receiverKeyboard
            );
            // In a more complete system, we would record the gift in a gift_transactions table
        } else {
            $this->bale->answerCallbackQuery($callbackId, '❌ خطا در ارسال هدیه. لطفاً دوباره تلاش کنید.', true);
        }
    }

    /**
     * گرفتن کیبورد مناسب برای کاربر در حالت active chat.
     * - اگر در secret_meeting است → secretMeetingChatKeyboard
     * - اگر در match chat است → inline keyboard با block/delete/back
     * - در غیر این صورت → main menu
     */
    private function resolveActiveChatKeyboard(array $user, int $partnerId): array
    {
        $status = $user['current_status'] ?? 'idle';
        if ($status === 'in_secret_meeting' && !empty($user['current_secret_meeting_room_id'])) {
            $roomId = (int) $user['current_secret_meeting_room_id'];
            $room = SecretMeetingRoom::getRoomById($roomId);
            if ($room && $room['status'] === 'active') {
                return $this->bale->secretMeetingChatKeyboard($partnerId, $roomId);
            }
        }
        // fallback برای match‌های عادی یا حالت idle
        $stepData = User::getStepData($user);
        if (!empty($stepData['match_id'])) {
            return $this->bale->inlineKeyboard([[
                ['text' => '🚫 بلاک کردن', 'callback_data' => 'chat_block_' . $partnerId],
                ['text' => '🗑 حذف مچ', 'callback_data' => 'chat_delete_' . $stepData['match_id']],
                ['text' => '🔙 بازگشت', 'callback_data' => 'chat_back'],
            ]]);
        }
        return $this->bale->mainMenuKeyboard();
    }

    private function handleEndChat(array $user, string $callbackId, int $roomId): void
    {
        $chatId = (int) $user['bale_id'];
        $room = SecretMeetingRoom::getRoomById($roomId);

        if (!$room) {
            $this->bale->answerCallbackQuery($callbackId, '❌ اتاق گفتگو یافت نشد.', true);
            return;
        }

        // بررسی اینکه کاربر واقعاً عضو این اتاق است
        $isUser1 = ((int) $room['user1_id'] === (int) $user['id']);
        $isUser2 = ((int) $room['user2_id'] === (int) $user['id']);
        if (!$isUser1 && !$isUser2) {
            $this->bale->answerCallbackQuery($callbackId, '❌ دسترسی ندارید.', true);
            return;
        }

        // اگر اتاق از قبل پایان یافته، فقط وضعیت کاربر را idle کن
        if ($room['status'] !== 'active') {
            User::updateUserStatus($user['id'], 'idle');
            User::updateStep($user['id'], 'idle');
            $this->bale->answerCallbackQuery($callbackId, 'گفتگو از قبل پایان یافته.', false);
            $this->bale->sendMessage($chatId, '✅ گفتگوی شما پایان یافت.', $this->bale->mainMenuKeyboard());
            return;
        }

        $partnerId = $isUser1 ? (int) $room['user2_id'] : (int) $room['user1_id'];
        $partnerUser = User::findById($partnerId);
        $partnerBaleId = $partnerUser ? (int) $partnerUser['bale_id'] : 0;

        // مشخص کردن کاربر پایان‌دهنده (user1 یا user2) — برای ENUM معتبر در ستون status
        $endStatus = $isUser1 ? 'ended_by_user1' : 'ended_by_user2';

        SecretMeetingRoom::endRoom($roomId, $endStatus);
        User::updateUserStatus($user['id'], 'idle');
        User::updateStep($user['id'], 'idle');
        if ($partnerId) {
            User::updateUserStatus($partnerId, 'idle');
            User::updateStep($partnerId, 'idle');
        }

        $this->bale->answerCallbackQuery($callbackId, 'گفتگو پایان یافت.', false);
        $this->bale->sendMessage($chatId, '✅ گفتگوی شما پایان یافت.', $this->bale->mainMenuKeyboard());
        if ($partnerBaleId) {
            $this->bale->sendMessage($partnerBaleId, '👋 طرف مقابل گفتگو را پایان داد.', $this->bale->mainMenuKeyboard());
        }
    }

    private function handleDeleteMessages(array $user, string $callbackId, int $roomId): void
    {
        $chatId = (int) $user['bale_id'];
        $room = SecretMeetingRoom::getRoomById($roomId);

        if (!$room) {
            $this->bale->answerCallbackQuery($callbackId, '❌ اتاق گفتگو یافت نشد.', true);
            return;
        }

        if ($room['status'] !== 'active') {
            $this->bale->answerCallbackQuery($callbackId, '❌ این گفتگو پایان یافته است.', true);
            User::updateUserStatus($user['id'], 'idle');
            User::updateStep($user['id'], 'idle');
            $this->bale->sendMessage($chatId, '✅ گفتگوی شما پایان یافت.', $this->bale->mainMenuKeyboard());
            return;
        }

        // Verify user is part of this room
        $isUser1 = ($room['user1_id'] == $user['id']);
        $isUser2 = ($room['user2_id'] == $user['id']);
        if (!$isUser1 && !$isUser2) {
            $this->bale->answerCallbackQuery($callbackId, '❌ دسترسی ندارید.', true);
            return;
        }

        if ($isUser1) {
            Database::execute('UPDATE messages SET deleted_by_user1 = 1 WHERE conversation_type = "secret_meeting" AND conversation_id = ?', [$roomId]);
        } else {
            Database::execute('UPDATE messages SET deleted_by_user2 = 1 WHERE conversation_type = "secret_meeting" AND conversation_id = ?', [$roomId]);
        }

        // پیدا کردن partner برای ساختن کیبورد چت
        $partnerId = $isUser1 ? (int) $room['user2_id'] : (int) $room['user1_id'];

        $this->bale->answerCallbackQuery($callbackId, '🗑 پیام‌ها برای شما حذف شدند.', false);
        $this->bale->sendMessage(
            $chatId,
            '🗑 تاریخچه گفتگو برای شما حذف شد.',
            $this->bale->secretMeetingChatKeyboard($partnerId, $roomId)
        );
    }

    private function handleReportUser(array $user, string $callbackId, int $partnerId): void
    {
        $chatId = (int) $user['bale_id'];

        $partner = User::findById($partnerId);
        if (!$partner) {
            $this->bale->answerCallbackQuery($callbackId, '❌ کاربر یافت نشد.', true);
            return;
        }

        // For simplicity, we'll use a generic reason for now.
        // In a real system, you might ask the user for a specific reason.
        $reason = 'گزارش شده از چت ملاقات مخفیانه';

        BlockReport::report($user['id'], $partnerId, $reason);

        $this->bale->answerCallbackQuery($callbackId, '🚨 کاربر گزارش شد. با تشکر از شما.', true);

        // کیبورد چت را حفظ کن — گزارش دادن نباید از چت خارج کند
        $chatKeyboard = $this->resolveActiveChatKeyboard($user, $partnerId);
        $this->bale->sendMessage(
            $chatId,
            '🚨 کاربر مورد نظر گزارش شد. تیم پشتیبانی ما به زودی بررسی خواهد کرد.',
            $chatKeyboard
        );
    }
}