<?php

class SettingsController
{
    private Bale $bale;

    public function __construct(Bale $bale)
    {
        $this->bale = $bale;
    }

    public function show(array $user): void
    {
        $chatId = (int) $user['bale_id'];
        $profile = Profile::findByUserId($user['id']);
        $isVip = Vip::isVip($user['id']);

        $text = "⚙ *تنظیمات*\n\n";
        $text .= "👤 نام: {$profile['name']}\n";
        $text .= "📍 شهر: {$profile['city']}\n";
        $text .= "⭐ وضعیت: " . ($isVip ? 'عضو ویژه' : 'عادی') . "\n";

        $this->bale->sendMessage($chatId, $text, $this->bale->inlineKeyboard([
            [['text' => '🔍 فیلتر جستجو', 'callback_data' => 'settings_filter']],
            [['text' => '🔙 بازگشت', 'callback_data' => 'settings_back']],
        ]));
    }

    public function showVip(array $user): void
    {
        $chatId = (int) $user['bale_id'];
        $isVip = Vip::isVip($user['id']);

        if ($isVip) {
            $vipInfo = Vip::getInfo($user['id']);
            $this->bale->sendMessage($chatId, "⭐ *عضویت ویژه فعال*\n\nتاریخ انقضا: {$vipInfo['expires_at']}\n\nمزایا:\n✅ مشاهده نامحدود\n✅ لایک نامحدود\n✅ اولویت در نمایش");
            return;
        }

        $this->bale->sendMessage($chatId, "⭐ *عضویت ویژه*\n\nمزایا:\n✅ مشاهده نامحدود\n✅ لایک نامحدود\n✅ اولویت در نمایش\n\nبرای خرید با ادمین تماس بگیرید.", $this->bale->inlineKeyboard([
            [['text' => '📞 تماس با ادمین', 'callback_data' => 'vip_contact']],
        ]));
    }

    public function startReport(array $user): void
    {
        $chatId = (int) $user['bale_id'];
        User::updateStep($user['id'], 'report_id');
        $this->bale->sendMessage($chatId, "🚨 *گزارش کاربر*\n\nشناسه بله (Bale ID) کاربر مورد نظر را وارد کنید:", $this->bale->removeKeyboard());
    }

    public function handleReport(array $user, string $text): void
    {
        $chatId = (int) $user['bale_id'];
        $step = $user['step'];
        $stepData = User::getStepData($user) ?? [];

        if ($step === 'report_id') {
            $targetBaleId = (int) $text;
            $targetUser = User::findByBaleId($targetBaleId) ?? Database::fetch('SELECT u.* FROM users u WHERE u.bale_id = ?', [$targetBaleId]);

            if (!$targetUser) {
                $this->bale->sendMessage($chatId, '❌ کاربر یافت نشد.');
                User::updateStep($user['id'], 'idle');
                $this->bale->sendMessage($chatId, 'بازگشت به منو.', $this->bale->mainMenuKeyboard());
                return;
            }

            $stepData['reported_id'] = $targetUser['id'];
            User::updateStep($user['id'], 'report_reason', $stepData);
            $this->bale->sendMessage($chatId, "دلیل گزارش را بنویسید:");
        } elseif ($step === 'report_reason') {
            BlockReport::report($user['id'], $stepData['reported_id'], htmlspecialchars(mb_substr($text, 0, 255)));
            User::updateStep($user['id'], 'idle');
            $this->bale->sendMessage($chatId, '✅ گزارش شما ثبت شد و توسط ادمین بررسی خواهد شد.', $this->bale->mainMenuKeyboard());
        }
    }

    public function handleCallback(array $user, string $callbackId, string $data): void
    {
        $chatId = (int) $user['bale_id'];

        if ($data === 'vip_contact') {
            $this->bale->answerCallbackQuery($callbackId);
            $this->bale->sendMessage($chatId, "برای خرید عضویت ویژه با ادمین تماس بگیرید:\n@admin_username");
        } elseif ($data === 'settings_back') {
            User::updateStep($user['id'], 'idle');
            $this->bale->answerCallbackQuery($callbackId);
            $this->bale->sendMessage($chatId, 'بازگشت به منو.', $this->bale->mainMenuKeyboard());
        } elseif ($data === 'settings_filter') {
            $this->bale->answerCallbackQuery($callbackId, 'به‌زودی اضافه می‌شود.', true);
        }
    }
}
