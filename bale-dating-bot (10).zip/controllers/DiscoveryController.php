<?php

class DiscoveryController
{
    private Bale $bale;

    public function __construct(Bale $bale)
    {
        $this->bale = $bale;
    }

    public function showNext(array $user, array $filters = []): void
    {
        $chatId = (int) $user['bale_id'];

        if ($user['step'] === 'chatting') {
            User::updateStep($user['id'], 'idle');
        }

        if (!Vip::canView($user['id'])) {
            $this->bale->sendMessage(
                $chatId,
                "⚠️ محدودیت روزانه شما تمام شده است.\n\nبرای مشاهده نامحدود، عضویت ⭐ ویژه تهیه کنید.",
                $this->bale->mainMenuKeyboard()
            );
            return;
        }

        $profiles = Profile::getForDiscovery($user['id'], $filters);

        if (empty($profiles)) {
            $this->bale->sendMessage(
                $chatId,
                "😔 در حال حاضر کاربر جدیدی برای نمایش وجود ندارد.\nبعداً دوباره امتحان کنید.",
                $this->bale->mainMenuKeyboard()
            );
            return;
        }

        $profile = $profiles[0];
        Profile::incrementViews($user['id']);

        $caption = Profile::formatCard($profile);
        $keyboard = $this->bale->inlineKeyboard([[
            ['text' => '❤️ پسندیدن', 'callback_data' => 'like_' . $profile['user_id']],
            ['text' => '❌ رد کردن', 'callback_data' => 'dislike_' . $profile['user_id']],
            ['text' => '⏭ بعدی', 'callback_data' => 'next_' . $profile['user_id']],
        ]]);

        if ($profile['photo_file_id']) {
            $this->bale->sendPhoto($chatId, $profile['photo_file_id'], $caption, $keyboard);
        } else {
            $this->bale->sendMessage($chatId, $caption, $keyboard);
        }
    }

    public function handleCallback(array $user, string $callbackId, string $data, int $messageId): void
    {
        $chatId = (int) $user['bale_id'];
        [$action, $targetUserId] = explode('_', $data, 2);
        $targetUserId = (int) $targetUserId;

        if ($action === 'like') {
            if (!Vip::canLike($user['id'])) {
                $this->bale->answerCallbackQuery($callbackId, '⚠️ محدودیت لایک روزانه! عضویت ویژه تهیه کنید.', true);
                return;
            }
            MatchModel::addLike($user['id'], $targetUserId, 'like');
            Profile::incrementLikes($user['id']);

            if (MatchModel::checkMutualLike($user['id'], $targetUserId)) {
                MatchModel::createMatch($user['id'], $targetUserId);
                $targetUser = User::findById($targetUserId);
                $myProfile = Profile::findByUserId($user['id']);
                $theirProfile = Profile::findByUserId($targetUserId);

                // اطمینان از وجود پروفایل هر دو طرف — جلوگیری از TypeError
                if ($targetUser && $myProfile && $theirProfile) {
                    $this->bale->sendMessage(
                        $chatId,
                        "🎉 *مچ شدید!*\nشما و *{$theirProfile['name']}* همدیگر را پسند کردید.\nمیتوانید گفتگو کنید! 💬",
                        $this->bale->mainMenuKeyboard()
                    );
                    $this->bale->sendMessage(
                        (int) $targetUser['bale_id'],
                        "🎉 *مچ شدید!*\nشما و *{$myProfile['name']}* همدیگر را پسند کردید.\nمیتوانید گفتگو کنید! 💬",
                        $this->bale->mainMenuKeyboard()
                    );
                    $this->bale->answerCallbackQuery($callbackId, '❤️ مچ شدید!', true);
                } else {
                    Logger::error("DiscoveryController: missing profile for match (user={$user['id']}, target=$targetUserId, targetUser=" . ($targetUser ? 'yes' : 'no') . ', myProfile=' . ($myProfile ? 'yes' : 'no') . ', theirProfile=' . ($theirProfile ? 'yes' : 'no') . ')');
                    $this->bale->answerCallbackQuery($callbackId, '❌ خطا در ساخت مچ. لطفاً بعداً تلاش کنید.', true);
                }
                return;
            }
            $this->bale->answerCallbackQuery($callbackId, '❤️ پسندیده شد!');
        } elseif ($action === 'dislike') {
            MatchModel::addLike($user['id'], $targetUserId, 'dislike');
            $this->bale->answerCallbackQuery($callbackId, '❌ رد شد.');
        } elseif ($action === 'next') {
            $this->bale->answerCallbackQuery($callbackId);
        }

        $this->bale->deleteMessage($chatId, $messageId);
        $this->showNext($user);
    }
}
