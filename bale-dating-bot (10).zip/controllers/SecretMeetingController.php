<?php

use SecretMeetingQueue;

class SecretMeetingController
{
    private Bale $bale;
    private ChatController $chatCtrl;

    private const COST_GENDER = 2;
    private const COST_PROVINCE = 4;

    private const PROVINCES = [
        'تهران', 'اصفهان', 'فارس', 'خراسان رضوی', 'آذربایجان شرقی',
        'آذربایجان غربی', 'اردبیل', 'البرز', 'ایلام', 'بوشهر',
        'چهارمحال و بختیاری', 'خراسان جنوبی', 'خراسان شمالی', 'خوزستان', 'زنجان',
        'سمنان', 'سیستان و بلوچستان', 'گیلان', 'گلستان', 'همدان',
        'هرمزگان', 'کردستان', 'کرمان', 'کرمانشاه', 'کهگیلویه و بویراحمد',
        'لرستان', 'مازندران', 'مرکزی', 'قزوین', 'قم', 'یزد',
    ];

    public function __construct(Bale $bale, ChatController $chatCtrl)
    {
        $this->bale = $bale;
        $this->chatCtrl = $chatCtrl;
    }

    public function showMenu(array $user): void
    {
        Logger::info('User ' . $user['id'] . ' entered SecretMeetingController::showMenu.');
        $chatId = (int) $user['bale_id'];

        try {
            // اطمینان از آماده بودن schema
            Schema::ensureSecretMeetingSchema();

            // اگر کاربر در صف است، از صف خارج کن (شروع جریان جدید)
            if (($user['current_status'] ?? 'idle') === 'in_queue') {
                SecretMeetingQueue::removeFromQueue($user['id']);
                Logger::info('User ' . $user['id'] . ' was in queue, removed from queue.');
            }

            // اگر کاربر در یک گفتگوی فعال است، ابتدا آن را پایان بده
            if (($user['current_status'] ?? 'idle') === 'in_secret_meeting') {
                $this->endExistingSecretMeeting($user);
                $user = User::findById($user['id']);
                if (!$user) return;
                Logger::info('User ' . $user['id'] . ' was in secret meeting, ended it.');
            }

            if ($user['step'] === 'chatting') {
                User::updateStep($user['id'], 'idle');
                Logger::info('User ' . $user['id'] . ' was chatting, step set to idle.');
            }

            User::updateStep($user['id'], 'secret_meeting');
            Logger::info('User ' . $user['id'] . ' step set to secret_meeting.');
        } catch (Throwable $e) {
            Logger::error('showMenu failed (user=' . $user['id'] . '): ' . $e->getMessage());
            // ادامه می‌دهیم — حتی اگر cleanup شکست خورد، منو را نشان بده
        }

        $this->bale->sendMessage(
            $chatId,
            "🕶 *ملاقات ناشناس*\n\nنوع جستجو را انتخاب کنید:",
            $this->bale->secretMeetingKeyboard()
        );
        Logger::info('User ' . $user['id'] . ' secret meeting keyboard sent.');
    }

    /**
     * نمایش پیام "به‌زودی" برای جستجوی پیشرفته
     */
    public function showComingSoon(array $user, bool $advanced = false): void
    {
        $chatId = (int) $user['bale_id'];
        $this->bale->sendMessage(
            $chatId,
            "🚧 *جستجوی پیشرفته*\n\nاین بخش به‌زودی فعال خواهد شد.\nدر نسخه بعدی می‌توانید بر اساس سن، علایق و فاصله جستجو کنید.",
            $this->bale->mainMenuKeyboard()
        );
    }

    public function handleMenu(array $user, string $text): void
    {
        $chatId = (int) $user['bale_id'];

        switch ($text) {
            case '🎲 جستجوی شانسی (0 سکه)':
                $this->addToQueue($user, 'random', null, null, 0);
                break;

            case '👨 جستجوی پسر (2 سکه)':
                $this->addToQueue($user, 'gender_male', 'male', null, self::COST_GENDER);
                break;

            case '👩 جستجوی دختر (2 سکه)':
                $this->addToQueue($user, 'gender_female', 'female', null, self::COST_GENDER);
                break;

            case '🗺 جستجوی بر اساس استان (4 سکه)':
                if (Coin::getBalance($user['id']) < self::COST_PROVINCE) {
                    $this->bale->sendMessage(
                        $chatId,
                        '⚠️ برای جستجوی استانی به *' . self::COST_PROVINCE . ' سکه* نیاز دارید.',
                        $this->bale->secretMeetingKeyboard()
                    );
                    return;
                }
                User::updateStep($user['id'], 'secret_meeting_gender');
                $this->bale->sendMessage(
                    $chatId,
                    '🗺 ابتدا جنسیت مورد نظر را انتخاب کنید:',
                    $this->genderKeyboard()
                );
                break;

            case '🔙 بازگشت':
                $status = $user['current_status'] ?? 'idle';
                if ($status === 'in_queue') {
                    SecretMeetingQueue::removeFromQueue($user['id']);
                    User::updateUserStatus($user['id'], 'idle');
                    User::updateStep($user['id'], 'idle');
                    $this->bale->sendMessage($chatId, 'از صف انتظار خارج شدید.', $this->bale->mainMenuKeyboard());
                } elseif ($status === 'in_secret_meeting') {
                    // اگر در گفتگوی فعال است، آن را هم پایان بده
                    $this->endExistingSecretMeeting($user);
                    $this->bale->sendMessage($chatId, 'از گفتگو خارج شدید.', $this->bale->mainMenuKeyboard());
                } else {
                    User::updateStep($user['id'], 'idle');
                    User::updateUserStatus($user['id'], 'idle');
                    $this->bale->sendMessage($chatId, 'بازگشت به منوی اصلی.', $this->bale->mainMenuKeyboard());
                }
                break;

            default:
                $this->bale->sendMessage($chatId, 'لطفاً از دکمه‌های منو استفاده کنید.', $this->bale->secretMeetingKeyboard());
                break;
        }
    }

    public function handleGenderSelection(array $user, string $text): void
    {
        $chatId = (int) $user['bale_id'];

        if ($text === '🔙 بازگشت') {
            User::updateStep($user['id'], 'secret_meeting');
            $this->bale->sendMessage($chatId, '🕶 *ملاقات ناشناس*', $this->bale->secretMeetingKeyboard());
            return;
        }

        if (!str_contains($text, 'پسر') && !str_contains($text, 'دختر')) {
            $this->bale->sendMessage($chatId, '❌ لطفاً از دکمه‌ها استفاده کنید.', $this->genderKeyboard());
            return;
        }

        $gender = str_contains($text, 'پسر') ? 'male' : 'female';
        $stepData = User::getStepData($user) ?? [];
        $stepData['search_gender'] = $gender;
        User::updateStep($user['id'], 'secret_meeting_province', $stepData);
        $this->bale->sendMessage(
            $chatId,
            '🗺 استان مورد نظر را انتخاب کنید:',
            $this->bale->provinceKeyboard()
        );
    }

    public function handleProvinceSelection(array $user, string $text): void
    {
        $chatId = (int) $user['bale_id'];

        if ($text === '🔙 بازگشت') {
            User::updateStep($user['id'], 'secret_meeting');
            $this->bale->sendMessage($chatId, '🕶 *ملاقات ناشناس*', $this->bale->secretMeetingKeyboard());
            return;
        }

        if (!in_array($text, self::PROVINCES, true)) {
            $this->bale->sendMessage($chatId, '❌ لطفاً از دکمه‌های استان استفاده کنید.', $this->bale->provinceKeyboard());
            return;
        }

        User::updateStep($user['id'], 'idle');
        $stepData = User::getStepData($user) ?? [];
        $filters = ['city' => $text];
        if (!empty($stepData['search_gender'])) {
            $filters['gender'] = $stepData['search_gender'];
        }

        $this->addToQueue($user, 'province', $stepData['search_gender'] ?? null, $text, self::COST_PROVINCE);
    }

    private function addToQueue(array $user, string $searchPreference, ?string $genderPreference, ?string $provincePreference, int $coinCost): void
    {
        $chatId = (int) $user['bale_id'];

        // اطمینان از آماده بودن schema (دقیقاً مثل webhook، idempotent)
        try {
            Schema::ensureSecretMeetingSchema();
        } catch (Throwable $e) {
            Logger::error('addToQueue: schema check failed: ' . $e->getMessage());
        }

        try {
            // اگر کاربر در حال حاضر در یک گفتگوی فعال است، ابتدا آن را پایان بده
            if (($user['current_status'] ?? 'idle') === 'in_secret_meeting') {
                $this->endExistingSecretMeeting($user);
                $user = User::findById($user['id']);
                if (!$user) return;
            }

            // اگر کاربر از قبل در صف است، فقط مچ کردن را دوباره امتحان کن (تغییر ترجیح نه)
            if (($user['current_status'] ?? 'idle') === 'in_queue') {
                $match = SecretMeetingQueue::tryMatchUser($user['id']);
                if ($match) {
                    $this->notifyMatch($user, $match);
                } else {
                    $this->bale->sendMessage(
                        $chatId,
                        "⏳ شما هنوز در صف انتظار هستید. به محض پیدا شدن کاربر مناسب، متصل می‌شوید.\n\nبرای تغییر نوع جستجو، ابتدا از دکمه «🔙 بازگشت» استفاده کنید.",
                        $this->bale->secretMeetingKeyboard()
                    );
                }
                return;
            }

            if ($coinCost > 0 && Coin::getBalance($user['id']) < $coinCost) {
                $this->bale->sendMessage(
                    $chatId,
                    "⚠️ برای این جستجو به *{$coinCost} سکه* نیاز دارید.\nموجودی شما: " . Coin::getBalance($user['id']) . ' سکه',
                    $this->bale->secretMeetingKeyboard()
                );
                return;
            }

            // Deduct coins before adding to queue
            if ($coinCost > 0 && !Coin::deduct($user['id'], $coinCost, 'ملاقات مخفیانه - ' . $searchPreference)) {
                $this->bale->sendMessage(
                    $chatId,
                    '❌ خطا در کسر سکه. لطفاً دوباره تلاش کنید.',
                    $this->bale->secretMeetingKeyboard()
                );
                return;
            }

            // VIP اولویت بالاتری در صف دارد
            $vipPriority = Vip::isVip($user['id']) ? 1 : 0;

            SecretMeetingQueue::addToQueue($user['id'], $searchPreference, $genderPreference, $provincePreference, $vipPriority);

            // تلاش برای مچ کردن در همان لحظه (Real-time)
            $match = SecretMeetingQueue::tryMatchUser($user['id']);

            if ($match) {
                $this->notifyMatch($user, $match);
                return;
            }

            // اگر مچ نشد، کاربر در صف می‌ماند. ممکن است تراکنش هم‌زمان دیگری او را مچ کرده باشد.
            $refreshedUser = User::findById($user['id']);
            if ($refreshedUser && ($refreshedUser['current_status'] ?? 'idle') === 'in_secret_meeting') {
                // توسط تراکنش هم‌زمان دیگری مچ شد — او خودش Notify می‌کند
                return;
            }

            $this->bale->sendMessage(
                $chatId,
                '🕵️ شما به صف اضافه شدید. به محض پیدا شدن کاربر مناسب، فوراً متصل می‌شوید...',
                $this->bale->secretMeetingKeyboard()
            );
        } catch (Throwable $e) {
            Logger::error('addToQueue failed (user=' . $user['id'] . ', pref=' . $searchPreference . '): ' . $e->getMessage());
            $this->bale->sendMessage(
                $chatId,
                '❌ خطا در افزودن به صف. لطفاً دوباره تلاش کنید یا /start را بزنید.',
                $this->bale->mainMenuKeyboard()
            );
        }
    }

    /**
     * ارسال پیام اتصال موفقیت‌آمیز به هر دو کاربر.
     * این متد بعد از tryMatchUser فراخوانی می‌شود — وضعیت هر دو کاربر
     * در داخل تراکنش به in_secret_meeting تغییر کرده است.
     */
    private function notifyMatch(array $user, array $match): void
    {
        $roomId       = (int) $match['room_id'];
        $partnerId    = (int) $match['partner_user_id'];
        $partnerBale  = (int) $match['partner_bale_id'];
        $myBaleId     = (int) ($match['my_bale_id'] ?? $user['bale_id']);

        $message = "🕶 *اتصال موفقیت‌آمیز*\n\n"
                 . "یک عضو جدید از خانواده مافیا برای ملاقات مخفیانه شما پیدا شد.\n"
                 . "اکنون می‌توانید گفتگوی خصوصی خود را آغاز کنید.\n\n"
                 . "⚠️ پیام‌های شما کاملاً ناشناس است. برای پایان گفتگو از دکمه زیر استفاده کنید.";

        // پیام به کاربر آغازگر
        $this->bale->sendMessage(
            (int) $user['bale_id'],
            $message,
            $this->bale->secretMeetingChatKeyboard($partnerId, $roomId)
        );

        // پیام به طرف مقابل
        $this->bale->sendMessage(
            $partnerBale,
            $message,
            $this->bale->secretMeetingChatKeyboard((int) $user['id'], $roomId)
        );
    }

    /**
     * پایان دادن خودکار به یک ملاقات مخفیانه فعال (در صورت وجود).
     * زمانی استفاده می‌شود که کاربر می‌خواهد وارد صف جدیدی شود ولی هنوز در گفتگوی قبلی است.
     */
    private function endExistingSecretMeeting(array $user): void
    {
        $roomId = (int) ($user['current_secret_meeting_room_id'] ?? 0);
        if (!$roomId) {
            User::updateUserStatus($user['id'], 'idle');
            return;
        }

        $room = SecretMeetingRoom::getRoomById($roomId);
        if (!$room || $room['status'] !== 'active') {
            User::updateUserStatus($user['id'], 'idle');
            User::updateStep($user['id'], 'idle');
            return;
        }

        SecretMeetingRoom::endRoom($roomId, 'aborted');

        $partnerId = ($room['user1_id'] == $user['id']) ? (int) $room['user2_id'] : (int) $room['user1_id'];
        $partner   = User::findById($partnerId);

        User::updateUserStatus($user['id'], 'idle');
        User::updateStep($user['id'], 'idle');

        if ($partner) {
            User::updateUserStatus($partnerId, 'idle');
            User::updateStep($partnerId, 'idle');
            $this->bale->sendMessage(
                (int) $partner['bale_id'],
                '👋 طرف مقابل گفتگو را ترک کرد.',
                $this->bale->mainMenuKeyboard()
            );
        }
    }

    private function genderKeyboard(): array
    {
        return [
            'keyboard' => [
                [['text' => '👨 جستجوی پسر']],
                [['text' => '👩 جستجوی دختر']],
                [['text' => '🔙 بازگشت']],
            ],
            'resize_keyboard'   => true,
            'one_time_keyboard' => true,
        ];
    }


}
