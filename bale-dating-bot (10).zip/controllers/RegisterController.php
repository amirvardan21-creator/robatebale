<?php

class RegisterController
{
    private Bale $bale;

    private const PROVINCES = [
        'تهران','اصفهان','فارس','خراسان رضوی','آذربایجان شرقی',
        'آذربایجان غربی','اردبیل','البرز','ایلام','بوشهر',
        'چهارمحال و بختیاری','خراسان جنوبی','خراسان شمالی','خوزستان','زنجان',
        'سمنان','سیستان و بلوچستان','گیلان','گلستان','همدان',
        'هرمزگان','کردستان','کرمان','کرمانشاه','کهگیلویه و بویراحمد',
        'لرستان','مازندران','مرکزی','قزوین','قم','یزد',
    ];

    public function __construct(Bale $bale)
    {
        $this->bale = $bale;
    }

    private function ageKeyboard(): array
    {
        $rows = [];
        $row  = [];
        for ($i = 10; $i <= 100; $i++) {
            $row[] = ['text' => (string)$i];
            if (count($row) === 5) {
                $rows[] = $row;
                $row = [];
            }
        }
        if ($row) $rows[] = $row;
        return ['keyboard' => $rows, 'resize_keyboard' => true, 'one_time_keyboard' => true];
    }

    private function provinceKeyboard(): array
    {
        $rows = [];
        $row  = [];
        foreach (self::PROVINCES as $p) {
            $row[] = ['text' => $p];
            if (count($row) === 2) {
                $rows[] = $row;
                $row = [];
            }
        }
        if ($row) $rows[] = $row;
        return ['keyboard' => $rows, 'resize_keyboard' => true, 'one_time_keyboard' => true];
    }

    public function start(?array $user, array $from): void
    {
        if (!$user) {
            $userId = User::create(
                $from['id'],
                $from['first_name'],
                $from['last_name'] ?? null,
                $from['username'] ?? null
            );
            $user = User::findById($userId);
        }

        $profile = Profile::findByUserId($user['id']);

        if ($profile) {
            User::updateStep($user['id'], 'idle');
            $this->bale->sendMessage(
                (int)$from['id'],
                "سلام {$profile['name']} عزیز! 👋\nبه ربات دوستیابی خوش برگشتی.",
                $this->bale->mainMenuKeyboard()
            );
            return;
        }

        User::updateStep($user['id'], 'register_name');
        $this->bale->sendMessage(
            (int)$from['id'],
            "👋 سلام! به ربات دوستیابی خوش آمدید.\n\nلطفاً نام خود را وارد کنید:",
            $this->bale->removeKeyboard()
        );
    }

    public function handle(array $user, string $text, ?array $photo): void
    {
        $chatId   = (int)$user['bale_id'];
        $step     = $user['step'];
        $stepData = User::getStepData($user) ?? [];

        switch ($step) {

            case 'register_name':
                if (mb_strlen($text) < 2 || mb_strlen($text) > 50) {
                    $this->bale->sendMessage($chatId, '❌ نام باید بین ۲ تا ۵۰ کاراکتر باشد.');
                    return;
                }
                $stepData['name'] = htmlspecialchars($text);
                User::updateStep($user['id'], 'register_age', $stepData);
                $this->bale->sendMessage($chatId, "✅ نام ثبت شد.\n\nسن خود را انتخاب کنید:", $this->ageKeyboard());
                break;

            case 'register_age':
                $age = (int)$text;
                if ($age < 10 || $age > 100) {
                    $this->bale->sendMessage($chatId, '❌ لطفاً از دکمه‌ها انتخاب کنید.');
                    return;
                }
                $stepData['age'] = $age;
                User::updateStep($user['id'], 'register_gender', $stepData);
                $this->bale->sendMessage($chatId, "✅ سن ثبت شد.\n\nجنسیت خود را انتخاب کنید:", [
                    'keyboard'          => [[['text' => '👨 مرد'], ['text' => '👩 زن']]],
                    'resize_keyboard'   => true,
                    'one_time_keyboard' => true,
                ]);
                break;

            case 'register_gender':
                $gender = null;
                if (str_contains($text, 'مرد')) $gender = 'male';
                elseif (str_contains($text, 'زن')) $gender = 'female';
                if (!$gender) {
                    $this->bale->sendMessage($chatId, '❌ لطفاً از دکمه‌ها استفاده کنید.');
                    return;
                }
                $stepData['gender'] = $gender;
                User::updateStep($user['id'], 'register_city', $stepData);
                $this->bale->sendMessage($chatId, "✅ جنسیت ثبت شد.\n\nاستان خود را انتخاب کنید:", $this->provinceKeyboard());
                break;

            case 'register_city':
                if (!in_array($text, self::PROVINCES)) {
                    $this->bale->sendMessage($chatId, '❌ لطفاً از دکمه‌ها انتخاب کنید.');
                    return;
                }
                $stepData['city'] = $text;
                User::updateStep($user['id'], 'register_bio', $stepData);
                $this->bale->sendMessage(
                    $chatId,
                    "✅ استان ثبت شد.\n\nبیوگرافی خود را بنویسید:\n(هر چیزی که دوست دارید دیگران بدانند — علایق، شخصیت، هدف از آشنایی و ...)\n\nیا دکمه رد کردن را بزنید:",
                    ['keyboard' => [[['text' => '⏭ رد کردن']]], 'resize_keyboard' => true, 'one_time_keyboard' => true]
                );
                break;

            case 'register_bio':
                $stepData['bio']          = ($text === '⏭ رد کردن') ? null : htmlspecialchars(mb_substr($text, 0, 500));
                $stepData['interests']    = null;
                $stepData['looking_for']  = null;
                User::updateStep($user['id'], 'register_photo', $stepData);
                $this->bale->sendMessage(
                    $chatId,
                    "✅ ثبت شد.\n\nعکس پروفایل خود را ارسال کنید:\n(یا دکمه رد کردن را بزنید)",
                    ['keyboard' => [[['text' => '⏭ رد کردن']]], 'resize_keyboard' => true, 'one_time_keyboard' => true]
                );
                break;

            case 'register_photo':
                if ($text === '⏭ رد کردن') {
                    $stepData['photo_file_id'] = null;
                } elseif ($photo) {
                    $stepData['photo_file_id'] = end($photo)['file_id'];
                } else {
                    $this->bale->sendMessage($chatId, '❌ لطفاً یک عکس ارسال کنید یا دکمه رد کردن را بزنید.');
                    return;
                }
                Profile::create($user['id'], $stepData);
                User::updateStep($user['id'], 'idle');
                $this->bale->sendMessage(
                    $chatId,
                    "🎉 پروفایل شما با موفقیت ساخته شد!\n\nاکنون می‌توانید از ربات استفاده کنید.",
                    $this->bale->mainMenuKeyboard()
                );
                break;
        }
    }
}
