<?php

class ProfileController
{
    private Bale $bale;

    public function __construct(Bale $bale)
    {
        $this->bale = $bale;
    }

    public function show(array $user): void
    {
        $chatId = (int) $user['bale_id'];
        $profile = Profile::findByUserId($user['id']);

        if (!$profile) {
            $this->bale->sendMessage($chatId, '❌ پروفایل شما یافت نشد.');
            return;
        }

        $isVip = Vip::isVip($user['id']);
        $vipBadge = $isVip ? ' ⭐' : '';
        $caption = Profile::formatCard($profile) . ($isVip ? "\n⭐ *عضو ویژه*" : '');

        $keyboard = $this->bale->inlineKeyboard([
            [
                ['text' => '✏️ ویرایش اطلاعات', 'callback_data' => 'profile_edit'],
                ['text' => '🖼 تغییر عکس', 'callback_data' => 'profile_photo'],
            ],
            [
                ['text' => $profile['is_visible'] ? '🙈 مخفی کردن' : '👁 نمایش دادن', 'callback_data' => 'profile_toggle'],
                ['text' => '🗑 حذف پروفایل', 'callback_data' => 'profile_delete'],
            ],
        ]);

        if ($profile['photo_file_id']) {
            $this->bale->sendPhoto($chatId, $profile['photo_file_id'], $caption, $keyboard);
        } else {
            $this->bale->sendMessage($chatId, $caption, $keyboard);
        }
    }

    public function handleCallback(array $user, string $callbackId, string $data): void
    {
        $chatId = (int) $user['bale_id'];

        switch ($data) {
            case 'profile_edit':
                User::updateStep($user['id'], 'edit_field');
                $this->bale->answerCallbackQuery($callbackId);
                $this->bale->sendMessage($chatId, 'کدام بخش را میخواهید ویرایش کنید؟', $this->bale->inlineKeyboard([
                    [['text' => 'نام', 'callback_data' => 'edit_name'], ['text' => 'سن', 'callback_data' => 'edit_age']],
                    [['text' => 'شهر', 'callback_data' => 'edit_city'], ['text' => 'بیو', 'callback_data' => 'edit_bio']],
                    [['text' => 'علایق', 'callback_data' => 'edit_interests'], ['text' => 'دنبال چه کسی', 'callback_data' => 'edit_looking_for']],
                ]));
                break;

            case 'profile_photo':
                User::updateStep($user['id'], 'update_photo');
                $this->bale->answerCallbackQuery($callbackId);
                $this->bale->sendMessage($chatId, '📸 عکس جدید خود را ارسال کنید:');
                break;

            case 'profile_toggle':
                $profile = Profile::findByUserId($user['id']);
                $newVisibility = $profile['is_visible'] ? 0 : 1;
                Profile::update($user['id'], ['is_visible' => $newVisibility]);
                $this->bale->answerCallbackQuery($callbackId, $newVisibility ? '👁 پروفایل نمایش داده میشود.' : '🙈 پروفایل مخفی شد.', true);
                break;

            case 'profile_delete':
                $this->bale->answerCallbackQuery($callbackId);
                $this->bale->sendMessage($chatId, '⚠️ آیا مطمئن هستید؟ تمام اطلاعات حذف میشود.', $this->bale->inlineKeyboard([
                    [['text' => '✅ بله، حذف کن', 'callback_data' => 'profile_delete_confirm'], ['text' => '❌ انصراف', 'callback_data' => 'profile_delete_cancel']],
                ]));
                break;

            case 'profile_delete_confirm':
                User::delete($user['id']);
                $this->bale->answerCallbackQuery($callbackId, '✅ پروفایل حذف شد.', true);
                $this->bale->sendMessage($chatId, '✅ پروفایل شما حذف شد. برای ثبت نام مجدد /start را بزنید.', $this->bale->removeKeyboard());
                break;

            case 'profile_delete_cancel':
                $this->bale->answerCallbackQuery($callbackId, 'انصراف داده شد.');
                break;

            default:
                if (str_starts_with($data, 'edit_')) {
                    $field = substr($data, 5);
                    User::updateStep($user['id'], 'editing_' . $field);
                    $labels = [
                        'name' => 'نام جدید', 'age' => 'سن جدید', 'city' => 'شهر جدید',
                        'bio' => 'بیو جدید', 'interests' => 'علایق جدید', 'looking_for' => 'دنبال چه کسی هستی',
                    ];
                    $this->bale->answerCallbackQuery($callbackId);
                    $this->bale->sendMessage($chatId, "✏️ {$labels[$field]} را وارد کنید:");
                }
        }
    }

    public function handleEdit(array $user, string $text, ?array $photo): void
    {
        $chatId = (int) $user['bale_id'];
        $step = $user['step'];

        if ($step === 'edit_field') {
            $this->bale->sendMessage($chatId, 'لطفاً از دکمه‌های بالا یک گزینه را انتخاب کنید.');
            return;
        }

        if ($step === 'update_photo') {
            if (!$photo) {
                $this->bale->sendMessage($chatId, '❌ لطفاً یک عکس ارسال کنید.');
                return;
            }
            $fileId = end($photo)['file_id'];
            Profile::update($user['id'], ['photo_file_id' => $fileId]);
            User::updateStep($user['id'], 'idle');
            $this->bale->sendMessage($chatId, '✅ عکس پروفایل بروزرسانی شد.', $this->bale->mainMenuKeyboard());
            return;
        }

        $field = str_replace('editing_', '', $step);
        $allowedFields = ['name', 'age', 'city', 'bio', 'interests', 'looking_for'];

        if (!in_array($field, $allowedFields)) return;

        $value = htmlspecialchars(mb_substr($text, 0, 300));
        if ($field === 'age') {
            $value = (int) $text;
            if ($value < 18 || $value > 80) {
                $this->bale->sendMessage($chatId, '❌ سن باید بین ۱۸ تا ۸۰ باشد.');
                return;
            }
        }

        Profile::update($user['id'], [$field => $value]);
        User::updateStep($user['id'], 'idle');
        $this->bale->sendMessage($chatId, '✅ اطلاعات بروزرسانی شد.', $this->bale->mainMenuKeyboard());
    }
}
