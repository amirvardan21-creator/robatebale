<?php
/**
 * نمونه فایل تنظیمات — این فایل را به config.php کپی کن و مقادیر را پر کن
 * هرگز فایل config.php واقعی را در گیت commit نکن!
 */

define('BOT_TOKEN', 'YOUR_BALE_BOT_TOKEN_HERE');
define('BOT_USERNAME', 'your_bot_username');
define('BALE_API_URL', 'https://tapi.bale.ai/bot' . BOT_TOKEN . '/');
define('WEBHOOK_SECRET', 'CHANGE_THIS_TO_RANDOM_STRING_32_CHARS');

define('DB_HOST', 'localhost');
define('DB_NAME', 'your_db_name');
define('DB_USER', 'your_db_user');
define('DB_PASS', 'your_db_password');
define('DB_CHARSET', 'utf8mb4');

define('ADMIN_BALE_ID', 0); // شناسه بله ادمین (عدد)

define('UPLOAD_PATH', __DIR__ . '/../uploads/');
define('LOG_PATH', __DIR__ . '/../logs/');
define('BASE_URL', 'https://yourdomain.com/bale');

define('FREE_DAILY_LIKES', 10);
define('FREE_DAILY_VIEWS', 20);

define('ADMIN_USERNAME', 'admin');
define('ADMIN_PASSWORD', 'change_this_password');
