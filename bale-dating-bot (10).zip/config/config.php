<?php
define('BOT_TOKEN', '1706344265:70iFbRkBeq92GWyXnUwrIQqKkd2HBdZJShM');
define('BOT_USERNAME', 'your_bot_username');
define('BALE_API_URL', 'https://tapi.bale.ai/bot' . BOT_TOKEN . '/');
define('WEBHOOK_SECRET', 'xK9mP2qR7nL4wZ3');

define('DB_HOST', 'localhost');
define('DB_NAME', 'opujkdbu_dating');
define('DB_USER', 'opujkdbu_dating');
define('DB_PASS', 'amir1381@@');
define('DB_CHARSET', 'utf8mb4');

define('ADMIN_BALE_ID', 1480128084);

define('UPLOAD_PATH', __DIR__ . '/../uploads/');
define('LOG_PATH', __DIR__ . '/../logs/');
define('BASE_URL', 'https://a7vbot.ir/bale');

define('FREE_DAILY_LIKES', 10);
define('FREE_DAILY_VIEWS', 20);

define('ADMIN_USERNAME', 'admin');
define('ADMIN_PASSWORD', 'change_this_password');
