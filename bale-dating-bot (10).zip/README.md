# 🤖 ربات دوستیابی بله (مافیا مچ)

ربات دوستیابی حرفه‌ای برای پیام‌رسان **بله** - ساخته شده با PHP 8.1 و MySQL

---

## 📁 ساختار پروژه

```
bale-dating-bot/
├── config/
│   ├── config.php              # تنظیمات اصلی (هرگز در گیت commit نشود)
│   └── config.example.php      # نمونه تنظیمات
├── classes/                    # لایه مدل (Bale, User, Profile, Match, Coin, Vip, ...)
├── controllers/                # لایه کنترلر
│   ├── RegisterController.php
│   ├── DiscoveryController.php
│   ├── ProfileController.php
│   ├── ChatController.php
│   ├── SettingsController.php
│   └── SecretMeetingController.php
├── webhook/                    # نقطه ورودی webhook
├── admin/                      # پنل مدیریت (با CSRF protection)
├── cli/
│   └── cli_match_maker.php     # پردازشگر صف ملاقات ناشناس (الزامی: cron)
├── database/
│   ├── database.sql            # اسکیمای پایه
│   └── migrations/             # مایگریشن‌ها
├── install.php                 # نصب خودکار (بعد از نصب حذف کن)
├── .gitignore                  # جلوگیری از commit فایل‌های حساس
└── README.md
```

---

## 🚀 نصب روی cPanel

### مرحله ۱: آپلود فایل‌ها
1. وارد **File Manager** در cPanel شوید
2. فایل‌ها را در `public_html/bale/` آپلود کنید
3. پوشه‌های `uploads/` و `logs/` را قابل نوشتن کنید:
   ```
   chmod 755 uploads/
   chmod 755 logs/
   ```

### مرحله ۲: ساخت دیتابیس
1. در cPanel به **MySQL Databases** بروید
2. دیتابیس و کاربر MySQL بسازید

### مرحله ۳: تنظیم config
فایل `config/config.php` را با مقادیر واقعی پر کنید (از `config.example.php` کپی کنید):
```php
define('BOT_TOKEN', 'توکن_ربات_بله');
define('WEBHOOK_SECRET', 'یک_رشته_تصادفی_۳۲_کاراکتری');
define('DB_NAME', 'username_dating');
define('DB_USER', 'username_dbuser');
define('DB_PASS', 'رمز_دیتابیس');
define('BASE_URL', 'https://yourdomain.com/bale');
define('ADMIN_BALE_ID', شناسه_بله_ادمین);
```

### مرحله ۴: نصب خودکار دیتابیس
به آدرس زیر بروید:
```
https://yourdomain.com/bale/install.php
```
این کار تمام جداول (شامل secret_meeting و conversation_type) را می‌سازد.

### مرحله ۵: تنظیم رمز ادمین
1. به `https://yourdomain.com/bale/admin/setup_password.php` بروید
2. نام کاربری و رمز عبور تنظیم کنید
3. **فایل `setup_password.php` را حذف کنید!**

### مرحله ۶: تنظیم Cron Job (الزامی برای ملاقات ناشناس) ⚠️
بدون cron job، کاربران در صف ملاقات ناشناس گیر می‌کنند و هیچ‌وقت مچ نمی‌شوند.

در cPanel → **Cron Jobs** → اضافه کنید:
```
* * * * * php /home/youruser/public_html/bale/cli/cli_match_maker.php >> /home/youruser/public_html/bale/logs/cron.log 2>&1
```
این دستور هر دقیقه اجرا می‌شود و کاربران در صف را به هم وصل می‌کند.

### مرحله ۷: تنظیم Webhook
به آدرس زیر بروید (SECRET را جایگزین کنید):
```
https://yourdomain.com/bale/webhook/setup.php?secret=YOUR_SECRET&action=set
```

### مرحله ۸: حذف فایل‌های نصب
پس از تکمیل نصب، **این فایل‌ها را حذف کنید**:
- `install.php`
- `admin/setup_password.php`
- `debug.php`, `apitest.php`, `test_webhook.php`, `switch_webhook.php` (در صورت نیاز نگه دارید اما در production حذف کنید)

---

## 🔑 دریافت توکن ربات بله
1. در بله ربات `@BotFather` را جستجو کنید
2. دستور `/newbot` را ارسال کنید
3. نام و یوزرنیم ربات را وارد کنید
4. توکن دریافتی را در `config.php` قرار دهید

---

## ⚙️ Cron Job (الزامی)

فایل `cli/cli_match_maker.php` باید هر دقیقه اجرا شود تا کاربران در صف ملاقات ناشناس به هم وصل شوند.

**روش cPanel:**
1. به **Cron Jobs** در cPanel بروید
2. تنظیمات: `* * * * *` (هر دقیقه)
3. دستور:
```
php -f /home/youruser/public_html/bale/cli/cli_match_maker.php
```

**روش SSH (crontab -e):**
```
* * * * * /usr/bin/php /home/youruser/public_html/bale/cli/cli_match_maker.php >> /home/youruser/public_html/bale/logs/cron.log 2>&1
```

بدون cron job، بخش **🕶 ملاقات مخفیانه** کار نخواهد کرد.

---

## 🎛 پنل مدیریت
آدرس: `https://yourdomain.com/bale/admin/`

امکانات:
- 📊 داشبورد با آمار کاربران
- 👥 مدیریت کاربران (جستجو، مسدود، حذف، VIP)
- 🪙 خزانه سکه (مدیریت موجودی، تراکنش‌ها)
- 🚨 بررسی گزارشات
- 📢 ارسال پیام همگانی
- ⚙ تنظیمات ربات

🔒 تمام فرم‌ها از CSRF token محافظت می‌شوند.

---

## ✨ امکانات ربات

| امکان | توضیح |
|-------|-------|
| ثبت‌نام | دریافت اطلاعات کامل کاربر (نام، سن، جنسیت، استان، بایو، عکس) |
| 🕶 ملاقات مخفیانه | چت ناشناس با کاربر تصادفی (تصادفی/جنسیت/استان) |
| ❤️ پیدا کردن دوست | نمایش پروفایل‌ها مانند Tinder |
| مچ شدن | اطلاع‌رسانی خودکار هنگام مچ |
| چت دو طرفه | پیام‌رسانی بین کاربران مچ شده |
| پروفایل | ویرایش کامل اطلاعات |
| 💎 VIP | عضویت ویژه با امکانات بیشتر |
| 🪙 سکه | سیستم ارز داخلی |
| 🚨 گزارش | گزارش کاربران مشکل‌دار |

---

## 🔒 امنیت

- ✅ تمام کوئری‌ها با PDO Prepared Statements
- ✅ اعتبارسنجی تمام ورودی‌ها
- ✅ محافظت از پوشه config با `.htaccess`
- ✅ جلوگیری از اجرای PHP در `uploads/`
- ✅ ثبت تمام خطاها در `logs/`
- ✅ **CSRF Token** برای تمام فرم‌های پنل ادمین
- ✅ توکن CSRF در session ذخیره می‌شود و با `hash_equals` اعتبارسنجی می‌شود
- ✅ فایل `config.php` در `.gitignore` (هرگز در گیت commit نشود)
- ✅ فایل‌های تست توکن را از `config.php` می‌خوانند (نه هاردکد شده)

---

## 📋 نیازمندی‌ها
- PHP 8.1+
- MySQL 5.7+ یا MariaDB 10.3+
- cURL, PDO, pdo_mysql, mbstring extensions
- SSL (HTTPS) - الزامی برای webhook
- **Cron Job** (برای ملاقات ناشناس)

---

## 🆘 رفع مشکلات

**webhook ثبت نمی‌شود:**
- مطمئن شوید سایت HTTPS دارد
- توکن ربات را بررسی کنید
- لاگ‌ها را در `logs/` بررسی کنید

**ملاقات ناشناس کار نمی‌کند:**
- مطمئن شوید cron job برای `cli/cli_match_maker.php` تنظیم شده
- `logs/cron.log` را بررسی کنید

**خطای دیتابیس:**
- اطلاعات اتصال در `config.php` را بررسی کنید
- مطمئن شوید `install.php` اجرا شده

**ربات پاسخ نمی‌دهد:**
- `https://yourdomain.com/bale/debug.php?key=YOUR_SECRET` را بررسی کنید
- فایل لاگ امروز را در `logs/` بررسی کنید

**پنل ادمین "توکن امنیتی نامعتبر" می‌گوید:**
- session شما منقضی شده. خارج شوید و دوباره لاگین کنید.

---

## 🔄 چangelog

### v1.1.0 — رفع باگ‌های حیاتی
- ✅ فیکس کرش ربات به دلیل کانستراکتور SecretMeetingController
- ✅ فیکس mismatch دکمه `🕶 ملاقات ناشناس/مخفیانه`
- ✅ فیکس mismatch دکمه‌های منوی ملاقات ناشناس (با پرانتز سکه)
- ✅ افزودن هندلر قدم `secret_meeting_gender`
- ✅ افزودن متد `showComingSoon`
- ✅ فیکس `MatchModel::getMessages` با اسکیمای جدید
- ✅ فیکس چت یک‌طرفه (اتوماتیک step طرف مقابل تنظیم می‌شود)
- ✅ آپدیت `install.php` با اسکیمای کامل
- ✅ بهبود Discovery: reset 24h برای دیسلایک‌ها
- ✅ افزودن CSRF protection به پنل ادمین
- ✅ استخراج توکن از فایل‌های تست به config
- ✅ ساخت `config.example.php` و `.gitignore`
