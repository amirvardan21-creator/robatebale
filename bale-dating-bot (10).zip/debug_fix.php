<?php
/**
 * 🔍 فایل دیباگ فfocused برای مشکل "مشاهده پرونده مخاطب" + بررسی کامل ربات
 *
 * آدرس: https://yourdomain.com/bale/debug_fix.php?key=YOUR_WEBHOOK_SECRET
 *
 * این فایل:
 *   ۱. خطاهای اخیر لاگ‌شده (err_*, cb_*) را با جستجوی کد خطا نمایش می‌دهد
 *   ۲. جریان کامل callback مربوط به "مشاهده پرونده مخاطب" را شبیه‌سازی می‌کند
 *   ۳. همه کلاس‌ها/متدها/جداول/ستون‌های مورد نیاز را چک می‌کند
 *   ۴. زمان آخرین تغییر فایل‌ها را نشان می‌دهد (برای تشخیص کد قدیمی روی سرور)
 *   ۵. تمام کاربران گیرکرده در in_secret_meeting / in_queue را لیست می‌کند
 *
 * ⚠️ بعد از رفع مشکل این فایل را حذف کن!
 */

// ============================================================
// ۱. احراز هویت
// ============================================================
$configPath = __DIR__ . '/config/config.php';
$allowedKey = 'xK9mP2qR7nL4wZ3';
if (file_exists($configPath)) {
    $cfg = file_get_contents($configPath);
    if (preg_match("/define\('WEBHOOK_SECRET',\s*'([^']+)'\)/", $cfg, $m)) {
        $allowedKey = $m[1];
    }
}

if (($_GET['key'] ?? '') !== $allowedKey) {
    if (empty($_GET['key'])) {
        $hint = 'https://' . ($_SERVER['HTTP_HOST'] ?? 'yourdomain.com') . $_SERVER['PHP_SELF'] . '?key=' . $allowedKey;
        die("<div style='font-family:Tahoma;direction:rtl;padding:30px;background:#fff3cd;border-radius:8px;max-width:600px;margin:50px auto'>
            <h3>🔑 کلید امنیتی لازم است</h3>
            <p>آدرس را اینطور باز کن:</p>
            <code style='background:#eee;padding:5px 10px;border-radius:4px;display:block;margin-top:10px;direction:ltr'>" . htmlspecialchars($hint) . "</code>
        </div>");
    }
    http_response_code(403);
    die('<h2 style="color:red;font-family:Tahoma;direction:rtl;padding:20px">❌ کلید اشتباه است.</h2>');
}

error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Tehran');

// ============================================================
// ۲. بارگذاری پروژه
// ============================================================
$loadErrors = [];
$requiredFiles = [
    'config/config.php',
    'classes/Database.php', 'classes/Logger.php', 'classes/Bale.php',
    'classes/User.php', 'classes/Profile.php', 'classes/MatchModel.php',
    'classes/Vip.php', 'classes/BlockReport.php', 'classes/Coin.php',
    'classes/Schema.php', 'classes/SecretMeetingQueue.php', 'classes/SecretMeetingRoom.php',
    'controllers/RegisterController.php', 'controllers/DiscoveryController.php',
    'controllers/ProfileController.php', 'controllers/ChatController.php',
    'controllers/SettingsController.php', 'controllers/SecretMeetingController.php',
    'webhook/index.php',
];
foreach ($requiredFiles as $rel) {
    $full = __DIR__ . '/' . $rel;
    if (!file_exists($full)) {
        $loadErrors[] = "MISSING FILE: $rel";
        continue;
    }
    try {
        // فقط config و classes را require کن (webhook/index.php را require نکن چون اجرا می‌کند)
        if ($rel !== 'webhook/index.php') {
            require_once $full;
        }
    } catch (Throwable $e) {
        $loadErrors[] = "LOAD ERROR in $rel: " . $e->getMessage();
    }
}

// ============================================================
// ۳. جمع‌آوری اطلاعات
// ============================================================
$checks = [];
function check(string $title, bool $ok, string $detail = '', string $fix = ''): array {
    return ['title' => $title, 'ok' => $ok, 'detail' => $detail, 'fix' => $fix];
}

// ----- ۳.۱ خطاهای بارگذاری -----
foreach ($loadErrors as $err) {
    $checks[] = check('بارگذاری فایل', false, $err, 'فایل را دوباره آپلود کن');
}

// ----- ۳.۲ بررسی کلاس‌ها و متدهای حیاتی برای جریان view profile -----
$criticalClasses = [
    'Bale'                 => ['sendMessage', 'sendPhoto', 'answerCallbackQuery', 'secretMeetingChatKeyboard', 'mainMenuKeyboard', 'inlineKeyboard'],
    'User'                 => ['findByBaleId', 'findById', 'isBlocked', 'touchLastSeen', 'getStepData', 'updateStep', 'updateUserStatus'],
    'Profile'              => ['findByUserId', 'formatCard'],
    'SecretMeetingRoom'    => ['getRoomById', 'endRoom'],
    'SecretMeetingQueue'   => ['tryMatchUser', 'addToQueue', 'removeFromQueue'],
    'Database'             => ['fetch', 'fetchAll', 'execute', 'insert', 'getInstance'],
    'Logger'               => ['error', 'info'],
    'Schema'               => ['ensureAll', 'ensureSecretMeetingSchema', 'ensureMessagesSchema'],
    'ChatController'       => ['handleCallback'],
    'SecretMeetingController' => ['showMenu', 'handleMenu', 'handleGenderSelection', 'handleProvinceSelection'],
    'Coin'                 => ['getBalance', 'deduct'],
    'BlockReport'          => ['isBlockedEither', 'block', 'report'],
];
foreach ($criticalClasses as $cls => $methods) {
    if (!class_exists($cls)) {
        $checks[] = check("کلاس $cls", false, 'کلاس تعریف نشده', "فایل classes/$cls.php را آپلود کن");
        continue;
    }
    $missing = [];
    foreach ($methods as $m) {
        if (!method_exists($cls, $m)) {
            $missing[] = $m;
        }
    }
    if ($missing) {
        $checks[] = check("متدهای $cls", false, 'متدهای مفقود: ' . implode(', ', $missing), 'نسخه جدید فایل را آپلود کن');
    } else {
        $checks[] = check("کلاس $cls", true, 'همه متدهای حیاتی موجودند');
    }
}

// ----- ۳.۳ اتصال به دیتابیس + بررسی جداول و ستون‌ها -----
$dbOk = false;
$pdo = null;
if (defined('DB_HOST')) {
    try {
        $pdo = new PDO(
            'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
            DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        $dbOk = true;
        $checks[] = check('اتصال به دیتابیس', true, DB_NAME . '@' . DB_HOST);

        // جداول ضروری
        $existingTables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
        $requiredTables = [
            'users', 'profiles', 'likes', 'matches', 'messages',
            'blocked_users', 'reports', 'admins', 'vip_users', 'settings',
            'secret_meeting_rooms', 'secret_meeting_queue', 'coins', 'coin_transactions',
        ];
        foreach ($requiredTables as $tbl) {
            $has = in_array($tbl, $existingTables, true);
            $checks[] = check("جدول $tbl", $has, $has ? 'موجود' : 'مفقود!', $has ? '' : 'migrate.php را اجرا کن');
        }

        // ستون‌های users
        $userCols = $pdo->query("SHOW COLUMNS FROM users")->fetchAll(PDO::FETCH_COLUMN);
        foreach (['current_status', 'current_secret_meeting_room_id', 'last_seen_at', 'step', 'step_data', 'bale_id', 'is_blocked', 'is_active'] as $col) {
            $has = in_array($col, $userCols, true);
            $checks[] = check("users.$col", $has, $has ? 'موجود' : 'مفقود!', $has ? '' : 'migrate.php را اجرا کن');
        }

        // ستون‌های messages
        $msgCols = $pdo->query("SHOW COLUMNS FROM messages")->fetchAll(PDO::FETCH_COLUMN);
        foreach (['conversation_type', 'conversation_id', 'sender_id', 'content', 'deleted_by_user1', 'deleted_by_user2'] as $col) {
            $has = in_array($col, $msgCols, true);
            $checks[] = check("messages.$col", $has, $has ? 'موجود' : 'مفقود!', $has ? '' : 'migrate.php را اجرا کن');
        }

        // ستون‌های profiles
        $profCols = $pdo->query("SHOW COLUMNS FROM profiles")->fetchAll(PDO::FETCH_COLUMN);
        foreach (['user_id', 'name', 'age', 'gender', 'city', 'bio', 'interests', 'looking_for', 'photo_file_id', 'is_visible'] as $col) {
            $has = in_array($col, $profCols, true);
            $checks[] = check("profiles.$col", $has, $has ? 'موجود' : 'مفقود!', $has ? '' : 'database.sql را ایمپورت کن');
        }

        // ستون‌های secret_meeting_rooms
        if (in_array('secret_meeting_rooms', $existingTables, true)) {
            $roomCols = $pdo->query("SHOW COLUMNS FROM secret_meeting_rooms")->fetchAll(PDO::FETCH_COLUMN);
            foreach (['id', 'user1_id', 'user2_id', 'status', 'search_type', 'province_filter', 'gender_filter'] as $col) {
                $has = in_array($col, $roomCols, true);
                $checks[] = check("secret_meeting_rooms.$col", $has, $has ? 'موجود' : 'مفقود!');
            }
            // بررسی مقادیر ENUM معتبر برای status
            $statusCol = $pdo->query("SHOW COLUMNS FROM secret_meeting_rooms LIKE 'status'")->fetch();
            if ($statusCol && preg_match("/enum\(([^)]+)\)/i", $statusCol['Type'], $em)) {
                $enumVals = array_map(fn($v) => trim($v, "'\""), explode(',', $em[1]));
                $requiredEnums = ['active', 'ended_by_user1', 'ended_by_user2', 'ended_mutually', 'aborted'];
                $missingEnums = array_diff($requiredEnums, $enumVals);
                if ($missingEnums) {
                    $checks[] = check('ENUM status در secret_meeting_rooms', false, 'مقادیر مفقود: ' . implode(',', $missingEnums), 'جدول را DROP کن و migrate.php را اجرا کن');
                } else {
                    $checks[] = check('ENUM status در secret_meeting_rooms', true, implode(',', $enumVals));
                }
            }
        }

        // ستون‌های secret_meeting_queue
        if (in_array('secret_meeting_queue', $existingTables, true)) {
            $qCols = $pdo->query("SHOW COLUMNS FROM secret_meeting_queue")->fetchAll(PDO::FETCH_COLUMN);
            foreach (['user_id', 'search_preference', 'gender_preference', 'province_preference', 'vip_priority', 'queued_at', 'last_ping_at'] as $col) {
                $has = in_array($col, $qCols, true);
                $checks[] = check("secret_meeting_queue.$col", $has, $has ? 'موجود' : 'مفقود!');
            }
        }
    } catch (Throwable $e) {
        $checks[] = check('اتصال به دیتابیس', false, $e->getMessage(), 'config.php را بررسی کن');
    }
}

// ----- ۳.۴ کاربران گیرکرده -----
$stuckInMeeting = [];
$stuckInQueue = [];
if ($dbOk) {
    try {
        $stuckInMeeting = $pdo->query("
            SELECT u.id, u.bale_id, u.username, u.current_secret_meeting_room_id, u.step, u.last_seen_at,
                   r.status AS room_status, r.ended_at
            FROM users u
            LEFT JOIN secret_meeting_rooms r ON r.id = u.current_secret_meeting_room_id
            WHERE u.current_status = 'in_secret_meeting'
            ORDER BY u.last_seen_at DESC
            LIMIT 50
        ")->fetchAll(PDO::FETCH_ASSOC);

        $stuckInQueue = $pdo->query("
            SELECT u.id, u.bale_id, u.username, sq.search_preference, sq.gender_preference, sq.province_preference, sq.queued_at, sq.last_ping_at
            FROM secret_meeting_queue sq
            JOIN users u ON u.id = sq.user_id
            ORDER BY sq.queued_at DESC
            LIMIT 50
        ")->fetchAll(PDO::FETCH_ASSOC);

        $checks[] = check(
            'کاربران گیرکرده in_secret_meeting',
            count($stuckInMeeting) === 0,
            count($stuckInMeeting) . ' کاربر',
            count($stuckInMeeting) > 0 ? 'cli/cli_match_maker.php را اجرا کن یا اتاق‌ها را پایان بده' : ''
        );
        $checks[] = check(
            'کاربران در صف',
            count($stuckInQueue) === 0,
            count($stuckInQueue) . ' کاربر در صف',
            ''
        );
    } catch (Throwable $e) {
        $checks[] = check('بررسی کاربران گیرکرده', false, $e->getMessage());
    }
}

// ----- ۳.۵ زمان آخرین تغییر فایل‌های کلیدی -----
$fileTimes = [];
foreach ($requiredFiles as $rel) {
    $full = __DIR__ . '/' . $rel;
    $fileTimes[$rel] = file_exists($full) ? date('Y-m-d H:i:s', filemtime($full)) : 'NOT FOUND';
}

// ----- ۳.۶ جستجوی کد خطا در لاگ‌ها -----
$searchError = trim($_GET['search_err'] ?? '');
$logDir = __DIR__ . '/logs/';
$logFiles = glob($logDir . '*.log') ?: [];
rsort($logFiles);
$foundErrors = [];
$recentErrors = []; // 50 خطای اخیر

if (!empty($logFiles)) {
    // در ۵ لاگ اخیر بگرد
    foreach (array_slice($logFiles, 0, 5) as $logFile) {
        $content = @file_get_contents($logFile);
        if ($content === false) continue;
        $lines = explode("\n", $content);

        foreach ($lines as $line) {
            if (!str_contains($line, '[ERROR]')) continue;

            // اگر کد خطای خاصی درخواست شده
            if ($searchError !== '' && str_contains($line, $searchError)) {
                $foundErrors[] = ['file' => basename($logFile), 'line' => $line];
            }
            // ۵۰ خطای اخیر را نگه دار
            $recentErrors[] = ['file' => basename($logFile), 'line' => $line];
        }
    }
    // فقط ۵۰ خطای اخیر را نگه دار
    $recentErrors = array_slice($recentErrors, -50);
}

// ----- ۳.۷ شبیه‌سازی جریان "مشاهده پرونده مخاطب" -----
$simulationResult = null;
$simulateUserId = (int)($_GET['simulate_user'] ?? 0);

if ($dbOk && $simulateUserId > 0) {
    $simulationResult = ['steps' => [], 'error' => null];
    try {
        // Step 1: پیدا کردن کاربر
        $simUser = User::findById($simulateUserId);
        if (!$simUser) {
            throw new RuntimeException("User id=$simulateUserId یافت نشد");
        }
        $simulationResult['steps'][] = "✅ User found: id={$simUser['id']}, bale_id={$simUser['bale_id']}, status={$simUser['current_status']}, room_id={$simUser['current_secret_meeting_room_id']}";

        // Step 2: بررسی وضعیت in_secret_meeting
        if (($simUser['current_status'] ?? 'idle') !== 'in_secret_meeting' || empty($simUser['current_secret_meeting_room_id'])) {
            $simulationResult['steps'][] = "⚠️ User is NOT in_secret_meeting (status={$simUser['current_status']}). این کاربر در چت فعال نیست.";
        } else {
            $roomId = (int) $simUser['current_secret_meeting_room_id'];
            $room = SecretMeetingRoom::getRoomById($roomId);
            if (!$room) {
                $simulationResult['steps'][] = "❌ Room id=$roomId یافت نشد — کاربر گیرکرده است (orphaned)";
            } elseif ($room['status'] !== 'active') {
                $simulationResult['steps'][] = "❌ Room status='{$room['status']}' (active نیست) — کاربر گیرکرده است";
            } else {
                $partnerId = ((int)$room['user1_id'] === (int)$simUser['id']) ? (int)$room['user2_id'] : (int)$room['user1_id'];
                $simulationResult['steps'][] = "✅ Room active, partner_id=$partnerId";

                // Step 3: پیدا کردن partner
                $partner = User::findById($partnerId);
                if (!$partner) {
                    $simulationResult['steps'][] = "❌ Partner user id=$partnerId یافت نشد در جدول users";
                } else {
                    $simulationResult['steps'][] = "✅ Partner found: id={$partner['id']}, bale_id={$partner['bale_id']}";

                    // Step 4: پیدا کردن پروفایل partner
                    $partnerProfile = Profile::findByUserId($partnerId);
                    if (!$partnerProfile) {
                        $simulationResult['steps'][] = "❌ Profile برای user_id=$partnerId یافت نشد — این علت اصلی خطاست!";
                    } else {
                        $simulationResult['steps'][] = "✅ Partner profile found: name={$partnerProfile['name']}, gender={$partnerProfile['gender']}, photo=" . (empty($partnerProfile['photo_file_id']) ? 'NO' : 'YES');

                        // Step 5: تست formatCard
                        $card = Profile::formatCard($partnerProfile);
                        $simulationResult['steps'][] = "✅ formatCard OK (length=" . strlen($card) . ")";

                        // Step 6: تست ساختن کیبورد (ساخت نمونه Bale فقط برای تست keyboard builder)
                        $bale = new Bale();
                        $keyboard = $bale->secretMeetingChatKeyboard($partnerId, $roomId);
                        $simulationResult['steps'][] = "✅ Keyboard built (callback_data='sm_view_profile_{$partnerId}')";

                        // Step 7: تست answerCallbackQuery (بدون ارسال واقعی — فقط بررسی ساختار)
                        $simulationResult['steps'][] = "✅ همه مراحل جریان view_profile موفق بود. اگر روی سرور خطا می‌دهد، احتمالاً کد قدیمی روی سرور است یا ستونی در DB مفقود است.";
                    }
                }
            }
        }
    } catch (Throwable $e) {
        $simulationResult['error'] = $e->getMessage() . "\n\nFile: " . $e->getFile() . ':' . $e->getLine() . "\n\nTrace:\n" . $e->getTraceAsString();
        $simulationResult['steps'][] = "❌ EXCEPTION: " . $e->getMessage();
    }
}

// ----- ۳.۸ تست مستقیم Bale API -----
$baleApiTest = null;
if (defined('BOT_TOKEN') && BOT_TOKEN !== 'YOUR_BALE_BOT_TOKEN') {
    $ch = curl_init(BALE_API_URL . 'getMe');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => '{}',
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);
    $resp = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);

    if ($err) {
        $baleApiTest = ['ok' => false, 'detail' => 'cURL: ' . $err];
    } else {
        $d = json_decode($resp, true);
        if ($d && !empty($d['ok'])) {
            $baleApiTest = ['ok' => true, 'detail' => 'Bot: ' . ($d['result']['first_name'] ?? '?') . ' @' . ($d['result']['username'] ?? '?')];
        } else {
            $baleApiTest = ['ok' => false, 'detail' => 'Response: ' . $resp];
        }
    }
    $checks[] = check('Bale API getMe', $baleApiTest['ok'], $baleApiTest['detail']);
}

// ----- ۳.۹ Webhook info -----
$webhookInfo = null;
if ($baleApiTest && $baleApiTest['ok']) {
    $ch = curl_init(BALE_API_URL . 'getWebhookInfo');
    curl_setopt_array($ch, [
        CURLOPT_POST => true, CURLOPT_POSTFIELDS => '{}',
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);
    $resp = curl_exec($ch);
    curl_close($ch);
    $d = json_decode($resp, true);
    if ($d && !empty($d['ok'])) {
        $webhookInfo = $d['result'];
        $checks[] = check('Webhook URL ثبت شده', !empty($webhookInfo['url']), $webhookInfo['url'] ?? 'خالی');
        if (!empty($webhookInfo['last_error_message'])) {
            $checks[] = check('آخرین خطای Webhook (از Bale)', false, $webhookInfo['last_error_message'] . ' @ ' . ($webhookInfo['last_error_date'] ?? '?'));
        }
        if (!empty($webhookInfo['pending_update_count']) && $webhookInfo['pending_update_count'] > 0) {
            $checks[] = check('آپدیت‌های در انتظار', false, $webhookInfo['pending_update_count'] . ' آپدیت در صف — احتمالاً webhook 200 برنمی‌گرداند');
        }
    }
}

// ============================================================
// ۴. نمایش نتایج
// ============================================================
$pass = count(array_filter($checks, fn($c) => $c['ok']));
$fail = count(array_filter($checks, fn($c) => !$c['ok']));
$total = count($checks);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>🔍 دیباگ فیکس — ربات بله</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:Tahoma,Arial,sans-serif;background:#f0f2f5;padding:20px;direction:rtl;line-height:1.6}
h1{text-align:center;margin-bottom:5px;color:#1a1a1a}
.subtitle{text-align:center;color:#666;margin-bottom:25px;font-size:13px}
.summary{display:flex;gap:12px;justify-content:center;margin-bottom:25px;flex-wrap:wrap}
.sum-box{padding:12px 24px;border-radius:8px;text-align:center;font-size:20px;font-weight:bold;min-width:100px}
.sum-pass{background:#d4edda;color:#155724}
.sum-fail{background:#f8d7da;color:#721c24}
.sum-total{background:#d1ecf1;color:#0c5460}
.sum-box span{display:block;font-size:11px;font-weight:normal;margin-top:3px}
.section{font-size:14px;font-weight:bold;color:#fff;background:#007bff;padding:8px 12px;border-radius:6px;margin:25px 0 10px}
.item{background:#fff;border-radius:8px;padding:12px 16px;margin-bottom:8px;display:flex;align-items:flex-start;gap:10px;box-shadow:0 1px 3px rgba(0,0,0,.06)}
.icon{font-size:18px;min-width:22px}
.content{flex:1}
.title{font-weight:bold;font-size:13px;margin-bottom:2px}
.detail{font-size:12px;color:#555;word-break:break-all}
.fix{font-size:12px;color:#856404;background:#fff3cd;padding:4px 8px;border-radius:4px;margin-top:4px;display:inline-block}
.log-box{background:#1e1e1e;color:#d4d4d4;padding:15px;border-radius:8px;font-family:Consolas,monospace;font-size:11px;white-space:pre-wrap;max-height:400px;overflow-y:auto;margin-top:10px;direction:ltr;text-align:left}
table{width:100%;border-collapse:collapse;background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.06);font-size:12px}
th,td{padding:8px 10px;text-align:right;border-bottom:1px solid #eee}
th{background:#f8f9fa;font-weight:bold}
tr:hover{background:#f8f9fa}
.search-box{background:#fff;padding:15px;border-radius:8px;margin:15px 0;box-shadow:0 1px 3px rgba(0,0,0,.06)}
.search-box input{padding:8px 12px;border:1px solid #ccc;border-radius:4px;width:300px;font-family:monospace;direction:ltr}
.search-box button{padding:8px 16px;background:#007bff;color:#fff;border:none;border-radius:4px;cursor:pointer;margin-right:5px}
.search-box button:hover{background:#0056b3}
.btn{display:inline-block;padding:8px 16px;background:#28a745;color:#fff;text-decoration:none;border-radius:4px;font-size:12px;margin:3px}
.btn:hover{background:#1e7e34}
.btn-warn{background:#ffc107;color:#000}
.btn-warn:hover{background:#d39e00}
.warning{background:#fff3cd;border:1px solid #ffc107;padding:12px;border-radius:8px;margin-bottom:20px;font-size:13px;color:#856404}
.success{background:#d4edda;border:1px solid #28a745;padding:12px;border-radius:8px;margin-bottom:20px;font-size:13px;color:#155724}
code{background:#f1f1f1;padding:2px 6px;border-radius:3px;font-family:Consolas,monospace;direction:ltr;display:inline-block}
.small{font-size:11px;color:#999}
.sim-step{padding:6px 10px;margin:4px 0;background:#f8f9fa;border-right:3px solid #007bff;border-radius:4px;font-family:Consolas,monospace;font-size:12px;direction:ltr;text-align:left}
.sim-error{padding:10px;background:#f8d7da;border-right:3px solid #dc3545;border-radius:4px;font-family:Consolas,monospace;font-size:12px;direction:ltr;text-align:left;white-space:pre-wrap}
</style>
</head>
<body>

<h1>🔍 دیباگ فیکس ربات بله</h1>
<p class="subtitle">بررسی دقیق مشکل "مشاهده پرونده مخاطب" و خطاهای <code>err_*</code></p>

<div class="warning">⚠️ این فایل اطلاعات حساس ربات را نمایش می‌دهد. بعد از رفع مشکل، حتماً آن را از سرور حذف کن: <code>rm debug_fix.php</code></div>

<div class="summary">
    <div class="sum-box sum-pass"><?= $pass ?><span>✅ موفق</span></div>
    <div class="sum-box sum-fail"><?= $fail ?><span>❌ مشکل</span></div>
    <div class="sum-box sum-total"><?= $total ?><span>🔢 کل</span></div>
</div>

<?php if ($fail === 0): ?>
<div class="success">🎉 همه چیک‌ها سبز است. اگر باز هم خطا می‌گیری، احتمالاً <strong>کد قدیمی روی سرور</strong> است — فایل‌ها را دوباره آپلود کن (به‌خصوص webhook/index.php و controllers/ChatController.php).</div>
<?php else: ?>
<div class="warning">❌ <?= $fail ?> مشکل پیدا شد. موارد قرمز را برطرف کن.</div>
<?php endif; ?>

<!-- ==================== چک‌لیست ==================== -->
<div class="section">📋 چک‌لیست کامل</div>
<?php foreach ($checks as $c): ?>
<div class="item">
    <div class="icon"><?= $c['ok'] ? '✅' : '❌' ?></div>
    <div class="content">
        <div class="title"><?= htmlspecialchars($c['title']) ?></div>
        <?php if ($c['detail']): ?><div class="detail"><?= htmlspecialchars($c['detail']) ?></div><?php endif; ?>
        <?php if (!$c['ok'] && $c['fix']): ?><div class="fix">🔧 <?= htmlspecialchars($c['fix']) ?></div><?php endif; ?>
    </div>
</div>
<?php endforeach; ?>

<!-- ==================== جستجوی کد خطا ==================== -->
<div class="section">🔎 جستجوی کد خطا در لاگ‌ها</div>
<div class="search-box">
    <form method="get">
        <input type="hidden" name="key" value="<?= htmlspecialchars($_GET['key']) ?>">
        <input type="text" name="search_err" placeholder="مثلاً: err_6a655e5fed3087" value="<?= htmlspecialchars($searchError) ?>">
        <button type="submit">🔍 جستجو</button>
        <?php if ($searchError): ?>
            <a href="?key=<?= htmlspecialchars($_GET['key']) ?>" class="btn btn-warn">پاک کردن</a>
        <?php endif; ?>
    </form>
    <div class="small" style="margin-top:8px">کد خطایی که کاربر در بله دیده را اینجا وارد کن تا لاگ کامل آن را ببینیم. جستجو در ۵ فایل لاگ اخیر انجام می‌شود.</div>
</div>

<?php if ($searchError !== ''): ?>
    <?php if (empty($foundErrors)): ?>
        <div class="warning">❌ هیچ خطایی با کد <code><?= htmlspecialchars($searchError) ?></code> در لاگ‌ها پیدا نشد. این یعنی یا لاگ‌ها پاک شده‌اند، یا کد قدیمی روی سرور است که هنوز لاگ نمی‌کرده، یا مسیر logs/ قابل نوشتن نیست.</div>
    <?php else: ?>
        <div class="log-box"><?php foreach ($foundErrors as $e): ?>>> [<?= htmlspecialchars($e['file']) ?>]
<?= htmlspecialchars($e['line']) ?>

<?php endforeach; ?></div>
    <?php endif; ?>
<?php endif; ?>

<!-- ==================== خطاهای اخیر ==================== -->
<div class="section">⚠️ ۵۰ خطای اخیر لاگ‌شده</div>
<?php if (empty($recentErrors)): ?>
<p class="small">هیچ خطایی لاگ نشده. این یعنی یا：<br>
۱. مسیر <code>logs/</code> قابل نوشتن نیست (chmod 755)<br>
۲. هیچ خطایی واقعاً رخ نداده<br>
۳. کد قدیمی روی سرور است که از کلاس Logger استفاده نمی‌کرده</p>
<?php else: ?>
<div class="log-box"><?php foreach ($recentErrors as $e): ?>> [<?= htmlspecialchars($e['file']) ?>] <?= htmlspecialchars($e['line']) ?>

<?php endforeach; ?></div>
<?php endif; ?>

<!-- ==================== شبیه‌سازی view profile ==================== -->
<div class="section">🧪 شبیه‌سازی جریان "مشاهده پرونده مخاطب"</div>
<p class="small">این بخش منطق <code>handleViewProfile</code> را بدون ارسال پیام واقعی اجرا می‌کند تا ببیند کجا شکست می‌خورد.<br>
برای اجرا، آیدی عددی کاربری که خطا می‌گیرد را وارد کن (از جدول پایین یا از <code>users.id</code>):</p>

<div class="search-box">
    <form method="get">
        <input type="hidden" name="key" value="<?= htmlspecialchars($_GET['key']) ?>">
        <input type="number" name="simulate_user" placeholder="user id (مثلاً 5)" value="<?= htmlspecialchars($simulateUserId) ?>">
        <button type="submit">🧪 شبیه‌سازی کن</button>
    </form>
</div>

<?php if ($simulationResult !== null): ?>
    <div style="background:#fff;padding:15px;border-radius:8px;margin-top:10px;box-shadow:0 1px 3px rgba(0,0,0,.06)">
        <?php foreach ($simulationResult['steps'] as $step): ?>
            <div class="sim-step"><?= htmlspecialchars($step) ?></div>
        <?php endforeach; ?>
        <?php if ($simulationResult['error']): ?>
            <div class="sim-error"><?= htmlspecialchars($simulationResult['error']) ?></div>
        <?php endif; ?>
    </div>
<?php endif; ?>

<!-- ==================== کاربران گیرکرده ==================== -->
<?php if (!empty($stuckInMeeting)): ?>
<div class="section">🚨 کاربران گیرکرده در in_secret_meeting (<?= count($stuckInMeeting) ?> نفر)</div>
<table>
    <tr><th>ID</th><th>bale_id</th><th>username</th><th>room_id</th><th>room_status</th><th>step</th><th>last_seen</th><th>action</th></tr>
    <?php foreach ($stuckInMeeting as $u): ?>
    <tr>
        <td><?= $u['id'] ?></td>
        <td><?= htmlspecialchars($u['bale_id']) ?></td>
        <td><?= htmlspecialchars($u['username'] ?? '-') ?></td>
        <td><?= $u['current_secret_meeting_room_id'] ?? '-' ?></td>
        <td><?= htmlspecialchars($u['room_status'] ?? 'NULL') ?></td>
        <td><?= htmlspecialchars($u['step']) ?></td>
        <td><?= htmlspecialchars($u['last_seen_at'] ?? '-') ?></td>
        <td><a href="?key=<?= htmlspecialchars($_GET['key']) ?>&simulate_user=<?= $u['id'] ?>" class="btn">🧪 تست</a></td>
    </tr>
    <?php endforeach; ?>
</table>
<?php endif; ?>

<?php if (!empty($stuckInQueue)): ?>
<div class="section">⏳ کاربران در صف انتظار (<?= count($stuckInQueue) ?> نفر)</div>
<table>
    <tr><th>ID</th><th>bale_id</th><th>username</th><th>search_pref</th><th>gender_pref</th><th>province_pref</th><th>queued_at</th><th>last_ping</th></tr>
    <?php foreach ($stuckInQueue as $u): ?>
    <tr>
        <td><?= $u['id'] ?></td>
        <td><?= htmlspecialchars($u['bale_id']) ?></td>
        <td><?= htmlspecialchars($u['username'] ?? '-') ?></td>
        <td><?= htmlspecialchars($u['search_preference']) ?></td>
        <td><?= htmlspecialchars($u['gender_preference'] ?? '-') ?></td>
        <td><?= htmlspecialchars($u['province_preference'] ?? '-') ?></td>
        <td><?= htmlspecialchars($u['queued_at']) ?></td>
        <td><?= htmlspecialchars($u['last_ping_at']) ?></td>
    </tr>
    <?php endforeach; ?>
</table>
<?php endif; ?>

<!-- ==================== زمان تغییر فایل‌ها ==================== -->
<div class="section">📅 زمان آخرین تغییر فایل‌ها</div>
<p class="small">اگر این تاریخ‌ها قدیمی‌تر از آخرین باری است که فایل آپلود کرده‌ای، یعنی آپلود کامل نشده.</p>
<table>
    <tr><th>فایل</th><th>آخرین تغییر</th></tr>
    <?php foreach ($fileTimes as $rel => $time): ?>
    <tr>
        <td><code><?= htmlspecialchars($rel) ?></code></td>
        <td><?= $time ?></td>
    </tr>
    <?php endforeach; ?>
</table>

<!-- ==================== Webhook info ==================== -->
<?php if ($webhookInfo): ?>
<div class="section">📡 وضعیت Webhook (از Bale)</div>
<table>
    <tr><th>URL</th><td><code><?= htmlspecialchars($webhookInfo['url'] ?? '') ?></code></td></tr>
    <tr><th>pending_updates</th><td><?= $webhookInfo['pending_update_count'] ?? 0 ?></td></tr>
    <tr><th>last_error</th><td><?= htmlspecialchars($webhookInfo['last_error_message'] ?? '-') ?> @ <?= htmlspecialchars($webhookInfo['last_error_date'] ?? '') ?></td></tr>
    <tr><th>max_connections</th><td><?= $webhookInfo['max_connections'] ?? '-' ?></td></tr>
</table>
<?php endif; ?>

<!-- ==================== راهنما ==================== -->
<div class="section">📖 راهنمای تفسیر نتایج</div>
<div style="background:#fff;padding:15px;border-radius:8px;font-size:13px;line-height:1.8">
<p><strong>۱. اگر خطای <code>err_*</code> در لاگ هست ولی شبیه‌سازی سبز است:</strong></p>
<p>کد قدیمی روی سرور است. فایل‌های زیر را حتماً دوباره آپلود کن:<br>
- <code>webhook/index.php</code> (داری try-catch داخلی برای callbackها)<br>
- <code>controllers/ChatController.php</code> (داری try-catch در handleCallback)<br>
- <code>classes/User.php</code>, <code>classes/Profile.php</code>, <code>classes/Bale.php</code></p>

<br>
<p><strong>۲. اگر شبیه‌سازی خطا می‌دهد:</strong></p>
<p>خود شبیه‌سازی می‌گوید کجا شکست خورده. مثلاً:<br>
- <code>Profile برای user_id=X یافت نشد</code> ← partner پروفایل ندارد<br>
- <code>Room status='ended_by_user1'</code> ← کاربر در اتاق گیرکرده، باید cleanup شود<br>
- <code>column not found</code> ← migrate.php را اجرا کن</p>

<br>
<p><strong>۳. اگر هیچ خطایی در لاگ نیست:</strong></p>
<p>مشکل از لاگ‌نویسی است. بررسی کن:<br>
- پوشه <code>logs/</code> وجود دارد و قابل نوشتن است (chmod 755)<br>
- کد قدیمی روی سرور است که از <code>Logger::error</code> استفاده نمی‌کرده</p>

<br>
<p><strong>۴. اگر کاربر در <code>in_secret_meeting</code> گیرکرده ولی اتاق active نیست:</strong></p>
<p>کرون job برای <code>cli/cli_match_maker.php</code> تنظیم کن، یا دستی اجرا کن:<br>
<code>php cli/cli_match_maker.php</code></p>
</div>

<p style="text-align:center;margin-top:20px;font-size:12px;color:#999">
    زمان بررسی: <?= date('Y-m-d H:i:s') ?> |
    <a href="?key=<?= htmlspecialchars($_GET['key']) ?>">🔄 رفرش</a>
</p>

</body>
</html>
