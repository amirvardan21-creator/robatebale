<?php
require_once __DIR__ . '/config/config.php';

$pdo = new PDO(
    'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
    DB_USER,
    DB_PASS,
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
);

$col = $pdo->query("SHOW COLUMNS FROM users LIKE 'last_seen_at'")->fetch();
if (!$col) {
    $pdo->exec('ALTER TABLE users ADD COLUMN last_seen_at TIMESTAMP NULL DEFAULT NULL');
    $pdo->exec('CREATE INDEX idx_last_seen ON users (last_seen_at)');
    echo 'OK - فیلد last_seen_at اضافه شد.';
} else {
    echo 'OK - فیلد last_seen_at از قبل وجود دارد.';
}
