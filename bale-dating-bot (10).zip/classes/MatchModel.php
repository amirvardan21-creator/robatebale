<?php

class MatchModel
{
    public static function addLike(int $fromUserId, int $toUserId, string $action): void
    {
        Database::execute(
            'INSERT INTO likes (from_user_id, to_user_id, action) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE action = ?',
            [$fromUserId, $toUserId, $action, $action]
        );
    }

    public static function checkMutualLike(int $userId1, int $userId2): bool
    {
        $like1 = Database::fetch(
            'SELECT id FROM likes WHERE from_user_id = ? AND to_user_id = ? AND action = "like"',
            [$userId1, $userId2]
        );
        $like2 = Database::fetch(
            'SELECT id FROM likes WHERE from_user_id = ? AND to_user_id = ? AND action = "like"',
            [$userId2, $userId1]
        );
        return $like1 && $like2;
    }

    public static function createMatch(int $userId1, int $userId2): int
    {
        $existing = self::getMatch($userId1, $userId2);
        if ($existing) return $existing['id'];

        $u1 = min($userId1, $userId2);
        $u2 = max($userId1, $userId2);
        return Database::insert(
            'INSERT IGNORE INTO matches (user1_id, user2_id) VALUES (?, ?)',
            [$u1, $u2]
        );
    }

    public static function getMatch(int $userId1, int $userId2): ?array
    {
        $u1 = min($userId1, $userId2);
        $u2 = max($userId1, $userId2);
        return Database::fetch(
            'SELECT * FROM matches WHERE user1_id = ? AND user2_id = ?',
            [$u1, $u2]
        );
    }

    public static function getUserMatches(int $userId): array
    {
        return Database::fetchAll(
            'SELECT m.*, 
                CASE WHEN m.user1_id = ? THEN m.user2_id ELSE m.user1_id END as partner_id,
                p.name as partner_name, p.photo_file_id, p.age, p.city
             FROM matches m
             JOIN profiles p ON p.user_id = CASE WHEN m.user1_id = ? THEN m.user2_id ELSE m.user1_id END
             WHERE (m.user1_id = ? OR m.user2_id = ?) AND m.is_active = 1
             ORDER BY m.created_at DESC',
            [$userId, $userId, $userId, $userId]
        );
    }

    public static function deleteMatch(int $matchId, int $userId): void
    {
        Database::execute(
            'UPDATE matches SET is_active = 0 WHERE id = ? AND (user1_id = ? OR user2_id = ?)',
            [$matchId, $userId, $userId]
        );
    }

    public static function isMatched(int $userId1, int $userId2): bool
    {
        $match = self::getMatch($userId1, $userId2);
        return $match && $match['is_active'] == 1;
    }

    public static function saveMessage(int $conversationId, int $senderId, string $content, string $type = 'text', string $conversationType = 'match'): int
    {
        return Database::insert(
            'INSERT INTO messages (conversation_id, conversation_type, sender_id, content, type) VALUES (?, ?, ?, ?, ?)',
            [$conversationId, $conversationType, $senderId, $content, $type]
        );
    }

    public static function getMessages(int $conversationId, string $conversationType = 'match', int $limit = 20): array
    {
        // Check if new schema (conversation_type column exists)
        try {
            $col = Database::fetch("SHOW COLUMNS FROM messages LIKE 'conversation_type'");
            if ($col) {
                return Database::fetchAll(
                    'SELECT m.*, p.name as sender_name FROM messages m JOIN profiles p ON p.user_id = m.sender_id WHERE m.conversation_type = ? AND m.conversation_id = ? ORDER BY m.created_at DESC LIMIT ?',
                    [$conversationType, $conversationId, $limit]
                );
            }
        } catch (Throwable $e) {
            Logger::error('getMessages schema check failed: ' . $e->getMessage());
        }

        // Fallback to old schema (match_id)
        return Database::fetchAll(
            'SELECT m.*, p.name as sender_name FROM messages m JOIN profiles p ON p.user_id = m.sender_id WHERE m.match_id = ? ORDER BY m.created_at DESC LIMIT ?',
            [$conversationId, $limit]
        );
    }
}
