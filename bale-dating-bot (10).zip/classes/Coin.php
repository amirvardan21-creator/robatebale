<?php

class Coin
{
    private static function tableExists(): bool
    {
        static $exists = null;
        if ($exists !== null) {
            return $exists;
        }

        try {
            $row = Database::fetch("SHOW TABLES LIKE 'coins'");
            $exists = (bool) $row;
        } catch (Throwable $e) {
            Logger::error('Coin table check failed: ' . $e->getMessage());
            $exists = false;
        }

        return $exists;
    }

    public static function getBalance(int $userId): int
    {
        if (!self::tableExists()) {
            return 0;
        }

        try {
            $row = Database::fetch('SELECT balance FROM coins WHERE user_id = ?', [$userId]);
            return $row ? (int)$row['balance'] : 0;
        } catch (Throwable $e) {
            Logger::error('Coin getBalance failed: ' . $e->getMessage());
            return 0;
        }
    }

    public static function add(int $userId, int $amount, string $description = '', ?int $adminId = null): void
    {
        Database::execute(
            'INSERT INTO coins (user_id, balance) VALUES (?, ?) ON DUPLICATE KEY UPDATE balance = balance + ?',
            [$userId, $amount, $amount]
        );
        Database::execute(
            'INSERT INTO coin_transactions (user_id, amount, type, description, admin_id) VALUES (?, ?, "add", ?, ?)',
            [$userId, $amount, $description, $adminId]
        );
    }

    public static function deduct(int $userId, int $amount, string $description = ''): bool
    {
        if (!self::tableExists()) {
            return false;
        }

        try {
            $balance = self::getBalance($userId);
            if ($balance < $amount) return false;
            Database::execute(
                'UPDATE coins SET balance = balance - ? WHERE user_id = ?',
                [$amount, $userId]
            );
            Database::execute(
                'INSERT INTO coin_transactions (user_id, amount, type, description) VALUES (?, ?, "deduct", ?)',
                [$userId, $amount, $description]
            );
            return true;
        } catch (Throwable $e) {
            Logger::error('Coin deduct failed: ' . $e->getMessage());
            return false;
        }
    }

    public static function set(int $userId, int $amount, ?int $adminId = null): void
    {
        $current = self::getBalance($userId);
        Database::execute(
            'INSERT INTO coins (user_id, balance) VALUES (?, ?) ON DUPLICATE KEY UPDATE balance = ?',
            [$userId, $amount, $amount]
        );
        $diff = $amount - $current;
        Database::execute(
            'INSERT INTO coin_transactions (user_id, amount, type, description, admin_id) VALUES (?, ?, "add", ?, ?)',
            [$userId, $diff, 'تنظیم مستقیم توسط ادمین', $adminId]
        );
    }

    public static function getTransactions(int $userId, int $limit = 20): array
    {
        return Database::fetchAll(
            'SELECT * FROM coin_transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT ?',
            [$userId, $limit]
        );
    }

    public static function getTopUsers(int $limit = 10): array
    {
        return Database::fetchAll(
            'SELECT c.*, p.name, u.bale_id FROM coins c JOIN users u ON c.user_id = u.id LEFT JOIN profiles p ON p.user_id = c.user_id ORDER BY c.balance DESC LIMIT ?',
            [$limit]
        );
    }
}
