<?php

class Bale
{
    private string $apiUrl;

    public function __construct()
    {
        $this->apiUrl = BALE_API_URL;
    }

    private function request(string $method, array $params = []): ?array
    {
        $url = $this->apiUrl . $method;

        // reply_markup باید به صورت JSON string ارسال شود
        if (isset($params['reply_markup']) && is_array($params['reply_markup'])) {
            $params['reply_markup'] = json_encode($params['reply_markup'], JSON_UNESCAPED_UNICODE);
        }

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => http_build_query($params),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
        ]);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            Logger::error("[$method] cURL error: $error");
            return null;
        }

        $data = json_decode($response, true);
        if (!$data || !$data['ok']) {
            Logger::error("[$method] API error (HTTP $httpCode): $response");
            return null;
        }

        return $data['result'] ?? null;
    }

    public function sendMessage(int $chatId, string $text, array $replyMarkup = []): ?array
    {
        $params = [
            'chat_id'    => $chatId,
            'text'       => $text,
            'parse_mode' => 'Markdown',
        ];
        if (!empty($replyMarkup)) {
            $params['reply_markup'] = $replyMarkup;
        }
        $result = $this->request('sendMessage', $params);
        // اگر Markdown parsing شکست خورد (carriage return، unmatched asterisk و غیره)،
        // بدون parse_mode دوباره امتحان کن
        if ($result === null) {
            unset($params['parse_mode']);
            $result = $this->request('sendMessage', $params);
        }
        return $result;
    }

    public function sendPhoto(int $chatId, string $photoFileId, string $caption = '', array $replyMarkup = []): ?array
    {
        $params = [
            'chat_id'    => $chatId,
            'photo'      => $photoFileId,
            'caption'    => $caption,
        ];
        if (!empty($caption)) {
            $params['parse_mode'] = 'Markdown';
        }
        if (!empty($replyMarkup)) {
            $params['reply_markup'] = $replyMarkup;
        }
        $result = $this->request('sendPhoto', $params);
        // اگر Markdown شکست خورد، بدون parse_mode دوباره امتحان کن
        if ($result === null && !empty($caption)) {
            unset($params['parse_mode']);
            $result = $this->request('sendPhoto', $params);
        }
        return $result;
    }

    public function editMessageText(int $chatId, int $messageId, string $text, array $replyMarkup = []): ?array
    {
        $params = [
            'chat_id'    => $chatId,
            'message_id' => $messageId,
            'text'       => $text,
        ];
        if (!empty($replyMarkup)) {
            $params['reply_markup'] = $replyMarkup;
        }
        return $this->request('editMessageText', $params);
    }

    public function answerCallbackQuery(string $callbackQueryId, string $text = '', bool $showAlert = false): ?array
    {
        // اگر callback_id خالی است (مثلاً وقتی از reply keyboard آمده‌ایم)،
        // ارسال درخواست بی‌معنی است و خطای API تولید می‌کند — صرفاً null برمی‌گردانیم.
        if ($callbackQueryId === '') {
            return null;
        }
        return $this->request('answerCallbackQuery', [
            'callback_query_id' => $callbackQueryId,
            'text'              => $text,
            'show_alert'        => $showAlert,
        ]);
    }

    public function deleteMessage(int $chatId, int $messageId): ?array
    {
        return $this->request('deleteMessage', [
            'chat_id'    => $chatId,
            'message_id' => $messageId,
        ]);
    }

    public function setWebhook(string $url): ?array
    {
        return $this->request('setWebhook', ['url' => $url]);
    }

    public function deleteWebhook(): ?array
    {
        return $this->request('deleteWebhook');
    }

    public function getWebhookInfo(): ?array
    {
        return $this->request('getWebhookInfo');
    }

    public function getUpdate(): ?array
    {
        $input = file_get_contents('php://input');
        if (empty($input)) return null;
        $data = json_decode($input, true);
        return $data ?: null;
    }

    // Keyboard builders
    public function mainMenuKeyboard(): array
    {
        return [
            'keyboard' => [
                [['text' => '🕶 ملاقات مخفیانه']],
                [['text' => '🔎 جستجوی پیشرفته'], ['text' => '🕴 کاربران مافیایی']],
                [['text' => '💰 ثروت من'], ['text' => '📁 پرونده من'], ['text' => '📖 دفترچه راهنما']],
                [['text' => '🎩 پشتیبانی'], ['text' => '⚖ قوانین مافیا'], ['text' => '🌃 اکسپلور']],
                [['text' => '💎 خرید اشتراک مافیایی'], ['text' => '🏰 اتاق مافیایی من']],
                [['text' => '❤️ پیدا کردن دوست'], ['text' => '💬 گفتگوهای من']],
            ],
            'resize_keyboard'   => true,
            'one_time_keyboard' => false,
        ];
    }

    public function inlineKeyboard(array $buttons): array
    {
        return ['inline_keyboard' => $buttons];
    }

    public function removeKeyboard(): array
    {
        return ['remove_keyboard' => true];
    }

    public function secretMeetingKeyboard(): array
    {
        return [
            'keyboard' => [
                [['text' => '🎲 جستجوی شانسی (0 سکه)']],
                [['text' => '👨 جستجوی پسر (2 سکه)'], ['text' => '👩 جستجوی دختر (2 سکه)']],
                [['text' => '🗺 جستجوی بر اساس استان (4 سکه)']],
                [['text' => '🔙 بازگشت']],
            ],
            'resize_keyboard'   => true,
            'one_time_keyboard' => false,
        ];
    }

    /**
     * کیبورد چت ملاقات مخفیانه — به‌صورت reply keyboard (شیشه‌ای پایین صفحه)
     * برای اینکه دکمه‌ها مزاحم پیام‌ها در صفحه چت نشوند.
     *
     * نکته: Bale در reply keyboard فقط متن دکمه را برای ما می‌فرستد (نه callback_data).
     * بنابراین متن دکمه‌ها را طوری طراحی کردیم که در webhook قابل تشخیص باشند.
     * فرمت: «PREFIX:ID» که PREFIX ثابت است و ID شناسه کاربر یا اتاق است.
     */
    public function secretMeetingChatKeyboard(int $partnerId, int $roomId): array
    {
        return [
            'keyboard' => [
                [['text' => '👤 مشاهده پرونده مخاطب']],
                [['text' => '🎁 هدیه دادن'], ['text' => '🚨 گزارش کاربر']],
                [['text' => '🗑 حذف پیام‌ها'], ['text' => '❌ پایان گفت‌وگو']],
            ],
            'resize_keyboard'   => true,
            'one_time_keyboard' => false,
        ];
    }

    public function provinceKeyboard(): array
    {
        $provinces = [
            'تهران', 'اصفهان', 'فارس', 'خراسان رضوی', 'آذربایجان شرقی',
            'آذربایجان غربی', 'اردبیل', 'البرز', 'ایلام', 'بوشهر',
            'چهارمحال و بختیاری', 'خراسان جنوبی', 'خراسان شمالی', 'خوزستان', 'زنجان',
            'سمنان', 'سیستان و بلوچستان', 'گیلان', 'گلستان', 'همدان',
            'هرمزگان', 'کردستان', 'کرمان', 'کرمانشاه', 'کهگیلویه و بویراحمد',
            'لرستان', 'مازندران', 'مرکزی', 'قزوین', 'قم', 'یزد',
        ];

        $rows = [];
        $row  = [];
        foreach ($provinces as $p) {
            $row[] = ['text' => $p];
            if (count($row) === 2) {
                $rows[] = $row;
                $row = [];
            }
        }
        if ($row) {
            $rows[] = $row;
        }
        $rows[] = [['text' => '🔙 بازگشت']];

        return [
            'keyboard'          => $rows,
            'resize_keyboard'   => true,
            'one_time_keyboard' => true,
        ];
    }
}
