<?php

class BlockReport
{
    public static function block(int $blockerId, int $blockedId): void
    {
        Database::execute(
            'INSERT IGNORE INTO blocked_users (blocker_id, blocked_id) VALUES (?, ?)',
            [$blockerId, $blockedId]
        );
        // Deactivate any existing match
        $u1 = min($blockerId, $blockedId);
        $u2 = max($blockerId, $blockedId);
        Database::execute(
            'UPDATE matches SET is_active = 0 WHERE user1_id = ? AND user2_id = ?',
            [$u1, $u2]
        );
    }

    public static function unblock(int $blockerId, int $blockedId): void
    {
        Database::execute(
            'DELETE FROM blocked_users WHERE blocker_id = ? AND blocked_id = ?',
            [$blockerId, $blockedId]
        );
    }

    public static function isBlocked(int $blockerId, int $blockedId): bool
    {
        $row = Database::fetch(
            'SELECT id FROM blocked_users WHERE blocker_id = ? AND blocked_id = ?',
            [$blockerId, $blockedId]
        );
        return (bool) $row;
    }

    public static function isBlockedEither(int $userId1, int $userId2): bool
    {
        return self::isBlocked($userId1, $userId2) || self::isBlocked($userId2, $userId1);
    }

    public static function report(int $reporterId, int $reportedId, string $reason): void
    {
        Database::execute(
            'INSERT INTO reports (reporter_id, reported_id, reason) VALUES (?, ?, ?)',
            [$reporterId, $reportedId, $reason]
        );
    }

    public static function getPendingReports(): array
    {
        return Database::fetchAll(
            'SELECT r.*, 
                p1.name as reporter_name, p2.name as reported_name,
                u1.bale_id as reporter_bale_id, u2.bale_id as reported_bale_id
             FROM reports r
             JOIN users u1 ON r.reporter_id = u1.id
             JOIN users u2 ON r.reported_id = u2.id
             LEFT JOIN profiles p1 ON p1.user_id = r.reporter_id
             LEFT JOIN profiles p2 ON p2.user_id = r.reported_id
             WHERE r.status = "pending"
             ORDER BY r.created_at DESC'
        );
    }

    public static function updateReportStatus(int $reportId, string $status, ?string $note = null): void
    {
        Database::execute(
            'UPDATE reports SET status = ?, admin_note = ? WHERE id = ?',
            [$status, $note, $reportId]
        );
    }
}
