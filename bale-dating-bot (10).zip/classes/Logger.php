<?php

/**
 * Logger — ثبت رویدادها با fallback امن
 *
 * اگر مسیر logs/ قابل نوشتن نباشد، خطاها در PHP error_log نوشته می‌شوند
 * تا هیچ خطایی گم نشود (مخصوصاً برای دیباگ خطاهای err_ روی سرور).
 */
class Logger
{
    private static ?string $fallbackUsed = null;

    public static function error(string $message): void
    {
        self::write('ERROR', $message);
    }

    public static function info(string $message): void
    {
        self::write('INFO', $message);
    }

    public static function warning(string $message): void
    {
        self::write('WARNING', $message);
    }

    private static function write(string $level, string $message): void
    {
        $line = '[' . date('Y-m-d H:i:s') . '] [' . $level . '] ' . $message . PHP_EOL;

        // تلاش اول: نوشتن در فایل لاگ روزانه
        $logFile = LOG_PATH . date('Y-m-d') . '.log';
        $written = @file_put_contents($logFile, $line, FILE_APPEND | LOCK_EX);

        if ($written !== false) {
            return;
        }

        // fallback: اگر مسیر logs قابل نوشتن نیست، از error_log سیستمی استفاده کن
        // این فقط یک‌بار لاگ می‌شود تا spam نشود
        if (self::$fallbackUsed !== $logFile) {
            self::$fallbackUsed = $logFile;
            error_log("[BaleBot] Logger: cannot write to {$logFile}. Falling back to system error_log. Reason: " . self::lastFileError());
        }
        error_log('[BaleBot][' . $level . '] ' . $message);
    }

    private static function lastFileError(): string
    {
        $err = error_get_last();
        if ($err && isset($err['message'])) {
            return $err['message'];
        }
        return 'unknown';
    }
}
