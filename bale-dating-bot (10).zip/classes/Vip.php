<?php

class Vip
{
    public static function isVip(int $userId): bool
    {
        $vip = Database::fetch(
            'SELECT id FROM vip_users WHERE user_id = ? AND is_active = 1 AND expires_at > NOW()',
            [$userId]
        );
        return (bool) $vip;
    }

    public static function getInfo(int $userId): ?array
    {
        return Database::fetch(
            'SELECT * FROM vip_users WHERE user_id = ? AND is_active = 1',
            [$userId]
        );
    }

    public static function activate(int $userId, string $plan = 'monthly'): void
    {
        $days = match($plan) {
            'quarterly' => 90,
            'yearly'    => 365,
            default     => 30,
        };
        Database::execute(
            'INSERT INTO vip_users (user_id, plan, started_at, expires_at) VALUES (?, ?, NOW(), DATE_ADD(NOW(), INTERVAL ? DAY))
             ON DUPLICATE KEY UPDATE plan = ?, started_at = NOW(), expires_at = DATE_ADD(NOW(), INTERVAL ? DAY), is_active = 1',
            [$userId, $plan, $days, $plan, $days]
        );
    }

    public static function canView(int $userId): bool
    {
        if (self::isVip($userId)) return true;
        Profile::resetDailyCountsIfNeeded($userId);
        $profile = Profile::findByUserId($userId);
        $limit = (int) (Database::fetch('SELECT value FROM settings WHERE `key` = "free_daily_views"')['value'] ?? FREE_DAILY_VIEWS);
        return $profile && $profile['daily_views'] < $limit;
    }

    public static function canLike(int $userId): bool
    {
        if (self::isVip($userId)) return true;
        Profile::resetDailyCountsIfNeeded($userId);
        $profile = Profile::findByUserId($userId);
        $limit = (int) (Database::fetch('SELECT value FROM settings WHERE `key` = "free_daily_likes"')['value'] ?? FREE_DAILY_LIKES);
        return $profile && $profile['daily_likes'] < $limit;
    }
}
