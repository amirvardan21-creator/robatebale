<?php

class User
{
    public static function findByBaleId(int $baleId): ?array
    {
        return Database::fetch('SELECT * FROM users WHERE bale_id = ?', [$baleId]);
    }

    public static function findById(int $id): ?array
    {
        return Database::fetch('SELECT * FROM users WHERE id = ?', [$id]);
    }

    public static function create(int $baleId, string $firstName, ?string $lastName, ?string $username): int
    {
        return Database::insert(
            'INSERT INTO users (bale_id, first_name, last_name, username) VALUES (?, ?, ?, ?)',
            [$baleId, $firstName, $lastName, $username]
        );
    }

    public static function updateStep(int $userId, string $step, ?array $stepData = null): void
    {
        Database::execute(
            'UPDATE users SET step = ?, step_data = ? WHERE id = ?',
            [$step, $stepData ? json_encode($stepData) : null, $userId]
        );
    }

    public static function updateUserStatus(int $userId, string $status, ?int $roomId = null): void
    {
        $sql = 'UPDATE users SET current_status = ?';
        $params = [$status];

        if ($status === 'in_secret_meeting' && $roomId !== null) {
            $sql .= ', current_secret_meeting_room_id = ?';
            $params[] = $roomId;
        } elseif ($status !== 'in_secret_meeting') {
            $sql .= ', current_secret_meeting_room_id = NULL';
        }

        $sql .= ' WHERE id = ?';
        $params[] = $userId;

        Database::execute($sql, $params);
    }

    public static function getStepData(array $user): ?array
    {
        return $user['step_data'] ? json_decode($user['step_data'], true) : null;
    }

    public static function isBlocked(int $userId): bool
    {
        $user = Database::fetch('SELECT is_blocked FROM users WHERE id = ?', [$userId]);
        return $user && $user['is_blocked'] == 1;
    }

    public static function block(int $userId): void
    {
        Database::execute('UPDATE users SET is_blocked = 1 WHERE id = ?', [$userId]);
    }

    public static function unblock(int $userId): void
    {
        Database::execute('UPDATE users SET is_blocked = 0 WHERE id = ?', [$userId]);
    }

    public static function delete(int $userId): void
    {
        Database::execute('DELETE FROM users WHERE id = ?', [$userId]);
    }

    public static function getAll(int $limit = 50, int $offset = 0): array
    {
        return Database::fetchAll(
            'SELECT u.*, p.name, p.age, p.city FROM users u LEFT JOIN profiles p ON u.id = p.user_id ORDER BY u.created_at DESC LIMIT ? OFFSET ?',
            [$limit, $offset]
        );
    }

    public static function count(): int
    {
        $row = Database::fetch('SELECT COUNT(*) as cnt FROM users');
        return (int) ($row['cnt'] ?? 0);
    }

    public static function countActive(): int
    {
        $row = Database::fetch('SELECT COUNT(*) as cnt FROM users WHERE is_active = 1 AND is_blocked = 0');
        return (int) ($row['cnt'] ?? 0);
    }

    public static function search(string $query): array
    {
        return Database::fetchAll(
            'SELECT u.*, p.name, p.age, p.city FROM users u LEFT JOIN profiles p ON u.id = p.user_id WHERE u.bale_id LIKE ? OR u.username LIKE ? OR p.name LIKE ? LIMIT 20',
            ["%$query%", "%$query%", "%$query%"]
        );
    }

    public static function touchLastSeen(int $userId): void
    {
        try {
            if (!self::ensureLastSeenColumn()) {
                return;
            }
            Database::execute('UPDATE users SET last_seen_at = NOW() WHERE id = ?', [$userId]);
        } catch (Throwable $e) {
            Logger::error('touchLastSeen failed: ' . $e->getMessage());
        }
    }

    public static function hasLastSeenColumn(): bool
    {
        return self::ensureLastSeenColumn();
    }

    private static function ensureLastSeenColumn(): bool
    {
        static $ready = null;
        if ($ready !== null) {
            return $ready;
        }

        try {
            $col = Database::fetch("SHOW COLUMNS FROM users LIKE 'last_seen_at'");
            if (!$col) {
                Database::execute('ALTER TABLE users ADD COLUMN last_seen_at TIMESTAMP NULL DEFAULT NULL');
                try {
                    Database::execute('CREATE INDEX idx_last_seen ON users (last_seen_at)');
                } catch (Throwable $e) {
                    // index may already exist
                }
            }
            $ready = true;
        } catch (Throwable $e) {
            Logger::error('ensureLastSeenColumn failed: ' . $e->getMessage());
            $ready = false;
        }

        return $ready;
    }
}
