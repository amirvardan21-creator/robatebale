<?php

/**
 * Schema — ابزار مهاجرت خودکار (Auto-Migration)
 *
 * این کلاس بررسی می‌کند که ستون‌ها/جداول موردنیار برای سیستم ملاقات مخفیانه
 * وجود دارند یا نه؛ در صورت نبودن، آنها را می‌سازد. با این روش، حتی اگر
 * install.php به‌درستی اجرا نشده باشد یا روی MySQL (نه MariaDB) اجرا شود،
 * ربات همچنان کار می‌کند.
 *
 * همه متدها Idempotent هستند — اجرای مکرر آنها مشکلی ایجاد نمی‌کند.
 * همه متدها در صورت خطا Exception پرتاب نمی‌کنند؛ در عوض False برمی‌گردانند
 * و خطا را در log ثبت می‌کنند.
 */
class Schema
{
    private static ?bool $secretMeetingReady = null;
    private static ?bool $messagesReady      = null;

    /**
     * بررسی وجود یک ستون در یک جدول.
     *
     * نکته مهم: از information_schema استفاده می‌کنیم چون MariaDB/MySQL
     * هنگام PDO::ATTR_EMULATE_PREPARES=false از placeholder `?` در
     * `SHOW COLUMNS FROM x LIKE ?` پشتیبانی نمی‌کند.
     */
    public static function columnExists(string $table, string $column): bool
    {
        try {
            $row = Database::fetch(
                "SELECT 1 FROM information_schema.columns
                 WHERE table_schema = DATABASE()
                   AND table_name = ?
                   AND column_name = ?
                 LIMIT 1",
                [$table, $column]
            );
            return (bool) $row;
        } catch (Throwable $e) {
            Logger::error("Schema::columnExists({$table}.{$column}) failed: " . $e->getMessage());
            return false;
        }
    }

    /**
     * بررسی وجود یک جدول.
     *
     * نکته مهم: از information_schema استفاده می‌کنیم چون MariaDB/MySQL
     * هنگام PDO::ATTR_EMULATE_PREPARES=false از placeholder `?` در
     * `SHOW TABLES LIKE ?` پشتیبانی نمی‌کند.
     */
    public static function tableExists(string $table): bool
    {
        try {
            $row = Database::fetch(
                "SELECT 1 FROM information_schema.tables
                 WHERE table_schema = DATABASE()
                   AND table_name = ?
                 LIMIT 1",
                [$table]
            );
            return (bool) $row;
        } catch (Throwable $e) {
            Logger::error("Schema::tableExists({$table}) failed: " . $e->getMessage());
            return false;
        }
    }

    /**
     * افزودن ستون به جدول در صورت عدم وجود.
     */
    public static function ensureColumn(string $table, string $column, string $definition): bool
    {
        if (self::columnExists($table, $column)) {
            return true;
        }
        try {
            Database::execute("ALTER TABLE `{$table}` ADD COLUMN `{$column}` {$definition}");
            Logger::info("Schema: added column {$table}.{$column}");
            return true;
        } catch (Throwable $e) {
            Logger::error("Schema: failed to add column {$table}.{$column}: " . $e->getMessage());
            return false;
        }
    }

    /**
     * ایجاد ایندکس در صورت عدم وجود.
     */
    public static function ensureIndex(string $table, string $indexName, string $columns): bool
    {
        try {
            $exists = Database::fetch(
                "SELECT 1 FROM information_schema.statistics
                 WHERE table_schema = DATABASE()
                   AND table_name = ?
                   AND index_name = ?",
                [$table, $indexName]
            );
            if ($exists) {
                return true;
            }
            Database::execute("CREATE INDEX `{$indexName}` ON `{$table}` ({$columns})");
            Logger::info("Schema: added index {$indexName} on {$table}");
            return true;
        } catch (Throwable $e) {
            // ایندکس ممکن است از قبل وجود داشته باشد (ناشی از race condition)
            return false;
        }
    }

    /**
     * مهاجرت کامل برای جداول و ستون‌های مرتبط با ملاقات مخفیانه.
     * شامل: secret_meeting_rooms, secret_meeting_queue, users.current_status,
     * users.current_secret_meeting_room_id
     *
     * @return bool آیا همه چیز آماده است؟
     */
    public static function ensureSecretMeetingSchema(): bool
    {
        if (self::$secretMeetingReady !== null) {
            return self::$secretMeetingReady;
        }

        $ok = true;

        // جدول secret_meeting_rooms
        if (!self::tableExists('secret_meeting_rooms')) {
            try {
                Database::execute(
                    "CREATE TABLE `secret_meeting_rooms` (
                      `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                      `user1_id` INT UNSIGNED NOT NULL,
                      `user2_id` INT UNSIGNED NOT NULL,
                      `status` ENUM('active','ended_by_user1','ended_by_user2','ended_mutually','aborted') DEFAULT 'active',
                      `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                      `ended_at` TIMESTAMP NULL DEFAULT NULL,
                      `search_type` ENUM('random','gender_male','gender_female','province') NULL DEFAULT NULL,
                      `province_filter` VARCHAR(255) NULL DEFAULT NULL,
                      `gender_filter` ENUM('male','female') NULL DEFAULT NULL,
                      INDEX `idx_status` (`status`)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
                );
                Logger::info('Schema: created table secret_meeting_rooms');
            } catch (Throwable $e) {
                Logger::error('Schema: failed to create secret_meeting_rooms: ' . $e->getMessage());
                $ok = false;
            }
        }

        // جدول secret_meeting_queue
        if (!self::tableExists('secret_meeting_queue')) {
            try {
                Database::execute(
                    "CREATE TABLE `secret_meeting_queue` (
                      `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                      `user_id` INT UNSIGNED NOT NULL UNIQUE,
                      `search_preference` ENUM('random','gender_male','gender_female','province') NOT NULL,
                      `gender_preference` ENUM('male','female') NULL DEFAULT NULL,
                      `province_preference` VARCHAR(255) NULL DEFAULT NULL,
                      `vip_priority` TINYINT(1) DEFAULT 0,
                      `queued_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                      `last_ping_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                      FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
                      INDEX `idx_search_preference` (`search_preference`),
                      INDEX `idx_gender_preference` (`gender_preference`),
                      INDEX `idx_province_preference` (`province_preference`),
                      INDEX `idx_vip_priority` (`vip_priority`)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
                );
                Logger::info('Schema: created table secret_meeting_queue');
            } catch (Throwable $e) {
                Logger::error('Schema: failed to create secret_meeting_queue: ' . $e->getMessage());
                $ok = false;
            }
        }

        // ستون‌های users
        self::ensureColumn('users', 'current_status', "ENUM('idle','in_queue','in_secret_meeting') DEFAULT 'idle'");
        self::ensureColumn('users', 'current_secret_meeting_room_id', 'INT UNSIGNED NULL DEFAULT NULL');
        self::ensureColumn('users', 'last_seen_at', 'TIMESTAMP NULL DEFAULT NULL');
        self::ensureIndex('users', 'idx_last_seen', '`last_seen_at`');
        self::ensureIndex('users', 'idx_current_status', '`current_status`');

        // بررسی نهایی
        $hasColumns = self::columnExists('users', 'current_status')
                   && self::columnExists('users', 'current_secret_meeting_room_id')
                   && self::columnExists('users', 'last_seen_at');
        $hasTables  = self::tableExists('secret_meeting_rooms') && self::tableExists('secret_meeting_queue');

        self::$secretMeetingReady = $ok && $hasColumns && $hasTables;
        return self::$secretMeetingReady;
    }

    /**
     * مهاجرت برای جدول messages: افزودن conversation_type و conversation_id،
     * حذف match_id قدیمی در صورت وجود.
     *
     * @return bool آیا همه چیز آماده است؟
     */
    public static function ensureMessagesSchema(): bool
    {
        if (self::$messagesReady !== null) {
            return self::$messagesReady;
        }

        // اگر جدول messages اصلاً وجود ندارد، ایجاد کن
        if (!self::tableExists('messages')) {
            try {
                Database::execute(
                    "CREATE TABLE `messages` (
                      `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                      `conversation_type` ENUM('match','secret_meeting') NOT NULL DEFAULT 'match',
                      `conversation_id` INT UNSIGNED NOT NULL,
                      `sender_id` INT UNSIGNED NOT NULL,
                      `content` TEXT NOT NULL,
                      `type` ENUM('text','photo') DEFAULT 'text',
                      `deleted_by_user1` TINYINT(1) DEFAULT 0,
                      `deleted_by_user2` TINYINT(1) DEFAULT 0,
                      `is_read` TINYINT(1) DEFAULT 0,
                      `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                      INDEX `idx_conversation` (`conversation_type`, `conversation_id`),
                      INDEX `idx_sender` (`sender_id`),
                      FOREIGN KEY (`sender_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
                );
                Logger::info('Schema: created table messages');
                self::$messagesReady = true;
                return true;
            } catch (Throwable $e) {
                Logger::error('Schema: failed to create messages: ' . $e->getMessage());
                self::$messagesReady = false;
                return false;
            }
        }

        // افزودن ستون‌های جدید در صورت نبودن
        self::ensureColumn('messages', 'conversation_type', "ENUM('match','secret_meeting') DEFAULT 'match'");
        self::ensureColumn('messages', 'conversation_id', 'INT UNSIGNED NULL DEFAULT NULL');
        self::ensureColumn('messages', 'deleted_by_user1', 'TINYINT(1) DEFAULT 0');
        self::ensureColumn('messages', 'deleted_by_user2', 'TINYINT(1) DEFAULT 0');

        // اگر ستون conversation_id به‌صورت NULLABLE ایجاد شده، آن را NOT NULL کن
        // (فقط در صورتی که داده‌ها migration شده باشند)

        // اگر match_id هنوز وجود دارد، داده‌ها را migration کن
        if (self::columnExists('messages', 'match_id')) {
            try {
                // کپی مقادیر match_id به conversation_id
                Database::execute(
                    "UPDATE `messages`
                     SET `conversation_type` = 'match',
                         `conversation_id` = `match_id`
                     WHERE `conversation_id` IS NULL"
                );

                // حذف FK اگر وجود دارد
                $fks = Database::fetchAll(
                    "SELECT CONSTRAINT_NAME FROM information_schema.KEY_COLUMN_USAGE
                     WHERE TABLE_SCHEMA = DATABASE()
                       AND TABLE_NAME = 'messages'
                       AND COLUMN_NAME = 'match_id'
                       AND REFERENCED_TABLE_NAME IS NOT NULL"
                );
                foreach ($fks as $fk) {
                    try {
                        Database::execute("ALTER TABLE `messages` DROP FOREIGN KEY `{$fk['CONSTRAINT_NAME']}`");
                    } catch (Throwable $e) {
                        // ignore
                    }
                }

                // حذف ستون match_id
                Database::execute("ALTER TABLE `messages` DROP COLUMN `match_id`");
                Logger::info('Schema: migrated messages table from match_id to conversation_id');
            } catch (Throwable $e) {
                Logger::error('Schema: failed to migrate messages match_id: ' . $e->getMessage());
            }
        }

        // ایجاد ایندکس conversation
        self::ensureIndex('messages', 'idx_conversation', '`conversation_type`, `conversation_id`');

        $ready = self::columnExists('messages', 'conversation_type')
              && self::columnExists('messages', 'conversation_id');

        self::$messagesReady = $ready;
        return $ready;
    }

    /**
     * اجرای همه مهاجرت‌ها. در ابتدای هر webhook call فراخوانی می‌شود.
     */
    public static function ensureAll(): void
    {
        try {
            self::ensureSecretMeetingSchema();
        } catch (Throwable $e) {
            Logger::error('Schema::ensureSecretMeetingSchema failed: ' . $e->getMessage());
        }
        try {
            self::ensureMessagesSchema();
        } catch (Throwable $e) {
            Logger::error('Schema::ensureMessagesSchema failed: ' . $e->getMessage());
        }
    }
}
