<?php

class SecretMeetingRoom
{
    public static function createRoom(
        int $user1Id,
        int $user2Id,
        string $searchType,
        ?string $provinceFilter,
        ?string $genderFilter
    ): int {
        return Database::insert(
            'INSERT INTO secret_meeting_rooms (user1_id, user2_id, status, search_type, province_filter, gender_filter) VALUES (?, ?, "active", ?, ?, ?)',
            [$user1Id, $user2Id, $searchType, $provinceFilter, $genderFilter]
        );
    }

    public static function getRoomById(int $roomId): ?array
    {
        return Database::fetch('SELECT * FROM secret_meeting_rooms WHERE id = ?', [$roomId]);
    }

    public static function getActiveRoomByUserId(int $userId): ?array
    {
        return Database::fetch(
            'SELECT * FROM secret_meeting_rooms WHERE (user1_id = ? OR user2_id = ?) AND status = "active"',
            [$userId, $userId]
        );
    }

    public static function endRoom(int $roomId, string $endedBy): void
    {
        // $endedBy can be 'user1', 'user2', 'mutually'
        Database::execute(
            'UPDATE secret_meeting_rooms SET status = ?, ended_at = NOW() WHERE id = ?',
            [$endedBy, $roomId]
        );
    }
}
