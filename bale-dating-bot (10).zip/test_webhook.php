<?php
/**
 * تست ساده webhook (توکن از config خوانده می‌شود)
 * آدرس: https://a7vbot.ir/bale/test_webhook.php
 * بعد از تست حذف کن!
 */

require_once __DIR__ . '/config/config.php';

// لاگ همه چیز
$logFile = __DIR__ . '/logs/test_' . date('Y-m-d_H-i-s') . '.txt';
$input = file_get_contents('php://input');
$log = "=== TEST WEBHOOK ===\n";
$log .= "Time: " . date('Y-m-d H:i:s') . "\n";
$log .= "Method: " . $_SERVER['REQUEST_METHOD'] . "\n";
$log .= "Input: " . $input . "\n";
$log .= "Headers: " . json_encode(function_exists('getallheaders') ? getallheaders() : []) . "\n";
file_put_contents($logFile, $log);

// اگر از بله آمد، یک پیام برگردان
if (!empty($input)) {
    $data = json_decode($input, true);
    if ($data && isset($data['message']['from']['id'])) {
        $chatId = $data['message']['from']['id'];

        $ch = curl_init(BALE_API_URL . 'sendMessage');
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => http_build_query([
                'chat_id' => $chatId,
                'text'    => 'webhook کار می‌کند! ✅ پیام دریافت شد.',
            ]),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_SSL_VERIFYPEER => false,
        ]);
        $result = curl_exec($ch);
        curl_close($ch);

        file_put_contents($logFile, "Send result: $result\n", FILE_APPEND);
    }
}

http_response_code(200);
echo 'OK';
