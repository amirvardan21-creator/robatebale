<?php

function h(?string $s): string
{
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}

function adminPageTitle(string $page): string
{
    return match ($page) {
        'dashboard'   => 'داشبورد',
        'users'       => 'مدیریت اعضا',
        'user_detail' => 'پروفایل عضو',
        'reports'     => 'گزارشات',
        'broadcast'   => 'پیام همگانی',
        'settings'    => 'تنظیمات',
        'coins'       => 'خزانه سکه',
        default       => 'مافیا مچ',
    };
}

function formatDate(?string $date): string
{
    if (!$date) return '—';
    return date('Y/m/d H:i', strtotime($date));
}

function genderLabel(?string $gender): string
{
    return match ($gender) {
        'male'   => '👨 مرد',
        'female' => '👩 زن',
        default  => '—',
    };
}

/**
 * تولید و بازیابی توکن CSRF
 */
function csrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * فیلد مخفی CSRF برای فرم‌ها
 */
function csrfField(): string
{
    return '<input type="hidden" name="csrf_token" value="' . csrfToken() . '">';
}

/**
 * اعتبارسنجی توکن CSRF در درخواست‌های POST
 */
function csrfVerify(): bool
{
    $token = $_POST['csrf_token'] ?? '';
    $sessionToken = $_SESSION['csrf_token'] ?? '';
    if (empty($token) || empty($sessionToken)) {
        return false;
    }
    return hash_equals($sessionToken, $token);
}

function tableExists(string $table): bool
{
    try {
        $row = Database::fetch(
            'SELECT COUNT(*) AS cnt FROM information_schema.tables WHERE table_schema = ? AND table_name = ?',
            [DB_NAME, $table]
        );
        return ($row['cnt'] ?? 0) > 0;
    } catch (Throwable) {
        return false;
    }
}

function safeCoinBalance(int $userId): int
{
    if (!tableExists('coins')) return 0;
    try {
        return Coin::getBalance($userId);
    } catch (Throwable) {
        return 0;
    }
}

function safeCoinTransactions(int $userId, int $limit = 15): array
{
    if (!tableExists('coin_transactions')) return [];
    try {
        return Coin::getTransactions($userId, $limit);
    } catch (Throwable) {
        return [];
    }
}

function safeTopCoinUsers(int $limit = 20): array
{
    if (!tableExists('coins')) return [];
    try {
        return Coin::getTopUsers($limit);
    } catch (Throwable) {
        return [];
    }
}

function safeTotalCoins(): int
{
    if (!tableExists('coins')) return 0;
    try {
        $row = Database::fetch('SELECT COALESCE(SUM(balance), 0) AS total FROM coins');
        return (int) ($row['total'] ?? 0);
    } catch (Throwable) {
        return 0;
    }
}
