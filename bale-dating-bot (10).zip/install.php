<?php
/**
 * نصب خودکار دیتابیس — نسخه کامل شامل Secret Meeting + Conversation Schema
 * آدرس: https://a7vbot.ir/bale/install.php
 * بعد از نصب این فایل را حذف کن!
 */

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/classes/Database.php';
require_once __DIR__ . '/classes/Logger.php';

$log = [];
$success = true;

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    $log[] = ['ok', 'اتصال به دیتابیس: ' . DB_NAME];
} catch (PDOException $e) {
    die('<p style="color:red;font-family:Tahoma;direction:rtl">خطای اتصال: ' . htmlspecialchars($e->getMessage()) . '</p>');
}

$tables = [

'users' => "CREATE TABLE IF NOT EXISTS `users` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `bale_id` BIGINT UNSIGNED NOT NULL,
  `username` VARCHAR(100) DEFAULT NULL,
  `first_name` VARCHAR(100) NOT NULL,
  `last_name` VARCHAR(100) DEFAULT NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  `is_blocked` TINYINT(1) DEFAULT 0,
  `step` VARCHAR(50) DEFAULT 'idle',
  `step_data` TEXT DEFAULT NULL,
  `current_status` ENUM('idle','in_queue','in_secret_meeting') DEFAULT 'idle',
  `current_secret_meeting_room_id` INT UNSIGNED NULL DEFAULT NULL,
  `last_seen_at` TIMESTAMP NULL DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_bale_id` (`bale_id`),
  INDEX `idx_is_active` (`is_active`),
  INDEX `idx_last_seen` (`last_seen_at`),
  INDEX `idx_current_status` (`current_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

'profiles' => "CREATE TABLE IF NOT EXISTS `profiles` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `age` TINYINT UNSIGNED NOT NULL,
  `gender` ENUM('male','female') NOT NULL,
  `city` VARCHAR(100) NOT NULL,
  `bio` TEXT DEFAULT NULL,
  `interests` VARCHAR(500) DEFAULT NULL,
  `looking_for` VARCHAR(200) DEFAULT NULL,
  `photo_file_id` VARCHAR(255) DEFAULT NULL,
  `is_visible` TINYINT(1) DEFAULT 1,
  `daily_views` SMALLINT UNSIGNED DEFAULT 0,
  `daily_likes` SMALLINT UNSIGNED DEFAULT 0,
  `last_reset_date` DATE DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_user_id` (`user_id`),
  INDEX `idx_gender` (`gender`),
  INDEX `idx_city` (`city`),
  INDEX `idx_age` (`age`),
  INDEX `idx_visible` (`is_visible`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

'likes' => "CREATE TABLE IF NOT EXISTS `likes` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `from_user_id` INT UNSIGNED NOT NULL,
  `to_user_id` INT UNSIGNED NOT NULL,
  `action` ENUM('like','dislike') NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_like` (`from_user_id`, `to_user_id`),
  INDEX `idx_to_user` (`to_user_id`),
  INDEX `idx_action` (`action`),
  FOREIGN KEY (`from_user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`to_user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

'matches' => "CREATE TABLE IF NOT EXISTS `matches` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user1_id` INT UNSIGNED NOT NULL,
  `user2_id` INT UNSIGNED NOT NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_match` (`user1_id`, `user2_id`),
  INDEX `idx_user1` (`user1_id`),
  INDEX `idx_user2` (`user2_id`),
  FOREIGN KEY (`user1_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`user2_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

// جدول messages با اسکیمای جدید (conversation_type + conversation_id)
'messages' => "CREATE TABLE IF NOT EXISTS `messages` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `conversation_type` ENUM('match','secret_meeting') NOT NULL DEFAULT 'match',
  `conversation_id` INT UNSIGNED NOT NULL,
  `sender_id` INT UNSIGNED NOT NULL,
  `content` TEXT NOT NULL,
  `type` ENUM('text','photo') DEFAULT 'text',
  `deleted_by_user1` TINYINT(1) DEFAULT 0,
  `deleted_by_user2` TINYINT(1) DEFAULT 0,
  `is_read` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_conversation` (`conversation_type`, `conversation_id`),
  INDEX `idx_sender` (`sender_id`),
  FOREIGN KEY (`sender_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

'blocked_users' => "CREATE TABLE IF NOT EXISTS `blocked_users` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `blocker_id` INT UNSIGNED NOT NULL,
  `blocked_id` INT UNSIGNED NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_block` (`blocker_id`, `blocked_id`),
  FOREIGN KEY (`blocker_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`blocked_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

'reports' => "CREATE TABLE IF NOT EXISTS `reports` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `reporter_id` INT UNSIGNED NOT NULL,
  `reported_id` INT UNSIGNED NOT NULL,
  `reason` VARCHAR(255) NOT NULL,
  `status` ENUM('pending','reviewed','resolved') DEFAULT 'pending',
  `admin_note` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_status` (`status`),
  FOREIGN KEY (`reporter_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`reported_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

'admins' => "CREATE TABLE IF NOT EXISTS `admins` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `last_login` TIMESTAMP NULL DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

'vip_users' => "CREATE TABLE IF NOT EXISTS `vip_users` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL,
  `plan` ENUM('monthly','quarterly','yearly') DEFAULT 'monthly',
  `started_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_active` TINYINT(1) DEFAULT 1,
  UNIQUE KEY `unique_user_id` (`user_id`),
  INDEX `idx_expires` (`expires_at`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

'coins' => "CREATE TABLE IF NOT EXISTS `coins` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL,
  `balance` INT UNSIGNED DEFAULT 0,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_user_id` (`user_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

'coin_transactions' => "CREATE TABLE IF NOT EXISTS `coin_transactions` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL,
  `amount` INT NOT NULL,
  `type` ENUM('add','deduct','spend') DEFAULT 'add',
  `description` VARCHAR(255) DEFAULT NULL,
  `admin_id` INT UNSIGNED DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

'secret_meeting_rooms' => "CREATE TABLE IF NOT EXISTS `secret_meeting_rooms` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user1_id` INT UNSIGNED NOT NULL,
  `user2_id` INT UNSIGNED NOT NULL,
  `status` ENUM('active','ended_by_user1','ended_by_user2','ended_mutually','aborted') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `ended_at` TIMESTAMP NULL DEFAULT NULL,
  `search_type` ENUM('random','gender_male','gender_female','province') NULL DEFAULT NULL,
  `province_filter` VARCHAR(255) NULL DEFAULT NULL,
  `gender_filter` ENUM('male','female') NULL DEFAULT NULL,
  FOREIGN KEY (`user1_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`user2_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

'secret_meeting_queue' => "CREATE TABLE IF NOT EXISTS `secret_meeting_queue` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL UNIQUE,
  `search_preference` ENUM('random','gender_male','gender_female','province') NOT NULL,
  `gender_preference` ENUM('male','female') NULL DEFAULT NULL,
  `province_preference` VARCHAR(255) NULL DEFAULT NULL,
  `vip_priority` TINYINT(1) DEFAULT 0,
  `queued_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `last_ping_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_search_preference` (`search_preference`),
  INDEX `idx_gender_preference` (`gender_preference`),
  INDEX `idx_province_preference` (`province_preference`),
  INDEX `idx_vip_priority` (`vip_priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

'settings' => "CREATE TABLE IF NOT EXISTS `settings` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `key` VARCHAR(100) NOT NULL,
  `value` TEXT DEFAULT NULL,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

];

// ساخت جدول‌ها
foreach ($tables as $name => $sql) {
    try {
        $pdo->exec($sql);
        $log[] = ['ok', "جدول $name ساخته شد"];
    } catch (PDOException $e) {
        $log[] = ['err', "خطا در جدول $name: " . $e->getMessage()];
        $success = false;
    }
}

// اضافه کردن ستون‌های جدید به users اگر از قبل وجود داشته ولی قدیمی است
$migrations = [
    "ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `current_status` ENUM('idle','in_queue','in_secret_meeting') DEFAULT 'idle' AFTER `step_data`",
    "ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `current_secret_meeting_room_id` INT UNSIGNED NULL DEFAULT NULL AFTER `current_status`",
    "ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `last_seen_at` TIMESTAMP NULL DEFAULT NULL",
    "ALTER TABLE `messages` ADD COLUMN IF NOT EXISTS `conversation_type` ENUM('match','secret_meeting') DEFAULT 'match' AFTER `id`",
    "ALTER TABLE `messages` ADD COLUMN IF NOT EXISTS `conversation_id` INT UNSIGNED NULL DEFAULT NULL AFTER `conversation_type`",
    "ALTER TABLE `messages` ADD COLUMN IF NOT EXISTS `deleted_by_user1` TINYINT(1) DEFAULT 0",
    "ALTER TABLE `messages` ADD COLUMN IF NOT EXISTS `deleted_by_user2` TINYINT(1) DEFAULT 0",
];
foreach ($migrations as $sql) {
    try { $pdo->exec($sql); } catch (PDOException $e) { /* ignore if exists */ }
}

// ایجاد ایندکس last_seen
try { $pdo->exec('CREATE INDEX IF NOT EXISTS `idx_last_seen` ON `users` (`last_seen_at`)'); } catch (PDOException $e) {}
try { $pdo->exec('CREATE INDEX IF NOT EXISTS `idx_current_status` ON `users` (`current_status`)'); } catch (PDOException $e) {}
try { $pdo->exec('CREATE INDEX IF NOT EXISTS `idx_conversation` ON `messages` (`conversation_type`, `conversation_id`)'); } catch (PDOException $e) {}

// اگر ستون قدیمی match_id هنوز در messages هست، migration کن
try {
    $col = $pdo->query("SHOW COLUMNS FROM messages LIKE 'match_id'")->fetch();
    if ($col) {
        // کپی مقادیر
        $pdo->exec("UPDATE `messages` SET `conversation_type` = 'match', `conversation_id` = `match_id` WHERE `conversation_id` IS NULL");
        // تلاش برای drop FK اگر وجود دارد
        try {
            $fks = $pdo->query("SELECT CONSTRAINT_NAME FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'messages' AND COLUMN_NAME = 'match_id' AND REFERENCED_TABLE_NAME IS NOT NULL")->fetchAll(PDO::FETCH_COLUMN);
            foreach ($fks as $fk) {
                $pdo->exec("ALTER TABLE `messages` DROP FOREIGN KEY `$fk`");
            }
        } catch (PDOException $e) {}
        $pdo->exec("ALTER TABLE `messages` DROP COLUMN `match_id`");
        $log[] = ['ok', 'migration messages از match_id به conversation_id انجام شد'];
    }
} catch (PDOException $e) {
    $log[] = ['err', 'migration messages: ' . $e->getMessage()];
}

// درج داده‌های پیش‌فرض settings
try {
    $count = (int)$pdo->query("SELECT COUNT(*) FROM settings")->fetchColumn();
    if ($count == 0) {
        $pdo->exec("INSERT INTO settings (`key`, `value`) VALUES
            ('bot_active', '1'),
            ('maintenance_message', 'ربات در حال بروزرسانی است، لطفاً بعداً تلاش کنید.'),
            ('free_daily_views', '20'),
            ('free_daily_likes', '10'),
            ('vip_monthly_price', '50000'),
            ('welcome_message', 'به ربات دوستیابی خوش آمدید!')");
        $log[] = ['ok', 'داده‌های پیش‌فرض settings درج شد'];
    } else {
        $log[] = ['ok', 'جدول settings قبلاً داده دارد'];
    }
} catch (PDOException $e) {
    $log[] = ['err', 'خطا در درج settings: ' . $e->getMessage()];
}

// درج ادمین پیش‌فرض
try {
    $count = (int)$pdo->query("SELECT COUNT(*) FROM admins")->fetchColumn();
    if ($count == 0) {
        $hash = password_hash('admin123', PASSWORD_BCRYPT, ['cost' => 10]);
        $stmt = $pdo->prepare("INSERT INTO admins (username, password_hash) VALUES (?, ?)");
        $stmt->execute(['admin', $hash]);
        $log[] = ['ok', 'ادمین پیش‌فرض ساخته شد — یوزر: admin | رمز: admin123'];
    } else {
        $log[] = ['ok', 'ادمین قبلاً وجود دارد'];
    }
} catch (PDOException $e) {
    $log[] = ['err', 'خطا در ادمین: ' . $e->getMessage()];
}

// هدایت کاربران قدیمی به idle (در صورت step معتبر نبودن)
try {
    $pdo->exec("UPDATE users SET step = 'idle' WHERE step IS NULL OR step = ''");
} catch (PDOException $e) {}

?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>نصب دیتابیس</title>
<style>
body{font-family:Tahoma,Arial,sans-serif;background:#f5f5f5;padding:30px;direction:rtl}
.box{max-width:600px;margin:0 auto;background:#fff;border-radius:10px;padding:25px;box-shadow:0 2px 10px rgba(0,0,0,.1)}
h2{margin-bottom:20px;color:#333}
.item{padding:10px 15px;border-radius:6px;margin-bottom:8px;font-size:14px}
.ok{background:#d4edda;color:#155724}
.err{background:#f8d7da;color:#721c24}
.done{background:#d1ecf1;color:#0c5460;padding:20px;border-radius:8px;text-align:center;margin-top:20px;font-size:15px}
.warn{background:#fff3cd;color:#856404;padding:15px;border-radius:8px;margin-top:15px;font-size:13px}
a{color:#007bff}
</style>
</head>
<body>
<div class="box">
    <h2>🛠 نصب دیتابیس ربات بله (نسخه کامل)</h2>

    <?php foreach ($log as [$type, $msg]): ?>
    <div class="item <?= $type ?>">
        <?= $type === 'ok' ? '✅' : '❌' ?> <?= htmlspecialchars($msg) ?>
    </div>
    <?php endforeach; ?>

    <?php if ($success): ?>
    <div class="done">
        🎉 نصب کامل شد!<br><br>
        <strong>قدم بعدی:</strong><br><br>
        ۱. <a href="admin/setup_password.php">رمز ادمین را تنظیم کن</a><br><br>
        ۲. <strong>تنظیم Cron Job برای ملاقات ناشناس (الزامی):</strong><br>
        <code style="direction:ltr;display:block;background:#eee;padding:8px;margin:8px 0">* * * * * php /home/youruser/public_html/bale/cli/cli_match_maker.php >> /home/youruser/public_html/bale/logs/cron.log 2>&1</code><br>
        ۳. در بله به ربات برو و <strong>/start</strong> بفرست<br><br>
        ۴. <strong style="color:red">این فایل (install.php) را حذف کن!</strong>
    </div>
    <div class="warn">
        ⚠️ رمز پیش‌فرض ادمین: <strong>admin123</strong><br>
        حتماً از <a href="admin/setup_password.php">اینجا</a> رمز را عوض کن!
    </div>
    <?php else: ?>
    <div class="item err" style="margin-top:15px">
        ❌ خطاهایی وجود دارد. اطلاعات بالا را بررسی کن.
    </div>
    <?php endif; ?>
</div>
</body>
</html>
