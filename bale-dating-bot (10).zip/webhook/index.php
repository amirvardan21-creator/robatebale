<?php

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../classes/Database.php';
require_once __DIR__ . '/../classes/Logger.php';
require_once __DIR__ . '/../classes/Bale.php';
require_once __DIR__ . '/../classes/User.php';
require_once __DIR__ . '/../classes/Profile.php';
require_once __DIR__ . '/../classes/MatchModel.php';
require_once __DIR__ . '/../classes/Vip.php';
require_once __DIR__ . '/../classes/BlockReport.php';
require_once __DIR__ . '/../classes/Coin.php';
require_once __DIR__ . '/../classes/Schema.php';
require_once __DIR__ . '/../controllers/RegisterController.php';
require_once __DIR__ . '/../controllers/DiscoveryController.php';
require_once __DIR__ . '/../controllers/ProfileController.php';
require_once __DIR__ . '/../controllers/ChatController.php';
require_once __DIR__ . '/../controllers/SettingsController.php';
require_once __DIR__ . '/../controllers/SecretMeetingController.php';
require_once __DIR__ . '/../classes/SecretMeetingQueue.php';
require_once __DIR__ . '/../classes/SecretMeetingRoom.php';

// اجرای مهاجرت‌های خودکار در ابتدای هر webhook (idempotent و safe)
try {
    Schema::ensureAll();
} catch (Throwable $e) {
    Logger::error('Schema migration failed: ' . $e->getMessage());
}

$rawInput = file_get_contents('php://input');

if (empty($rawInput)) {
    http_response_code(200);
    echo 'OK';
    exit;
}

$update = json_decode($rawInput, true);
if (!$update) {
    http_response_code(200);
    exit;
}

$headers = function_exists('getallheaders') ? getallheaders() : [];
if (!empty($headers['X-Bale-Bot-Api-Secret-Token']) && $headers['X-Bale-Bot-Api-Secret-Token'] !== WEBHOOK_SECRET) {
    http_response_code(403);
    exit;
}

$bale = new Bale();

// شناسه یکتا برای این webhook call — برای دیباگ و tracing
$webhookCallId = uniqid('wh_', true);
Logger::info("[{$webhookCallId}] Incoming update: " . substr($rawInput, 0, 500));

try {
    handleUpdate($update, $bale);
} catch (Throwable $e) {
    $errorId = uniqid('err_', true);
    // لاگ با حداکثر context برای دیباگ آسان‌تر
    $updateKind = isset($update['callback_query']) ? 'callback' : (isset($update['message']) ? 'message' : 'unknown');
    $ctxUserId = $update['callback_query']['from']['id'] ?? $update['message']['from']['id'] ?? 'unknown';
    $ctxData = $update['callback_query']['data'] ?? '';
    $ctxText = mb_substr($update['message']['text'] ?? '', 0, 100);
    Logger::error("[{$errorId}] [webhook={$webhookCallId}] [kind={$updateKind} user_id={$ctxUserId} cb_data={$ctxData} msg_text={$ctxText}] Exception: " . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine() . "\nTrace: " . $e->getTraceAsString());
    $chatId = extractChatId($update);
    if ($chatId) {
        try {
            $bale->sendMessage(
                $chatId,
                "⚠️ خطایی رخ داد.\nکد خطا: `{$errorId}`\nلطفاً /start را بزنید یا دوباره تلاش کنید.",
                $bale->mainMenuKeyboard()
            );
        } catch (Throwable $inner) {
            // حتی ارسال پیام خطا هم شکست خورده — فقط لاگ کن
            Logger::error("[{$errorId}] Failed to send error message to user: " . $inner->getMessage());
        }
    }
}

http_response_code(200);

function handleUpdate(array $update, Bale $bale): void
{
    $registerCtrl       = new RegisterController($bale);
    $discoveryCtrl      = new DiscoveryController($bale);
    $profileCtrl        = new ProfileController($bale);
    $chatCtrl           = new ChatController($bale);
    $settingsCtrl       = new SettingsController($bale);
    $secretMeetingCtrl  = new SecretMeetingController($bale, $chatCtrl);

    if (isset($update['callback_query'])) {
        $cb        = $update['callback_query'];
        $from      = $cb['from'];
        // data ممکن است null باشد (callback query بدون data) — جلوگیری از TypeError در str_starts_with
        $data      = $cb['data'] ?? '';
        $cbId      = $cb['id'] ?? '';
        $messageId = $cb['message']['message_id'] ?? 0;

        if ($cbId === '' || $data === '') {
            // بدون callback_id نمی‌توانیم answer کنیم؛ فقط رد شو
            return;
        }

        $user = User::findByBaleId((int)$from['id']);
        if (!$user || User::isBlocked($user['id'])) {
            try { $bale->answerCallbackQuery($cbId, '❌ دسترسی ندارید.', true); } catch (Throwable) {}
            return;
        }

        User::touchLastSeen($user['id']);

        // هر callback handler در try-catch مستقل — اگر یکی شکست خورد، کاربر پیام خطای واضح می‌گیرد
        // و chat state او خراب نمی‌شود (به‌جای err_ عمومی در سطح top-level).
        $handlerError = null;
        try {
            if (str_starts_with($data, 'like_') || str_starts_with($data, 'dislike_') || str_starts_with($data, 'next_')) {
                $discoveryCtrl->handleCallback($user, $cbId, $data, $messageId);
            } elseif (str_starts_with($data, 'profile_') || str_starts_with($data, 'edit_')) {
                $profileCtrl->handleCallback($user, $cbId, $data);
            } elseif (str_starts_with($data, 'chat_') || str_starts_with($data, 'sm_')) {
                // sm_* callbacks مربوط به کیبورد چت ملاقات مخفیانه است (مشاهده پرونده، هدیه، پایان، حذف پیام، گزارش)
                $chatCtrl->handleCallback($user, $cbId, $data);
            } elseif (str_starts_with($data, 'vip_') || str_starts_with($data, 'settings_')) {
                $settingsCtrl->handleCallback($user, $cbId, $data);
            } else {
                $bale->answerCallbackQuery($cbId);
            }
        } catch (Throwable $e) {
            $handlerError = $e;
        }

        if ($handlerError !== null) {
            $errId = uniqid('cb_', true);
            Logger::error("[{$errId}] Callback handler failed (user={$user['id']}, data={$data}): "
                . $handlerError->getMessage()
                . ' in ' . $handlerError->getFile() . ':' . $handlerError->getLine()
                . "\nTrace: " . $handlerError->getTraceAsString());
            try { $bale->answerCallbackQuery($cbId, '❌ خطایی رخ داد. لطفاً دوباره تلاش کنید.', true); } catch (Throwable) {}
            // پیام خطای کوتاه بدون exit کردن chat state (keyboard قبلی کاربر حفظ می‌شود)
            // این sendMessage هم در try-catch تا اگر خودش هم شکست خورد، تبدیل به err_ نشود
            try {
                $bale->sendMessage(
                    (int) $user['bale_id'],
                    "⚠️ یک خطای غیرمنتظره رخ داد.\nکد: `{$errId}`\nلطفاً دوباره تلاش کنید. اگر مشکل ادامه یافت، /start را بزنید."
                );
            } catch (Throwable $sendErr) {
                Logger::error("[{$errId}] Failed to send callback error message to user {$user['id']}: " . $sendErr->getMessage());
            }
        }
        return;
    }

    if (!isset($update['message'])) return;

    $message = $update['message'];
    $from    = $message['from'];
    $chatId  = (int)$from['id'];
    $text    = trim($message['text'] ?? '');
    $photo   = $message['photo'] ?? null;

    $user = User::findByBaleId($chatId);

    $botActive = Database::fetch('SELECT value FROM settings WHERE `key` = "bot_active"');
    if ($botActive && $botActive['value'] == '0' && (!$user || (int)$user['bale_id'] !== ADMIN_BALE_ID)) {
        $msg = Database::fetch('SELECT value FROM settings WHERE `key` = "maintenance_message"');
        $bale->sendMessage($chatId, $msg['value'] ?? 'ربات در حال بروزرسانی است.');
        return;
    }

    if ($text === '/start') {
        if ($user) {
            User::touchLastSeen($user['id']);
        }
        $registerCtrl->start($user, $from);
        return;
    }

    if (!$user) {
        $bale->sendMessage($chatId, 'برای شروع /start را بزنید.');
        return;
    }

    if (User::isBlocked($user['id'])) {
        $bale->sendMessage($chatId, '🚫 حساب شما مسدود شده است.');
        return;
    }

    User::touchLastSeen($user['id']);

    $step = $user['step'];

    if ($text === '/cancel') {
        User::updateStep($user['id'], 'idle');
        $bale->sendMessage($chatId, 'عملیات لغو شد.', $bale->mainMenuKeyboard());
        return;
    }

    if ($step === 'secret_meeting' && ($text === '🔎 جستجوی پیشرفته' || isSecretMeetingCommand($text))) {
        $secretMeetingCtrl->handleMenu($user, $text);
        return;
    }

    if ($step === 'secret_meeting_gender') {
        $secretMeetingCtrl->handleGenderSelection($user, $text);
        return;
    }

    if ($step === 'secret_meeting_province') {
        $secretMeetingCtrl->handleProvinceSelection($user, $text);
        return;
    }

    if (isMainMenuCommand($text)) {
        if ($step !== 'idle') {
            User::updateStep($user['id'], 'idle');
        }
        handleMainMenuCommand($text, $user, $bale, $discoveryCtrl, $profileCtrl, $chatCtrl, $settingsCtrl, $secretMeetingCtrl);
        return;
    }

    if (isSecretMeetingCommand($text)) {
        if ($step === 'chatting') {
            User::updateStep($user['id'], 'idle');
        }
        $secretMeetingCtrl->handleMenu($user, $text);
        return;
    }

    if (str_starts_with($step, 'register_')) {
        $registerCtrl->handle($user, $text, $photo);
        return;
    }

    if (str_starts_with($step, 'editing_') || $step === 'update_photo' || $step === 'edit_field') {
        $profileCtrl->handleEdit($user, $text, $photo);
        return;
    }

    // دکمه‌های کیبورد شیشه‌ای چت ملاقات مخفیانه — این دکمه‌ها به‌جای callback_data،
    // متن ثابت می‌فرستند. قبل از رفتن به حالت chatting، آن‌ها را به callback معادل
    // تبدیل می‌کنیم و به ChatController می‌سپاریم.
    if (isSecretMeetingChatButton($text)) {
        $syntheticCbData = resolveSecretMeetingChatButton($user, $text);
        if ($syntheticCbData !== null) {
            // callback_id خالی — ChatController و Bale::answerCallbackQuery این حالت را امن مدیریت می‌کنند
            $chatCtrl->handleCallback($user, '', $syntheticCbData);
            return;
        }
        // اگر نتوانستیم context را حل کنیم، به کاربر اطلاع می‌دهیم
        $bale->sendMessage($chatId, '⚠️ ابتدا وارد یک گفتگو شوید.', $bale->mainMenuKeyboard());
        return;
    }

    if ($step === 'chatting') {
        if ($text === '🔙 بازگشت') {
            User::updateStep($user['id'], 'idle');
            $bale->sendMessage($chatId, 'بازگشت به منو.', $bale->mainMenuKeyboard());
            return;
        }
        if ($text === '') {
            $bale->sendMessage($chatId, 'لطفاً پیام خود را بنویسید یا از دکمه 🔙 بازگشت استفاده کنید.');
            return;
        }
        $chatCtrl->sendChatMessage($user, $text);
        return;
    }

    if ($step === 'report_id' || $step === 'report_reason') {
        $settingsCtrl->handleReport($user, $text);
        return;
    }

    $profile = Profile::findByUserId($user['id']);
    if (!$profile) {
        $registerCtrl->start($user, $from);
        return;
    }

    $bale->sendMessage($chatId, 'از منوی زیر انتخاب کنید:', $bale->mainMenuKeyboard());
}

function isMainMenuCommand(string $text): bool
{
    return in_array($text, getMainMenuCommands(), true);
}

function isSecretMeetingCommand(string $text): bool
{
    foreach (getSecretMeetingCommands() as $cmd) {
        if (str_starts_with($text, $cmd)) {
            return true;
        }
    }
    return false;
}

function getMainMenuCommands(): array
{
    return array_merge([
        '🕶 ملاقات مخفیانه',
        '🔎 جستجوی پیشرفته',
        '🕴 کاربران مافیایی',
        '💰 ثروت من',
        '📁 پرونده من',
        '📖 دفترچه راهنما',
        '🎩 پشتیبانی',
        '⚖ قوانین مافیا',
        '🌃 اکسپلور',
        '💎 خرید اشتراک مافیایی',
        '🏰 اتاق مافیایی من',
    ], getLegacyMenuCommands());
}

function getLegacyMenuCommands(): array
{
    return [
        '❤️ پیدا کردن دوست',
        '👤 پروفایل من',
        '💬 گفتگوهای من',
        '⭐ عضویت ویژه',
        '⚙ تنظیمات',
        '🚨 گزارش کاربر',
    ];
}

function getSecretMeetingCommands(): array
{
    return [
        '🎲 جستجوی شانسی',
        '👨 جستجوی پسر',
        '👩 جستجوی دختر',
        '🗺 جستجوی بر اساس استان',
        '🔙 بازگشت',
    ];
}

function handleMainMenuCommand(
    string $text,
    array $user,
    Bale $bale,
    DiscoveryController $discoveryCtrl,
    ProfileController $profileCtrl,
    ChatController $chatCtrl,
    SettingsController $settingsCtrl,
    SecretMeetingController $secretMeetingCtrl
): void {
    $chatId = (int) $user['bale_id'];

    switch ($text) {
        case '🕶 ملاقات مخفیانه':
            $secretMeetingCtrl->showMenu($user);
            break;
        case '🔎 جستجوی پیشرفته':
            $secretMeetingCtrl->showComingSoon($user, true);
            break;
        case '📁 پرونده من':
        case '👤 پروفایل من':
            $profileCtrl->show($user);
            break;
        case '💎 خرید اشتراک مافیایی':
        case '⭐ عضویت ویژه':
            $settingsCtrl->showVip($user);
            break;
        case '🎩 پشتیبانی':
        case '⚙ تنظیمات':
            $settingsCtrl->show($user);
            break;
        case '💰 ثروت من':
            $balance = Coin::getBalance($user['id']);
            $bale->sendMessage($chatId, "💰 *ثروت شما:* {$balance} سکه", $bale->mainMenuKeyboard());
            break;
        case '📖 دفترچه راهنما':
            $bale->sendMessage(
                $chatId,
                "📖 *راهنمای ربات مافیا مچ*\n\n"
                . "🕶 *ملاقات مخفیانه:* چت ناشناس با کاربر تصادفی\n"
                . "🔎 *جستجوی پیشرفته:* فیلتر بر اساس سن و علایق (به‌زودی)\n"
                . "❤️ *پیدا کردن دوست:* مشاهده پروفایل‌ها و مچ\n"
                . "💬 *گفتگوهای من:* لیست مچ‌های فعال\n"
                . "💰 *ثروت من:* موجودی سکه\n"
                . "📁 *پرونده من:* ویرایش پروفایل\n"
                . "💎 *اشتراک مافیایی:* خرید VIP\n\n"
                . "برای شروع کافیست یکی از گزینه‌های بالا را انتخاب کنید.",
                $bale->mainMenuKeyboard()
            );
            break;
        case '⚖ قوانین مافیا':
            $bale->sendMessage(
                $chatId,
                "⚖ *قوانین مافیا مچ*\n\n"
                . "۱. احترام متقابل الزامی است\n"
                . "۲. ارسال محتوای نامناسب ممنوع\n"
                . "۳. تبلیغات و هرزنامه ممنوع\n"
                . "۴. گزارش تخلفات از طریق دکمه 🚨 گزارش کاربر\n\n"
                . "تخلف از قوانین باعث مسدود شدن حساب خواهد شد.",
                $bale->mainMenuKeyboard()
            );
            break;
        case '🌃 اکسپلور':
        case '🕴 کاربران مافیایی':
        case '🏰 اتاق مافیایی من':
            $bale->sendMessage($chatId, '🚧 این بخش به‌زودی فعال می‌شود.', $bale->mainMenuKeyboard());
            break;
        case '❤️ پیدا کردن دوست':
            $discoveryCtrl->showNext($user);
            break;
        case '💬 گفتگوهای من':
            $chatCtrl->showMatches($user);
            break;
        case '🚨 گزارش کاربر':
            $settingsCtrl->startReport($user);
            break;
        default:
            $bale->sendMessage($chatId, 'این بخش به‌زودی فعال می‌شود.', $bale->mainMenuKeyboard());
            break;
    }
}

function extractChatId(array $update): ?int
{
    if (isset($update['message']['from']['id'])) {
        return (int) $update['message']['from']['id'];
    }
    if (isset($update['callback_query']['from']['id'])) {
        return (int) $update['callback_query']['from']['id'];
    }
    return null;
}

/**
 * آیا این متن یکی از دکمه‌های کیبورد شیشه‌ای چت ملاقات مخفیانه است؟
 */
function isSecretMeetingChatButton(string $text): bool
{
    return in_array($text, [
        '👤 مشاهده پرونده مخاطب',
        '🎁 هدیه دادن',
        '❌ پایان گفت‌وگو',
        '🗑 حذف پیام‌ها',
        '🚨 گزارش کاربر',
    ], true);
}

/**
 * تبدیل متن دکمه شیشه‌ای به callback_data معادل.
 * برای این کار باید partner_id و room_id فعلی کاربر را از context استخراج کنیم.
 *
 * @return string|null  callback_data معادل یا null اگر context نامعتبر بود
 */
function resolveSecretMeetingChatButton(array $user, string $text): ?string
{
    $partnerId = 0;
    $roomId    = 0;

    // حالت ۱: در ملاقات مخفیانه فعال
    if (($user['current_status'] ?? 'idle') === 'in_secret_meeting'
        && !empty($user['current_secret_meeting_room_id'])) {
        try {
            $room = SecretMeetingRoom::getRoomById((int) $user['current_secret_meeting_room_id']);
            if ($room && $room['status'] === 'active') {
                $roomId = (int) $room['id'];
                $partnerId = ((int) $room['user1_id'] === (int) $user['id'])
                    ? (int) $room['user2_id']
                    : (int) $room['user1_id'];
            }
        } catch (Throwable $e) {
            Logger::error('resolveSecretMeetingChatButton: failed to load room: ' . $e->getMessage());
        }
    }

    // حالت ۲: در مچ معمولی (step_data)
    if ($partnerId === 0) {
        $stepData = User::getStepData($user);
        if (!empty($stepData['partner_id'])) {
            $partnerId = (int) $stepData['partner_id'];
        }
        if (!empty($stepData['match_id'])) {
            $roomId = (int) $stepData['match_id'];
        }
    }

    if ($partnerId === 0) {
        return null;
    }

    return match ($text) {
        '👤 مشاهده پرونده مخاطب' => 'sm_view_profile_' . $partnerId,
        '🎁 هدیه دادن'           => 'sm_gift_' . $partnerId,
        '🚨 گزارش کاربر'         => 'sm_report_user_' . $partnerId,
        '🗑 حذف پیام‌ها'         => $roomId > 0 ? 'sm_delete_messages_' . $roomId : null,
        '❌ پایان گفت‌وگو'       => $roomId > 0 ? 'sm_end_chat_' . $roomId : null,
        default                  => null,
    };
}