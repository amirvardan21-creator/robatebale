<?php
/**
 * Webhook Setup Script
 * Run once to register webhook with Bale
 * Access: https://yourdomain.com/bale-dating-bot/webhook/setup.php?secret=YOUR_WEBHOOK_SECRET
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../classes/Bale.php';
require_once __DIR__ . '/../classes/Logger.php';

$secret = $_GET['secret'] ?? '';
if ($secret !== WEBHOOK_SECRET) {
    http_response_code(403);
    die('Forbidden');
}

$bale = new Bale();
$action = $_GET['action'] ?? 'set';

if ($action === 'set') {
    $webhookUrl = BASE_URL . '/webhook/index.php';
    $result = $bale->setWebhook($webhookUrl);
    echo '<pre>';
    echo "Webhook URL: $webhookUrl\n";
    echo "Result: " . json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    echo '</pre>';
} elseif ($action === 'delete') {
    $result = $bale->deleteWebhook();
    echo '<pre>Delete result: ' . json_encode($result, JSON_PRETTY_PRINT) . '</pre>';
} elseif ($action === 'info') {
    $result = $bale->getWebhookInfo();
    echo '<pre>Webhook info: ' . json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . '</pre>';
}
