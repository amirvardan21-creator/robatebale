<?php
/**
 * تست مستقیم API بله (تنظیمات از config.php خوانده می‌شود)
 * آدرس: https://a7vbot.ir/bale/apitest.php?key=WEBHOOK_SECRET
 */

require_once __DIR__ . '/config/config.php';

if (($_GET['key'] ?? '') !== WEBHOOK_SECRET) {
    die('forbidden');
}

$token   = BOT_TOKEN;
$baseUrl = BALE_API_URL;

function baleCall(string $token, string $method, array $params = []): array {
    $ch = curl_init("https://tapi.bale.ai/bot{$token}/{$method}");
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => http_build_query($params),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 10,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
    ]);
    $res = curl_exec($ch);
    $err = curl_error($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['response' => $res, 'curl_error' => $err, 'http_code' => $code];
}

$results = [];

// ۱. getMe
$r = baleCall($token, 'getMe');
$results[] = ['title' => 'getMe — اطلاعات ربات', 'data' => $r];

// ۲. getWebhookInfo
$r = baleCall($token, 'getWebhookInfo');
$results[] = ['title' => 'getWebhookInfo — وضعیت webhook', 'data' => $r];

// ۳. ارسال پیام تست (اگر chat_id وارد شده)
$testChatId = $_GET['chat_id'] ?? '';
if ($testChatId) {
    $r = baleCall($token, 'sendMessage', [
        'chat_id' => $testChatId,
        'text'    => '✅ تست ارسال پیام موفق بود! ربات کار می‌کند.',
    ]);
    $results[] = ['title' => "sendMessage به chat_id: $testChatId", 'data' => $r];
}

// ۴. getUpdates (بدون webhook)
$r = baleCall($token, 'getUpdates', ['limit' => 5, 'timeout' => 0]);
$results[] = ['title' => 'getUpdates — آخرین پیام‌ها', 'data' => $r];

?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<title>تست API بله</title>
<style>
body{font-family:Tahoma;background:#f5f5f5;padding:20px;direction:rtl}
.box{background:#fff;border-radius:8px;padding:20px;margin-bottom:15px;box-shadow:0 1px 5px rgba(0,0,0,.1)}
h3{margin:0 0 10px;color:#333;font-size:15px}
pre{background:#1e1e1e;color:#d4d4d4;padding:12px;border-radius:6px;font-size:12px;overflow-x:auto;white-space:pre-wrap;direction:ltr;text-align:left}
.ok{border-right:4px solid #28a745}
.err{border-right:4px solid #dc3545}
.form{background:#fff3cd;padding:15px;border-radius:8px;margin-bottom:15px}
input{padding:8px;border:1px solid #ddd;border-radius:4px;width:200px}
button{padding:8px 16px;background:#007bff;color:#fff;border:none;border-radius:4px;cursor:pointer}
</style>
</head>
<body>
<h2>🔬 تست مستقیم API بله</h2>

<div class="form">
    <strong>ارسال پیام تست به خودت:</strong><br><br>
    <form method="GET">
        <input type="hidden" name="key" value="<?= htmlspecialchars(WEBHOOK_SECRET) ?>">
        شناسه بله خودت را وارد کن:
        <input type="text" name="chat_id" value="<?= htmlspecialchars($testChatId) ?>" placeholder="مثلاً: 123456789">
        <button type="submit">ارسال پیام تست</button>
    </form>
    <small style="color:#666;display:block;margin-top:8px">
        شناسه بله خودت را از ربات @myidbot بگیر
    </small>
</div>

<?php foreach ($results as $item):
    $decoded = json_decode($item['data']['response'], true);
    $isOk = $decoded && ($decoded['ok'] ?? false);
    $hasError = !empty($item['data']['curl_error']);
?>
<div class="box <?= ($isOk && !$hasError) ? 'ok' : 'err' ?>">
    <h3><?= $isOk ? '✅' : '❌' ?> <?= htmlspecialchars($item['title']) ?></h3>
    <?php if ($hasError): ?>
    <pre style="background:#f8d7da;color:#721c24">cURL Error: <?= htmlspecialchars($item['data']['curl_error']) ?></pre>
    <?php endif; ?>
    <pre><?= htmlspecialchars(json_encode($decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) ?></pre>
</div>
<?php endforeach; ?>

</body>
</html>
