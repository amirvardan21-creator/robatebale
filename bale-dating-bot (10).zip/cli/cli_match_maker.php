<?php

// cli/cli_match_maker.php
//
// پردازشگر صف ملاقات ناشناس — به‌عنوان پشتیبان (fallback) برای زمانی که
// مچ کردن real-time در webhook انجام نشده باشد.
//
// توصیه: این فایل هر دقیقه با cron اجرا شود:
//   * * * * * php /home/youruser/public_html/bale/cli/cli_match_maker.php >> /home/youruser/public_html/bale/logs/cron.log 2>&1
//
// مهم: در حالت عادی، مچ کردن در همان لحظه‌ای که کاربر جدید وارد صف می‌شود
// (توسط webhook) انجام می‌شود. این cron فقط برای موارد زیر است:
//   ۱. پاکسازی صف از کاربرانی که آفلاین شده‌اند.
//   ۲. پاکسازی وضعیت‌های یتیم (کاربری که در in_secret_meeting گیر کرده ولی اتاقش تمام شده).
//   ۳. تلاش مجدد برای مچ کردن کاربرانی که هنوز در صف هستند.

if (php_sapi_name() !== 'cli') {
    die("This script can only be run from the command line.\n");
}

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../classes/Database.php';
require_once __DIR__ . '/../classes/Logger.php';
require_once __DIR__ . '/../classes/Bale.php';
require_once __DIR__ . '/../classes/User.php';
require_once __DIR__ . '/../classes/Profile.php';
require_once __DIR__ . '/../classes/Vip.php';
require_once __DIR__ . '/../classes/Coin.php';
require_once __DIR__ . '/../classes/Schema.php';
require_once __DIR__ . '/../classes/SecretMeetingQueue.php';
require_once __DIR__ . '/../classes/SecretMeetingRoom.php';
require_once __DIR__ . '/../controllers/ChatController.php';

// اجرای مهاجرت‌های خودکار
try {
    Schema::ensureAll();
} catch (Throwable $e) {
    Logger::error('cli_match_maker: Schema migration failed: ' . $e->getMessage());
}

echo "[" . date('Y-m-d H:i:s') . "] Match Maker started.\n";
Logger::info('cli_match_maker: started');

$bale = new Bale();

// ۱. پاکسازی کاربران stale از صف
$staleCount = SecretMeetingQueue::cleanStaleEntries();
echo "Cleaned $staleCount stale queue entries.\n";

// ۲. پاکسازی وضعیت‌های یتیم
$orphanCount = SecretMeetingQueue::cleanOrphanedStatuses();
echo "Cleaned $orphanCount orphaned statuses.\n";

// ۳. تلاش برای مچ کردن کاربران باقی‌مانده در صف
$queuedUsers = Database::fetchAll(
    'SELECT user_id FROM secret_meeting_queue ORDER BY user_id ASC'
);

if (empty($queuedUsers)) {
    echo "No users in queue. Exiting.\n";
    Logger::info('cli_match_maker: no users in queue, exiting');
    exit;
}

echo "Found " . count($queuedUsers) . " users in queue.\n";
Logger::info('cli_match_maker: processing ' . count($queuedUsers) . ' queued users');

$matchedPairs = 0;
$notifiedUsers = 0;

foreach ($queuedUsers as $row) {
    $userId = (int) $row['user_id'];

    // بررسی اینکه کاربر هنوز در صف است یا خیر (ممکن است توسط تلاش قبلی مچ شده باشد)
    $user = User::findById($userId);
    if (!$user || $user['current_status'] !== 'in_queue') {
        // اگر در صف نیست ولی ردیف در secret_meeting_queue باقی مانده، پاک کن
        SecretMeetingQueue::removeFromQueue($userId);
        continue;
    }

    // تلاش برای مچ کردن
    $match = SecretMeetingQueue::tryMatchUser($userId);

    if (!$match) {
        echo "No match found for user $userId. Staying in queue.\n";
        continue;
    }

    $roomId       = (int) $match['room_id'];
    $partnerId    = (int) $match['partner_user_id'];
    $partnerBale  = (int) $match['partner_bale_id'];
    $myBaleId     = (int) $match['my_bale_id'];

    echo "Matched user $userId with $partnerId in room $roomId.\n";
    Logger::info("cli_match_maker: matched $userId <-> $partnerId in room $roomId");

    $matchedPairs++;

    $message = "🕶 *اتصال موفقیت‌آمیز*\n\n"
             . "یک عضو جدید از خانواده مافیا برای ملاقات مخفیانه شما پیدا شد.\n"
             . "اکنون می‌توانید گفتگوی خصوصی خود را آغاز کنید.\n\n"
             . "⚠️ پیام‌های شما کاملاً ناشناس است. برای پایان گفتگو از دکمه زیر استفاده کنید.";

    // پیام به کاربر آغازگر
    $bale->sendMessage(
        $myBaleId,
        $message,
        $bale->secretMeetingChatKeyboard($partnerId, $roomId)
    );

    // پیام به طرف مقابل
    $bale->sendMessage(
        $partnerBale,
        $message,
        $bale->secretMeetingChatKeyboard($userId, $roomId)
    );

    $notifiedUsers += 2;
}

echo "[" . date('Y-m-d H:i:s') . "] Match Maker finished. Matched $matchedPairs pairs, notified $notifiedUsers users.\n";
Logger::info("cli_match_maker: finished, matched $matchedPairs pairs, notified $notifiedUsers users");

exit;
