<?php
/**
 * صفحه تشخیص مشکل ربات بله
 * آدرس: https://yourdomain.com/bale/debug.php?key=YOUR_WEBHOOK_SECRET
 * بعد از رفع مشکل این فایل را حذف کن!
 */

// کلید امنیتی - از config خوانده میشود
$configPath = __DIR__ . '/config/config.php';
$allowedKey = 'xK9mP2qR7nL4wZ3'; // پیشفرض
if (file_exists($configPath)) {
    $configContent = file_get_contents($configPath);
    if (preg_match("/define\('WEBHOOK_SECRET',\s*'([^']+)'\)/", $configContent, $m)) {
        $allowedKey = $m[1];
    }
}

if (($_GET['key'] ?? '') !== $allowedKey) {
    // اگر کلید وارد نشده راهنما نشان بده
    if (empty($_GET['key'])) {
        die('<div style="font-family:Tahoma;direction:rtl;padding:30px;background:#fff3cd;border-radius:8px;max-width:500px;margin:50px auto">
            <h3>🔑 کلید امنیتی لازم است</h3>
            <p style="margin-top:10px">آدرس را اینطور باز کن:</p>
            <code style="background:#eee;padding:5px 10px;border-radius:4px;display:block;margin-top:10px;direction:ltr">' . htmlspecialchars('https://' . ($_SERVER['HTTP_HOST'] ?? 'yourdomain.com') . $_SERVER['REQUEST_URI'] . '?key=' . $allowedKey) . '</code>
        </div>');
    }
    http_response_code(403);
    die('<h2 style="color:red;font-family:Tahoma;direction:rtl;padding:20px">❌ کلید اشتباه است.</h2>');
}

error_reporting(E_ALL);
ini_set('display_errors', 1);

$results = [];

function check(string $title, bool $status, string $detail = '', string $fix = ''): array {
    return compact('title', 'status', 'detail', 'fix');
}

// ==================== ۱. PHP Version ====================
$phpVersion = PHP_VERSION;
$results[] = check(
    'نسخه PHP',
    version_compare($phpVersion, '8.0.0', '>='),
    "نسخه فعلی: $phpVersion",
    'نسخه PHP باید 8.0 یا بالاتر باشد'
);

// ==================== ۲. Extensions ====================
foreach (['curl', 'pdo', 'pdo_mysql', 'json', 'mbstring'] as $ext) {
    $results[] = check(
        "افزونه PHP: $ext",
        extension_loaded($ext),
        extension_loaded($ext) ? 'فعال است' : 'غیرفعال است',
        "در php.ini مقدار extension=$ext را فعال کنید"
    );
}

// ==================== ۳. Config File ====================
$configPath = __DIR__ . '/config/config.php';
$configExists = file_exists($configPath);
$results[] = check('فایل config.php', $configExists, $configExists ? $configPath : 'فایل پیدا نشد', 'فایل config/config.php باید وجود داشته باشد');

if ($configExists) {
    if (!defined('BOT_TOKEN')) require_once $configPath;

    $results[] = check(
        'BOT_TOKEN تنظیم شده',
        defined('BOT_TOKEN') && BOT_TOKEN !== 'YOUR_BALE_BOT_TOKEN' && strlen(BOT_TOKEN) > 10,
        defined('BOT_TOKEN') ? 'طول توکن: ' . strlen(BOT_TOKEN) . ' کاراکتر' : 'تعریف نشده',
        'مقدار BOT_TOKEN را در config.php وارد کنید'
    );

    $results[] = check(
        'BASE_URL تنظیم شده',
        defined('BASE_URL') && BASE_URL !== 'https://yourdomain.com/bale-dating-bot',
        defined('BASE_URL') ? BASE_URL : 'تعریف نشده',
        'مقدار BASE_URL را با آدرس واقعی سایت پر کنید'
    );

    $results[] = check(
        'HTTPS در BASE_URL',
        defined('BASE_URL') && str_starts_with(BASE_URL, 'https://'),
        defined('BASE_URL') ? BASE_URL : '',
        'بله فقط webhook با HTTPS قبول میکند'
    );
}

// ==================== ۴. Database ====================
if ($configExists && defined('DB_HOST')) {
    try {
        $pdo = new PDO(
            'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
            DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        $results[] = check('اتصال به دیتابیس', true, 'اتصال موفق به: ' . DB_NAME);

        // Check tables
        $tables = ['users','profiles','likes','matches','messages','blocked_users','reports','admins','vip_users','settings'];
        $existing = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
        foreach ($tables as $table) {
            $results[] = check(
                "جدول: $table",
                in_array($table, $existing),
                in_array($table, $existing) ? 'موجود است' : 'وجود ندارد',
                'فایل database.sql را در phpMyAdmin ایمپورت کنید'
            );
        }

        // Check settings table data
        $settingsCount = $pdo->query("SELECT COUNT(*) FROM settings")->fetchColumn();
        $results[] = check('داده در جدول settings', $settingsCount > 0, "تعداد رکورد: $settingsCount", 'database.sql را دوباره ایمپورت کنید');

    } catch (PDOException $e) {
        $results[] = check('اتصال به دیتابیس', false, $e->getMessage(), 'DB_HOST, DB_NAME, DB_USER, DB_PASS را در config.php چک کنید');
    }
}

// ==================== ۵. Directories ====================
$dirs = [
    'uploads' => __DIR__ . '/uploads',
    'logs'    => __DIR__ . '/logs',
];
foreach ($dirs as $name => $path) {
    $exists   = is_dir($path);
    $writable = $exists && is_writable($path);
    $results[] = check(
        "پوشه $name قابل نوشتن",
        $writable,
        $exists ? ($writable ? 'قابل نوشتن' : 'فقط خواندنی - permission اشتباه') : 'پوشه وجود ندارد',
        "در File Manager روی پوشه $name راستکلیک → Permissions → 755 بزن"
    );
}

// ==================== ۶. Bale API Test ====================
if ($configExists && defined('BOT_TOKEN') && BOT_TOKEN !== 'YOUR_BALE_BOT_TOKEN') {
    $ch = curl_init(BALE_API_URL . 'getMe');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => '{}',
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);
    $response = curl_exec($ch);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($curlError) {
        $results[] = check('اتصال به API بله', false, 'cURL error: ' . $curlError, 'سرور باید به اینترنت دسترسی داشته باشد');
    } else {
        $data = json_decode($response, true);
        if ($data && $data['ok']) {
            $botName = $data['result']['first_name'] ?? '';
            $botUsername = $data['result']['username'] ?? '';
            $results[] = check('اتصال به API بله', true, "ربات: $botName (@$botUsername)");
        } else {
            $results[] = check('اتصال به API بله', false, 'پاسخ: ' . $response, 'BOT_TOKEN اشتباه است یا ربات حذف شده');
        }
    }

    // Webhook status
    $ch = curl_init(BALE_API_URL . 'getWebhookInfo');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => '{}',
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);
    $whResponse = curl_exec($ch);
    curl_close($ch);
    $whData = json_decode($whResponse, true);

    if ($whData && $whData['ok']) {
        $whUrl = $whData['result']['url'] ?? '';
        $whError = $whData['result']['last_error_message'] ?? '';
        $whPending = $whData['result']['pending_update_count'] ?? 0;

        $results[] = check(
            'Webhook ثبت شده',
            !empty($whUrl),
            "URL: $whUrl",
            'به آدرس webhook/setup.php?secret=...&action=set بروید'
        );

        if ($whError) {
            $results[] = check('آخرین خطای Webhook', false, $whError, 'فایل webhook/index.php باید HTTP 200 برگرداند');
        }

        $results[] = check(
            'آپدیت در انتظار',
            true,
            "تعداد: $whPending پیام در صف",
            ''
        );
    }
}

// ==================== ۷. Webhook File ====================
$webhookFile = __DIR__ . '/webhook/index.php';
$results[] = check(
    'فایل webhook/index.php',
    file_exists($webhookFile),
    file_exists($webhookFile) ? 'موجود است' : 'فایل پیدا نشد',
    'فایل webhook/index.php باید آپلود شده باشد'
);

// ==================== ۸. Log Files ====================
$logDir = __DIR__ . '/logs/';
$logFiles = glob($logDir . '*.log');
$lastLog = '';
$lastErrors = '';
if (!empty($logFiles)) {
    rsort($logFiles);
    $lastLog = file_get_contents($logFiles[0]);
    // فیلتر فقط خطاها
    $lines = explode("\n", $lastLog);
    $errLines = array_filter($lines, fn($l) => str_contains($l, '[ERROR]'));
    $lastErrors = implode("\n", array_slice($errLines, -20));
}
$results[] = check(
    'فایلهای لاگ',
    true,
    empty($logFiles) ? 'هیچ لاگی وجود ندارد (ربات هنوز درخواستی دریافت نکرده)' : 'آخرین لاگ: ' . basename($logFiles[0])
);

if (!empty($lastErrors)) {
    $results[] = check(
        'خطاهای اخیر',
        false,
        'در لاگ خطاهایی وجود دارد — برای جزئیات پایین صفحه را ببین',
        'خطاهای زیر را بررسی کن'
    );
}

// ==================== ۹. Schema برای ملاقات مخفیانه ====================
if ($configExists && defined('DB_HOST') && isset($pdo)) {
    try {
        $secretTablesOk = true;
        foreach (['secret_meeting_rooms', 'secret_meeting_queue', 'coins', 'coin_transactions'] as $tbl) {
            $exists = in_array($tbl, $existing);
            if (!$exists) $secretTablesOk = false;
            $results[] = check(
                "جدول: $tbl",
                $exists,
                $exists ? 'موجود است' : 'مفقود!',
                'به آدرس migrate.php برو تا جدول‌های مفقود ساخته شوند'
            );
        }

        // بررسی ستون‌های ضروری users
        $userCols = $pdo->query("SHOW COLUMNS FROM users")->fetchAll(PDO::FETCH_COLUMN);
        foreach (['current_status', 'current_secret_meeting_room_id', 'last_seen_at'] as $col) {
            $exists = in_array($col, $userCols);
            if (!$exists) $secretTablesOk = false;
            $results[] = check(
                "ستون users.{$col}",
                $exists,
                $exists ? 'موجود است' : 'مفقود!',
                'به آدرس migrate.php برو تا ستون‌های مفقود ساخته شوند'
            );
        }

        // بررسی ستون‌های messages
        $msgCols = $pdo->query("SHOW COLUMNS FROM messages")->fetchAll(PDO::FETCH_COLUMN);
        foreach (['conversation_type', 'conversation_id'] as $col) {
            $exists = in_array($col, $msgCols);
            if (!$exists) $secretTablesOk = false;
            $results[] = check(
                "ستون messages.{$col}",
                $exists,
                $exists ? 'موجود است' : 'مفقود!',
                'به آدرس migrate.php برو تا ستون‌های مفقود ساخته شوند'
            );
        }

        // بررسی میزان کاربران گیرکرده
        if (in_array('current_status', $userCols)) {
            $stuck = $pdo->query("SELECT COUNT(*) FROM users WHERE current_status = 'in_secret_meeting'")->fetchColumn();
            if ($stuck > 0) {
                $results[] = check(
                    'کاربران گیرکرده در in_secret_meeting',
                    false,
                    "تعداد: $stuck کاربر",
                    'cron job برای cli_match_maker.php تنظیم کن یا دستی اجرا کن'
                );
            }
        }
    } catch (Throwable $e) {
        $results[] = check('بررسی schema', false, $e->getMessage(), '');
    }
}

// ==================== نمایش نتایج ====================
$pass = count(array_filter($results, fn($r) => $r['status']));
$fail = count(array_filter($results, fn($r) => !$r['status']));
$total = count($results);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>دیاگنوستیک ربات بله</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:Tahoma,Arial,sans-serif;background:#f5f5f5;padding:20px;direction:rtl}
h1{text-align:center;margin-bottom:5px;color:#333}
.subtitle{text-align:center;color:#666;margin-bottom:25px;font-size:13px}
.summary{display:flex;gap:15px;justify-content:center;margin-bottom:25px}
.sum-box{padding:15px 30px;border-radius:8px;text-align:center;font-size:22px;font-weight:bold}
.sum-pass{background:#d4edda;color:#155724}
.sum-fail{background:#f8d7da;color:#721c24}
.sum-total{background:#d1ecf1;color:#0c5460}
.sum-box span{display:block;font-size:12px;font-weight:normal;margin-top:3px}
.item{background:#fff;border-radius:8px;padding:14px 18px;margin-bottom:10px;display:flex;align-items:flex-start;gap:12px;box-shadow:0 1px 4px rgba(0,0,0,.07)}
.icon{font-size:20px;min-width:24px;margin-top:1px}
.content{flex:1}
.title{font-weight:bold;font-size:14px;margin-bottom:3px}
.detail{font-size:12px;color:#555;margin-bottom:3px}
.fix{font-size:12px;color:#856404;background:#fff3cd;padding:4px 8px;border-radius:4px;margin-top:5px;display:inline-block}
.section{font-size:13px;font-weight:bold;color:#666;margin:20px 0 8px;padding-right:5px;border-right:3px solid #007bff}
.log-box{background:#1e1e1e;color:#d4d4d4;padding:15px;border-radius:8px;font-family:monospace;font-size:12px;white-space:pre-wrap;max-height:300px;overflow-y:auto;margin-top:10px;direction:ltr}
.warning{background:#fff3cd;border:1px solid #ffc107;padding:12px;border-radius:8px;margin-bottom:20px;font-size:13px;color:#856404}
</style>
</head>
<body>
<h1>🔍 دیاگنوستیک ربات بله</h1>
<p class="subtitle">بررسی کامل وضعیت ربات دوستیابی</p>

<div class="warning">⚠️ بعد از رفع مشکل، این فایل را حذف کن! (debug.php)</div>

<div class="summary">
    <div class="sum-box sum-pass"><?= $pass ?><span>✅ موفق</span></div>
    <div class="sum-box sum-fail"><?= $fail ?><span>❌ مشکل</span></div>
    <div class="sum-box sum-total"><?= $total ?><span>🔢 کل</span></div>
</div>

<?php
$sections = [
    'PHP و سرور'    => array_slice($results, 0, 6),
    'فایل تنظیمات' => array_slice($results, 6, 3),
    'دیتابیس'       => array_slice($results, 9, 12),
    'پوشهها'        => array_slice($results, 21, 2),
    'API بله'       => array_slice($results, 23, 4),
    'فایلها و لاگ' => array_slice($results, 27),
];

// نمایش ساده همه نتایج بدون section بندی دقیق
foreach ($results as $r):
?>
<div class="item">
    <div class="icon"><?= $r['status'] ? '✅' : '❌' ?></div>
    <div class="content">
        <div class="title"><?= htmlspecialchars($r['title']) ?></div>
        <?php if ($r['detail']): ?>
        <div class="detail"><?= htmlspecialchars($r['detail']) ?></div>
        <?php endif; ?>
        <?php if (!$r['status'] && $r['fix']): ?>
        <div class="fix">🔧 راهحل: <?= htmlspecialchars($r['fix']) ?></div>
        <?php endif; ?>
    </div>
</div>
<?php endforeach; ?>

<?php if (!empty($lastErrors)): ?>
<div class="section">⚠️ آخرین خطاهای ثبت‌شده (۲۰ خطای اخیر)</div>
<div class="log-box"><?= htmlspecialchars($lastErrors) ?></div>
<?php elseif (!empty($lastLog)): ?>
<div class="section">📋 آخرین لاگ</div>
<div class="log-box"><?= htmlspecialchars(substr($lastLog, -3000)) ?></div>
<?php endif; ?>

<?php if ($fail === 0): ?>
<div style="background:#d4edda;color:#155724;padding:20px;border-radius:8px;text-align:center;margin-top:20px;font-size:16px">
    🎉 همه چیز درست است! ربات باید کار کند. در بله /start بفرست.
</div>
<?php else: ?>
<div style="background:#f8d7da;color:#721c24;padding:20px;border-radius:8px;text-align:center;margin-top:20px;font-size:14px">
    ❌ <?= $fail ?> مشکل پیدا شد. موارد قرمز را برطرف کن و دوباره این صفحه را رفرش کن.<br>
    <small>اگر مشکل جدول/ستون مفقود است، به <a href="migrate.php" style="color:#721c24;font-weight:bold">migrate.php</a> برو.</small>
</div>
<?php endif; ?>

<p style="text-align:center;margin-top:15px;font-size:12px;color:#999">
    زمان بررسی: <?= date('Y-m-d H:i:s') ?> | 
    <a href="?key=<?= htmlspecialchars($_GET['key']) ?>">🔄 رفرش</a>
</p>
</body>
</html>
