<?php
/**
 * تغییر webhook به فایل تست یا اصلی (توکن و URL از config خوانده می‌شود)
 * آدرس: https://a7vbot.ir/bale/switch_webhook.php?key=WEBHOOK_SECRET&mode=test
 * برای برگشت: mode=main
 */

require_once __DIR__ . '/config/config.php';

if (($_GET['key'] ?? '') !== WEBHOOK_SECRET) {
    die('forbidden');
}

$mode = $_GET['mode'] ?? 'main';

$url = $mode === 'test'
    ? BASE_URL . '/test_webhook.php'
    : BASE_URL . '/webhook/index.php';

$ch = curl_init(BALE_API_URL . 'setWebhook');
curl_setopt_array($ch, [
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => http_build_query(['url' => $url]),
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => 10,
    CURLOPT_SSL_VERIFYPEER => false,
]);
$result = curl_exec($ch);
curl_close($ch);

echo "<div style='font-family:Tahoma;direction:rtl;padding:20px'>";
echo "<h3>تغییر Webhook</h3>";
echo "<p>حالت: <strong>" . ($mode === 'test' ? '🧪 تست' : '🚀 اصلی') . "</strong></p>";
echo "<p>URL: <code>" . htmlspecialchars($url) . "</code></p>";
echo "<p>نتیجه: <code>" . htmlspecialchars($result) . "</code></p>";
echo "<hr>";
echo "<p><a href='?key=" . urlencode(WEBHOOK_SECRET) . "&mode=test'>🧪 رفتن به حالت تست</a> | <a href='?key=" . urlencode(WEBHOOK_SECRET) . "&mode=main'>🚀 برگشت به حالت اصلی</a></p>";
echo "</div>";
