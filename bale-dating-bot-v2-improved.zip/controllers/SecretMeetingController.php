<?php

/**
 * SecretMeetingController - بهبود یافته
 * - محدودیت روزانه
 * - هزینه‌های پویا
 * - آمار و مدیریت بهتر صف
 * - پیام‌های جذاب‌تر
 */
class SecretMeetingController
{
    private Bale $bale;
    private ChatController $chatCtrl;

    private const PROVINCES = [
        'تهران', 'اصفهان', 'فارس', 'خراسان رضوی', 'آذربایجان شرقی',
        'آذربایجان غربی', 'اردبیل', 'البرز', 'ایلام', 'بوشهر',
        'چهارمحال و بختیاری', 'خراسان جنوبی', 'خراسان شمالی', 'خوزستان', 'زنجان',
        'سمنان', 'سیستان و بلوچستان', 'گیلان', 'گلستان', 'همدان',
        'هرمزگان', 'کردستان', 'کرمان', 'کرمانشاه', 'کهگیلویه و بویراحمد',
        'لرستان', 'مازندران', 'مرکزی', 'قزوین', 'قم', 'یزد',
    ];

    public function __construct(Bale $bale, ChatController $chatCtrl)
    {
        $this->bale = $bale;
        $this->chatCtrl = $chatCtrl;
    }

    public function showMenu(array $user): void
    {
        $chatId = (int) $user['bale_id'];

        try {
            Schema::ensureSecretMeetingSchema();

            if (($user['current_status'] ?? 'idle') === 'in_queue') {
                SecretMeetingQueue::removeFromQueue($user['id']);
            }

            if (($user['current_status'] ?? 'idle') === 'in_secret_meeting') {
                $this->endExistingSecretMeeting($user);
                $user = User::findById($user['id']);
                if (!$user) return;
            }

            if ($user['step'] === 'chatting') {
                User::updateStep($user['id'], 'idle');
            }

            User::updateStep($user['id'], 'secret_meeting');
        } catch (Throwable $e) {
            Logger::error('showMenu failed: ' . $e->getMessage());
        }

        $balance = Coin::getBalance($user['id']);
        $isVip = Vip::isVip($user['id']);
        $stats = SecretMeetingRoom::getStats();
        $onlineCount = User::countOnline(5);

        $text = "🕶 *ملاقات مخفیانه - چت ناشناس*\n\n"
              . "اینجا می‌تونی با افراد جدید به صورت کاملاً ناشناس چت کنی!\n\n"
              . "📊 *آمار زنده:*\n"
              . "🟢 {$onlineCount} نفر آنلاین\n"
              . "🕶 {$stats['active']} چت فعال | 📅 {$stats['today']} چت امروز\n\n"
              . "💰 موجودی: {$balance} سکه\n"
              . ($isVip ? "⭐ VIP - اولویت در صف + نامحدود\n\n" : "🎁 امروز: " . (FREE_DAILY_SECRET - $this->getTodaySecretCount($user['id'])) . " چت رایگان باقی مانده\n\n")
              . "نوع جستجو را انتخاب کن:";

        $this->bale->sendMessage($chatId, $text, $this->bale->secretMeetingKeyboard());
    }

    public function showComingSoon(array $user, bool $advanced = false): void
    {
        $chatId = (int) $user['bale_id'];
        
        if ($advanced) {
            $this->bale->sendMessage(
                $chatId,
                "🔎 *جستجوی پیشرفته - به زودی*\n\n"
                . "در نسخه بعدی:\n"
                . "• فیلتر بر اساس سن\n"
                . "• فیلتر بر اساس علایق\n"
                . "• جستجو نزدیک من\n"
                . "• فیلتر عکس‌دارها\n\n"
                . "فعلاً از ملاقات مخفیانه استفاده کن!",
                $this->bale->mainMenuKeyboard()
            );
            return;
        }

        $this->bale->sendMessage(
            $chatId,
            "🚧 این بخش به‌زودی فعال می‌شود.",
            $this->bale->mainMenuKeyboard()
        );
    }

    public function handleMenu(array $user, string $text): void
    {
        $chatId = (int) $user['bale_id'];

        // Rate limiting
        if (!RateLimiter::checkQueue($user['id'])) {
            $this->bale->sendMessage($chatId, "⏳ لطفاً کمی صبر کنید (ضد اسپم)", $this->bale->secretMeetingKeyboard());
            return;
        }

        // محدودیت روزانه برای کاربران عادی
        if (!Vip::canSecretMeeting($user['id']) && !Vip::isVip($user['id'])) {
            $this->bale->sendMessage(
                $chatId,
                "⚠️ *محدودیت روزانه تمام شد*\n\n"
                . "شما امروز " . FREE_DAILY_SECRET . " چت مخفیانه انجام داده‌اید.\n"
                . "برای ادامه:\n"
                . "• فردا دوباره بیایید\n"
                . "• یا ⭐ VIP بخرید (نامحدود)\n\n"
                . "💰 موجودی: " . Coin::getBalance($user['id']) . " سکه",
                $this->bale->secretMeetingKeyboard()
            );
            return;
        }

        switch ($text) {
            case '🎲 جستجوی شانسی (0 سکه)':
            case '🎲 جستجوی شانسی (رایگان)':
                $this->addToQueue($user, 'random', null, null, COST_RANDOM);
                break;

            case '👨 جستجوی پسر (2 سکه)':
                $this->addToQueue($user, 'gender_male', 'male', null, COST_GENDER);
                break;

            case '👩 جستجوی دختر (2 سکه)':
                $this->addToQueue($user, 'gender_female', 'female', null, COST_GENDER);
                break;

            case '🗺 جستجوی بر اساس استان (4 سکه)':
                if (Coin::getBalance($user['id']) < COST_PROVINCE) {
                    $this->bale->sendMessage(
                        $chatId,
                        "⚠️ برای جستجوی استانی به *" . COST_PROVINCE . " سکه* نیاز داری\n"
                        . "موجودی: " . Coin::getBalance($user['id']) . " سکه\n\n"
                        . "🎁 با دعوت دوستان سکه رایگان بگیر!",
                        $this->bale->secretMeetingKeyboard()
                    );
                    return;
                }
                User::updateStep($user['id'], 'secret_meeting_gender');
                $this->bale->sendMessage(
                    $chatId,
                    "🗺 *جستجوی استانی*\n\nابتدا جنسیت مورد نظر را انتخاب کن:",
                    $this->genderKeyboard()
                );
                break;

            case '🔙 بازگشت':
                $status = $user['current_status'] ?? 'idle';
                if ($status === 'in_queue') {
                    SecretMeetingQueue::removeFromQueue($user['id']);
                    User::updateUserStatus($user['id'], 'idle');
                    User::updateStep($user['id'], 'idle');
                    $this->bale->sendMessage($chatId, "✅ از صف خارج شدی", $this->bale->mainMenuKeyboard());
                } elseif ($status === 'in_secret_meeting') {
                    $this->endExistingSecretMeeting($user);
                    $this->bale->sendMessage($chatId, "✅ از گفتگو خارج شدی", $this->bale->mainMenuKeyboard());
                } else {
                    User::updateStep($user['id'], 'idle');
                    User::updateUserStatus($user['id'], 'idle');
                    $this->bale->sendMessage($chatId, "بازگشت به منوی اصلی", $this->bale->mainMenuKeyboard());
                }
                break;

            default:
                $this->bale->sendMessage($chatId, "لطفاً از دکمه‌های منو استفاده کن", $this->bale->secretMeetingKeyboard());
                break;
        }
    }

    public function handleGenderSelection(array $user, string $text): void
    {
        $chatId = (int) $user['bale_id'];

        if ($text === '🔙 بازگشت') {
            User::updateStep($user['id'], 'secret_meeting');
            $this->bale->sendMessage($chatId, '🕶 ملاقات ناشناس', $this->bale->secretMeetingKeyboard());
            return;
        }

        if (!str_contains($text, 'پسر') && !str_contains($text, 'دختر') && !str_contains($text, 'مرد') && !str_contains($text, 'زن') && !str_contains($text, 'آقا') && !str_contains($text, 'خانم')) {
            $this->bale->sendMessage($chatId, '❌ لطفاً از دکمه‌ها استفاده کن', $this->genderKeyboard());
            return;
        }

        $gender = (str_contains($text, 'پسر') || str_contains($text, 'مرد') || str_contains($text, 'آقا')) ? 'male' : 'female';
        $stepData = User::getStepData($user) ?? [];
        $stepData['search_gender'] = $gender;
        User::updateStep($user['id'], 'secret_meeting_province', $stepData);
        $this->bale->sendMessage(
            $chatId,
            "✅ جنسیت: " . ($gender === 'male' ? 'پسر' : 'دختر') . "\n\n🗺 حالا استان مورد نظر را انتخاب کن:",
            $this->bale->provinceKeyboard()
        );
    }

    public function handleProvinceSelection(array $user, string $text): void
    {
        $chatId = (int) $user['bale_id'];

        if ($text === '🔙 بازگشت') {
            User::updateStep($user['id'], 'secret_meeting');
            $this->bale->sendMessage($chatId, '🕶 ملاقات ناشناس', $this->bale->secretMeetingKeyboard());
            return;
        }

        if (!in_array($text, self::PROVINCES, true)) {
            $this->bale->sendMessage($chatId, '❌ لطفاً یک استان معتبر انتخاب کن', $this->bale->provinceKeyboard());
            return;
        }

        User::updateStep($user['id'], 'idle');
        $stepData = User::getStepData($user) ?? [];

        $this->addToQueue($user, 'province', $stepData['search_gender'] ?? null, $text, COST_PROVINCE);
    }

    private function addToQueue(array $user, string $searchPreference, ?string $genderPreference, ?string $provincePreference, int $coinCost): void
    {
        $chatId = (int) $user['bale_id'];

        try {
            Schema::ensureSecretMeetingSchema();
        } catch (Throwable $e) {}

        try {
            if (($user['current_status'] ?? 'idle') === 'in_secret_meeting') {
                $this->endExistingSecretMeeting($user);
                $user = User::findById($user['id']);
                if (!$user) return;
            }

            if (($user['current_status'] ?? 'idle') === 'in_queue') {
                $match = SecretMeetingQueue::tryMatchUser($user['id']);
                if ($match) {
                    $this->notifyMatch($user, $match);
                } else {
                    $this->bale->sendMessage(
                        $chatId,
                        "⏳ هنوز در صف هستی...\n\n"
                        . "به محض پیدا شدن کاربر مناسب متصل میشی\n"
                        . "لطفاً صبر کن یا برای تغییر نوع جستجو 🔙 بزن",
                        $this->bale->secretMeetingKeyboard()
                    );
                }
                return;
            }

            if ($coinCost > 0 && Coin::getBalance($user['id']) < $coinCost) {
                $this->bale->sendMessage(
                    $chatId,
                    "⚠️ سکه کافی نیست!\n"
                    . "نیاز: {$coinCost} سکه\n"
                    . "موجودی: " . Coin::getBalance($user['id']) . " سکه\n\n"
                    . "🎁 با /daily یا دعوت دوستان سکه بگیر!",
                    $this->bale->secretMeetingKeyboard()
                );
                return;
            }

            if ($coinCost > 0 && !Coin::deduct($user['id'], $coinCost, 'ملاقات مخفیانه - ' . $searchPreference)) {
                $this->bale->sendMessage($chatId, '❌ خطا در کسر سکه', $this->bale->secretMeetingKeyboard());
                return;
            }

            $vipPriority = Vip::isVip($user['id']) ? 1 : 0;
            SecretMeetingQueue::addToQueue($user['id'], $searchPreference, $genderPreference, $provincePreference, $vipPriority);

            $match = SecretMeetingQueue::tryMatchUser($user['id']);

            if ($match) {
                $this->notifyMatch($user, $match);
                return;
            }

            $refreshedUser = User::findById($user['id']);
            if ($refreshedUser && ($refreshedUser['current_status'] ?? 'idle') === 'in_secret_meeting') {
                return;
            }

            $waitTime = $this->estimateWaitTime();
            $this->bale->sendMessage(
                $chatId,
                "🕵️ *در صف انتظار قرار گرفتی*\n\n"
                . "🔍 در حال جستجوی کاربر مناسب...\n"
                . "⏱ زمان تقریبی انتظار: {$waitTime}\n"
                . "👥 افراد در صف: " . $this->getQueueCount() . " نفر\n\n"
                . "به محض پیدا شدن، فوراً متصل میشی!\n"
                . "برای لغو 🔙 بزن",
                $this->bale->secretMeetingKeyboard()
            );

        } catch (Throwable $e) {
            Logger::error('addToQueue failed: ' . $e->getMessage(), ['user' => $user['id']]);
            $this->bale->sendMessage($chatId, '❌ خطا در افزودن به صف. دوباره تلاش کن', $this->bale->mainMenuKeyboard());
        }
    }

    private function notifyMatch(array $user, array $match): void
    {
        $roomId = (int) $match['room_id'];
        $partnerId = (int) $match['partner_user_id'];
        $partnerBale = (int) $match['partner_bale_id'];

        $partnerProfile = Profile::findByUserId($partnerId);
        $partnerName = $partnerProfile['name'] ?? 'کاربر ناشناس';

        $message = "🎉 *مچ شدی! یک نفر پیدا شد*\n\n"
                 . "🕶 ملاقات مخفیانه برقرار شد!\n"
                 . "👤 طرف مقابل: {$partnerName}\n\n"
                 . "💬 حالا می‌تونی چت کنی:\n"
                 . "• متن بفرست\n"
                 . "• عکس بفرست\n"
                 . "• هدیه بده (🎁)\n\n"
                 . "⚠️ این چت کاملاً ناشناسه و بعد از پایان، هویت شما فاش نمیشه\n"
                 . "🔒 برای امنیت، اطلاعات شخصی ندید\n\n"
                 . "پیامت رو بنویس 👇";

        $this->bale->sendMessage($user['bale_id'], $message, $this->bale->secretMeetingChatKeyboard($partnerId, $roomId));
        $this->bale->sendMessage($partnerBale, $message, $this->bale->secretMeetingChatKeyboard((int) $user['id'], $roomId));

        Logger::logUserAction($user['id'], 'secret_match', ['room_id' => $roomId, 'partner' => $partnerId]);
    }

    private function endExistingSecretMeeting(array $user): void
    {
        $roomId = (int) ($user['current_secret_meeting_room_id'] ?? 0);
        if (!$roomId) {
            User::updateUserStatus($user['id'], 'idle');
            return;
        }

        $room = SecretMeetingRoom::getRoomById($roomId);
        if (!$room || $room['status'] !== 'active') {
            User::updateUserStatus($user['id'], 'idle');
            User::updateStep($user['id'], 'idle');
            return;
        }

        SecretMeetingRoom::endRoom($roomId, 'aborted');

        $partnerId = (int) $room['user1_id'] === (int) $user['id'] ? (int) $room['user2_id'] : (int) $room['user1_id'];
        $partner = User::findById($partnerId);

        User::updateUserStatus($user['id'], 'idle');
        User::updateStep($user['id'], 'idle');

        if ($partner) {
            User::updateUserStatus($partnerId, 'idle');
            User::updateStep($partnerId, 'idle');
            try {
                $this->bale->sendMessage(
                    (int) $partner['bale_id'],
                    "👋 طرف مقابل گفتگو را ترک کرد و وارد صف جدید شد",
                    $this->bale->mainMenuKeyboard()
                );
            } catch (Throwable $e) {}
        }
    }

    private function genderKeyboard(): array
    {
        return [
            'keyboard' => [
                [['text' => '👨 جستجوی پسر']],
                [['text' => '👩 جستجوی دختر']],
                [['text' => '🔙 بازگشت']],
            ],
            'resize_keyboard' => true,
            'one_time_keyboard' => true,
        ];
    }

    private function getQueueCount(): int
    {
        try {
            $row = Database::fetch('SELECT COUNT(*) as cnt FROM secret_meeting_queue');
            return (int) ($row['cnt'] ?? 0);
        } catch (Throwable $e) {
            return 0;
        }
    }

    private function estimateWaitTime(): string
    {
        $count = $this->getQueueCount();
        if ($count === 0) return 'کمتر از ۱ دقیقه';
        if ($count < 5) return '۱-۲ دقیقه';
        if ($count < 15) return '۲-۵ دقیقه';
        return '۵-۱۰ دقیقه';
    }

    private function getTodaySecretCount(int $userId): int
    {
        try {
            $row = Database::fetch(
                'SELECT COUNT(*) as cnt FROM secret_meeting_rooms WHERE (user1_id = ? OR user2_id = ?) AND DATE(created_at) = CURDATE()',
                [$userId, $userId]
            );
            return (int) ($row['cnt'] ?? 0);
        } catch (Throwable $e) {
            return 0;
        }
    }
}
