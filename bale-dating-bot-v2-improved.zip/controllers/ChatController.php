<?php

/**
 * ChatController - نسخه بهبود یافته و کامل
 * - پشتیبانی از عکس در چت
 * - بهبود امنیت و اعتبارسنجی
 * - مدیریت بهتر اتاق‌ها
 * - ارسال هدیه با انیمیشن
 */

class ChatController
{
    private Bale $bale;

    public function __construct(Bale $bale)
    {
        $this->bale = $bale;
    }

    public function showMatches(array $user): void
    {
        $chatId = (int) $user['bale_id'];
        
        if ($user['step'] === 'chatting') {
            User::updateStep($user['id'], 'idle');
            User::updateUserStatus($user['id'], 'idle');
        }

        $matches = MatchModel::getUserMatches($user['id'], 20);

        if (empty($matches)) {
            $this->bale->sendMessage(
                $chatId,
                "💔 *هنوز مچی نداری*\n\n"
                . "برای پیدا کردن دوست:\n"
                . "• ❤️ پیدا کردن دوست رو بزن و پروفایل‌ها رو لایک کن\n"
                . "• 🕶 ملاقات مخفیانه - چت ناشناس شانسی\n"
                . "• وقتی کسی تورو لایک کنه و تو هم لایکش کنی، مچ میشید!\n\n"
                . "🎁 هر مچ = ۲ سکه جایزه!",
                $this->bale->mainMenuKeyboard()
            );
            return;
        }

        $buttons = [];
        foreach ($matches as $match) {
            $unread = !empty($match['unread_count']) ? " (🔴{$match['unread_count']})" : "";
            $online = '';
            if (!empty($match['last_seen_at'])) {
                $diff = time() - strtotime($match['last_seen_at']);
                if ($diff < 600) $online = '🟢 ';
            }
            $lastMsg = !empty($match['last_message']) ? ' - ' . mb_substr($match['last_message'], 0, 20) . '...' : '';
            $buttons[] = [[
                'text' => "{$online}💬 {$match['partner_name']} ({$match['age']} ساله، {$match['city']}){$unread}{$lastMsg}",
                'callback_data' => 'chat_open_' . $match['id']
            ]];
        }

        $buttons[] = [['text' => '🔙 منوی اصلی', 'callback_data' => 'chat_back']];

        $this->bale->sendMessage(
            $chatId,
            "💬 *گفتگوهای شما (" . count($matches) . " مچ فعال):*\n\nبرای ادامه گفتگو، یکی را انتخاب کن:",
            $this->bale->inlineKeyboard($buttons)
        );
    }

    public function openChat(array $user, string $callbackId, int $matchId): void
    {
        $chatId = (int) $user['bale_id'];
        $match = Database::fetch(
            'SELECT * FROM matches WHERE id = ? AND (user1_id = ? OR user2_id = ?) AND is_active = 1',
            [$matchId, $user['id'], $user['id']]
        );

        if (!$match) {
            $this->bale->answerCallbackQuery($callbackId, '❌ این گفتگو یافت نشد.', true);
            return;
        }

        $partnerId = ($match['user1_id'] == $user['id']) ? $match['user2_id'] : $match['user1_id'];
        $partnerProfile = Profile::findByUserId($partnerId);
        $partnerUser = User::findById($partnerId);

        if (!$partnerProfile || !$partnerUser) {
            $this->bale->answerCallbackQuery($callbackId, '❌ کاربر مقابل یافت نشد', true);
            return;
        }

        // علامت‌گذاری پیام‌ها به عنوان خوانده شده
        MatchModel::markAsRead($matchId, 'match', $user['id']);

        User::updateStep($user['id'], 'chatting', ['match_id' => $matchId, 'partner_id' => $partnerId]);
        $this->bale->answerCallbackQuery($callbackId);

        // نمایش تاریخچه کوتاه
        $messages = MatchModel::getMessages($matchId, 'match', 5);
        $historyText = "";
        if (!empty($messages)) {
            $historyText = "\n\n📜 *آخرین پیام‌ها:*\n";
            $messages = array_reverse($messages); // از قدیمی به جدید
            foreach (array_slice($messages, -3) as $msg) {
                $sender = $msg['sender_id'] == $user['id'] ? 'شما' : $partnerProfile['name'];
                $content = mb_substr($msg['content'], 0, 50);
                $historyText .= "{$sender}: {$content}\n";
            }
            $historyText .= "━━━━━━━━━━━━\n";
        }

        $keyboard = $this->bale->inlineKeyboard([
            [
                ['text' => '🚫 بلاک', 'callback_data' => 'chat_block_' . $partnerId],
                ['text' => '🗑 حذف', 'callback_data' => 'chat_delete_' . $matchId],
                ['text' => '👤 پروفایل', 'callback_data' => 'sm_view_profile_' . $partnerId],
            ],
            [['text' => '🔙 بازگشت به لیست', 'callback_data' => 'chat_list']],
        ]);

        $this->bale->sendMessage(
            $chatId,
            "💬 *گفتگو با {$partnerProfile['name']}* ({$partnerProfile['age']} ساله از {$partnerProfile['city']}){$historyText}\n"
            . "پیام خود را بنویسید (متن یا عکس):",
            $keyboard
        );
    }

    public function sendChatMessage(array $user, string $text, ?array $photo = null): void
    {
        $chatId = (int) $user['bale_id'];

        // بررسی rate limit
        if (!RateLimiter::checkMessage($user['id'])) {
            $this->bale->sendMessage($chatId, '⏳ لطفاً کمی آهسته‌تر! ضد اسپم فعال است. چند ثانیه صبر کنید.');
            return;
        }

        // اعتبارسنجی پیام
        if ($photo) {
            // عکس
            $fileId = end($photo)['file_id'] ?? null;
            if (!$fileId) {
                $this->bale->sendMessage($chatId, '❌ خطا در دریافت عکس');
                return;
            }
            $content = $fileId;
            $type = 'photo';
        } else {
            if ($text === '' || str_starts_with($text, '/')) {
                $this->bale->sendMessage($chatId, 'لطفاً یک پیام متنی یا عکس بفرستید');
                return;
            }

            $validation = Validator::textMessage($text);
            if (!$validation['valid']) {
                $this->bale->sendMessage($chatId, '❌ ' . $validation['error']);
                return;
            }
            $content = $validation['clean'];
            $type = 'text';
        }

        $stepData = User::getStepData($user);
        $conversationType = null;
        $conversationId = null;
        $partnerId = null;

        // تشخیص نوع گفتگو
        if (($user['current_status'] ?? 'idle') === 'in_secret_meeting' && !empty($user['current_secret_meeting_room_id'])) {
            $room = SecretMeetingRoom::getRoomById((int) $user['current_secret_meeting_room_id']);
            if ($room && $room['status'] === 'active') {
                $conversationType = 'secret_meeting';
                $conversationId = $room['id'];
                $partnerId = ($room['user1_id'] == $user['id']) ? $room['user2_id'] : $room['user1_id'];
            }
        } elseif ($stepData && !empty($stepData['match_id'])) {
            $conversationType = 'match';
            $conversationId = $stepData['match_id'];
            $partnerId = $stepData['partner_id'];
        }

        if (!$conversationType || !$conversationId || !$partnerId) {
            User::updateStep($user['id'], 'idle');
            User::updateUserStatus($user['id'], 'idle');
            $this->bale->sendMessage($chatId, '❌ وضعیت چت نامشخص است. لطفاً دوباره وارد گفتگو شوید.', $this->bale->mainMenuKeyboard());
            return;
        }

        if (BlockReport::isBlockedEither($user['id'], $partnerId)) {
            $this->bale->sendMessage($chatId, '🚫 امکان ارسال پیام وجود ندارد (بلاک شده)', $this->bale->mainMenuKeyboard());
            User::updateStep($user['id'], 'idle');
            return;
        }

        $partnerUser = User::findById($partnerId);
        if (!$partnerUser || User::isBlocked($partnerId)) {
            User::updateStep($user['id'], 'idle');
            User::updateUserStatus($user['id'], 'idle');
            $this->bale->sendMessage($chatId, '❌ کاربر مقابل در دسترس نیست', $this->bale->mainMenuKeyboard());
            return;
        }

        // ذخیره پیام
        MatchModel::saveMessage($conversationId, $user['id'], $content, $type, $conversationType);

        // اطمینان از اینکه طرف مقابل در حالت چت قرار می‌گیرد
        $this->ensurePartnerInChatStep($partnerUser, $user, $conversationType, $conversationId);

        // ارسال به طرف مقابل
        $partnerKeyboard = $conversationType === 'secret_meeting'
            ? $this->bale->secretMeetingChatKeyboard($user['id'], $conversationId)
            : $this->bale->inlineKeyboard([
                [
                    ['text' => '🚫 بلاک', 'callback_data' => 'chat_block_' . $user['id']],
                    ['text' => '🗑 حذف', 'callback_data' => 'chat_delete_' . $conversationId],
                    ['text' => '🔙 بازگشت', 'callback_data' => 'chat_back'],
                ]
            ]);

        if ($type === 'photo') {
            $myProfile = Profile::findByUserId($user['id']);
            $caption = "📸 عکس از " . ($myProfile['name'] ?? 'کاربر');
            $this->bale->sendPhoto((int) $partnerUser['bale_id'], $content, $caption, $partnerKeyboard);
            // تایید به فرستنده
            $this->bale->sendMessage($chatId, '✅ عکس ارسال شد', $this->resolveActiveChatKeyboard($user, $partnerId));
        } else {
            $this->bale->sendMessage((int) $partnerUser['bale_id'], $text, $partnerKeyboard);
        }

        // تایپینگ را شبیه‌سازی کن؟ نه نیاز نیست، چون پیام مستقیم ارسال می‌شود
    }

    private function ensurePartnerInChatStep(array $partner, array $sender, string $conversationType, int $conversationId): void
    {
        $partnerStep = $partner['step'] ?? 'idle';
        if (str_starts_with($partnerStep, 'register_') || str_starts_with($partnerStep, 'editing_')) {
            return;
        }

        if (!in_array($partnerStep, ['idle', 'chatting'], true)) {
            return;
        }

        if ($conversationType === 'secret_meeting') {
            if (($partner['current_status'] ?? 'idle') !== 'in_secret_meeting') {
                User::updateUserStatus($partner['id'], 'in_secret_meeting', $conversationId);
            }
        } else {
            $existing = User::getStepData($partner) ?? [];
            if (empty($existing['match_id']) || (int) $existing['match_id'] !== $conversationId) {
                User::updateStep($partner['id'], 'chatting', [
                    'match_id' => $conversationId,
                    'partner_id' => $sender['id'],
                ]);
            } elseif ($partnerStep !== 'chatting') {
                User::updateStep($partner['id'], 'chatting', $existing);
            }
        }
    }

    public function handleCallback(array $user, string $callbackId, string $data): void
    {
        $chatId = (int) $user['bale_id'];

        try {
            if (str_starts_with($data, 'chat_open_')) {
                $matchId = (int) substr($data, 10);
                $this->openChat($user, $callbackId, $matchId);

            } elseif (str_starts_with($data, 'chat_block_')) {
                $targetId = (int) substr($data, 11);
                BlockReport::block($user['id'], $targetId);
                User::updateStep($user['id'], 'idle');
                User::updateUserStatus($user['id'], 'idle');
                $this->bale->answerCallbackQuery($callbackId, '🚫 کاربر بلاک شد', true);
                $this->bale->sendMessage($chatId, "🚫 کاربر بلاک شد و از لیست حذف شد\nبرای مدیریت لیست بلاک: 📁 پرونده من > 🚫 بلاک شده‌ها", $this->bale->mainMenuKeyboard());

            } elseif (str_starts_with($data, 'chat_delete_')) {
                $matchId = (int) substr($data, 12);
                MatchModel::deleteMatch($matchId, $user['id']);
                User::updateStep($user['id'], 'idle');
                $this->bale->answerCallbackQuery($callbackId, '🗑 مچ حذف شد', true);
                $this->bale->sendMessage($chatId, '🗑 مچ حذف شد', $this->bale->mainMenuKeyboard());

            } elseif ($data === 'chat_back' || $data === 'chat_list') {
                User::updateStep($user['id'], 'idle');
                User::updateUserStatus($user['id'], 'idle');
                $this->bale->answerCallbackQuery($callbackId);
                if ($data === 'chat_list') {
                    $this->showMatches($user);
                } else {
                    $this->bale->sendMessage($chatId, 'بازگشت به منو', $this->bale->mainMenuKeyboard());
                }

            } elseif (str_starts_with($data, 'sm_view_profile_')) {
                $partnerId = (int) substr($data, 16);
                $this->handleViewProfile($user, $callbackId, $partnerId);

            } elseif (str_starts_with($data, 'sm_gift_')) {
                $partnerId = (int) substr($data, 8);
                $this->handleGiveGift($user, $callbackId, $partnerId);

            } elseif (str_starts_with($data, 'sm_end_chat_')) {
                $roomId = (int) substr($data, 12);
                $this->handleEndChat($user, $callbackId, $roomId);

            } elseif (str_starts_with($data, 'sm_delete_messages_')) {
                $roomId = (int) substr($data, 19);
                $this->handleDeleteMessages($user, $callbackId, $roomId);

            } elseif (str_starts_with($data, 'sm_report_user_')) {
                $partnerId = (int) substr($data, 15);
                $this->handleReportUser($user, $callbackId, $partnerId);

            } else {
                $this->bale->answerCallbackQuery($callbackId);
            }

        } catch (Throwable $e) {
            Logger::error("ChatController callback failed: " . $e->getMessage(), ['user' => $user['id'], 'data' => $data]);
            try { $this->bale->answerCallbackQuery($callbackId, '❌ خطا', true); } catch (Throwable $_) {}
            
            $partnerId = 0;
            try {
                if (($user['current_status'] ?? '') === 'in_secret_meeting' && !empty($user['current_secret_meeting_room_id'])) {
                    $room = SecretMeetingRoom::getRoomById((int) $user['current_secret_meeting_room_id']);
                    if ($room && $room['status'] === 'active') {
                        $partnerId = (int) $room['user1_id'] === (int) $user['id'] ? (int) $room['user2_id'] : (int) $room['user1_id'];
                    }
                }
            } catch (Throwable $_) {}

            try {
                $kb = $this->resolveActiveChatKeyboard($user, $partnerId);
                $this->bale->sendMessage($chatId, '❌ خطایی رخ داد. دوباره تلاش کنید.', $kb);
            } catch (Throwable $_) {
                try { $this->bale->sendMessage($chatId, '❌ خطا', $this->bale->mainMenuKeyboard()); } catch (Throwable $_) {}
            }
        }
    }

    private function handleViewProfile(array $user, string $callbackId, int $partnerId): void
    {
        $chatId = (int) $user['bale_id'];
        $partner = User::findById($partnerId);
        if (!$partner) {
            $this->bale->answerCallbackQuery($callbackId, '❌ کاربر یافت نشد', true);
            return;
        }

        $partnerProfile = Profile::findByUserId($partnerId);
        if (!$partnerProfile) {
            $this->bale->answerCallbackQuery($callbackId, '❌ پروفایل ندارد', true);
            return;
        }

        $this->bale->answerCallbackQuery($callbackId);

        $replyMarkup = [];
        $roomId = 0;
        try {
            if (($user['current_status'] ?? '') === 'in_secret_meeting' && !empty($user['current_secret_meeting_room_id'])) {
                $roomId = (int) $user['current_secret_meeting_room_id'];
                $room = SecretMeetingRoom::getRoomById($roomId);
                if ($room && $room['status'] === 'active') {
                    $replyMarkup = $this->bale->secretMeetingChatKeyboard($partnerId, $roomId);
                }
            }
        } catch (Throwable $e) {}

        $cardText = Profile::formatCard($partnerProfile);
        $cardText .= "\n\n💎 موجودی: " . Coin::getBalance($partnerId) . " سکه (تخمینی)";

        $photoFileId = $partnerProfile['photo_file_id'] ?? '';
        $sent = false;

        if (!empty($photoFileId)) {
            try {
                $result = $this->bale->sendPhoto($chatId, $photoFileId, $cardText, $replyMarkup);
                $sent = $result !== null;
            } catch (Throwable $e) {}
        }

        if (!$sent) {
            $this->bale->sendMessage($chatId, $cardText, $replyMarkup);
        }

        // اطلاع به طرف مقابل
        try {
            $partnerBaleId = (int) ($partner['bale_id'] ?? 0);
            if ($partnerBaleId > 0) {
                $partnerKb = $this->resolveActiveChatKeyboard($partner, (int) $user['id']);
                $this->bale->sendMessage($partnerBaleId, '🕵️ مخاطب پرونده شما را مشاهده کرد', $partnerKb);
            }
        } catch (Throwable $e) {}
    }

    private function handleGiveGift(array $user, string $callbackId, int $partnerId): void
    {
        $chatId = (int) $user['bale_id'];
        $partner = User::findById($partnerId);
        
        if (!$partner) {
            $this->bale->answerCallbackQuery($callbackId, '❌ کاربر یافت نشد', true);
            return;
        }

        $balance = Coin::getBalance($user['id']);
        if ($balance < COST_GIFT) {
            $this->bale->answerCallbackQuery($callbackId, "⚠️ سکه کافی نیست! نیاز: " . COST_GIFT . " | موجودی: $balance", true);
            return;
        }

        $myProfile = Profile::findByUserId($user['id']);
        $giftText = "🎁 هدیه از {$myProfile['name']}!";

        if (Coin::transfer($user['id'], $partnerId, COST_GIFT, 'هدیه در چت')) {
            $this->bale->answerCallbackQuery($callbackId, "🎁 هدیه {$giftText} ارسال شد! (".COST_GIFT." سکه)", false);
            
            $senderKb = $this->resolveActiveChatKeyboard($user, $partnerId);
            $this->bale->sendMessage($chatId, "🎁 شما {$giftText} سکه برای " . ($partner['first_name'] ?? 'کاربر') . " فرستادید!", $senderKb);

            $receiverKb = $this->resolveActiveChatKeyboard($partner, $user['id']);
            $this->bale->sendMessage(
                (int) $partner['bale_id'],
                "🎁 *هدیه دریافت کردید!*\n\n{$myProfile['name']} برای شما " . COST_GIFT . " سکه هدیه فرستاد! 🎉\n\n💰 موجودی جدید: " . Coin::getBalance($partnerId) . " سکه",
                $receiverKb
            );
        } else {
            $this->bale->answerCallbackQuery($callbackId, '❌ خطا در ارسال هدیه', true);
        }
    }

    private function resolveActiveChatKeyboard(array $user, int $partnerId): array
    {
        $status = $user['current_status'] ?? 'idle';
        if ($status === 'in_secret_meeting' && !empty($user['current_secret_meeting_room_id'])) {
            $roomId = (int) $user['current_secret_meeting_room_id'];
            $room = SecretMeetingRoom::getRoomById($roomId);
            if ($room && $room['status'] === 'active') {
                return $this->bale->secretMeetingChatKeyboard($partnerId, $roomId);
            }
        }

        $stepData = User::getStepData($user);
        if (!empty($stepData['match_id'])) {
            return $this->bale->inlineKeyboard([
                [
                    ['text' => '🚫 بلاک', 'callback_data' => 'chat_block_' . $partnerId],
                    ['text' => '🗑 حذف', 'callback_data' => 'chat_delete_' . $stepData['match_id']],
                    ['text' => '🔙 بازگشت', 'callback_data' => 'chat_back'],
                ]
            ]);
        }

        return $this->bale->mainMenuKeyboard();
    }

    private function handleEndChat(array $user, string $callbackId, int $roomId): void
    {
        $chatId = (int) $user['bale_id'];
        $room = SecretMeetingRoom::getRoomById($roomId);

        if (!$room) {
            $this->bale->answerCallbackQuery($callbackId, '❌ اتاق یافت نشد', true);
            return;
        }

        $isUser1 = (int) $room['user1_id'] === (int) $user['id'];
        $isUser2 = (int) $room['user2_id'] === (int) $user['id'];
        if (!$isUser1 && !$isUser2) {
            $this->bale->answerCallbackQuery($callbackId, '❌ دسترسی ندارید', true);
            return;
        }

        if ($room['status'] !== 'active') {
            User::updateUserStatus($user['id'], 'idle');
            User::updateStep($user['id'], 'idle');
            $this->bale->answerCallbackQuery($callbackId, 'گفتگو از قبل تمام شده');
            $this->bale->sendMessage($chatId, '✅ گفتگو تمام شده', $this->bale->mainMenuKeyboard());
            return;
        }

        $partnerId = $isUser1 ? (int) $room['user2_id'] : (int) $room['user1_id'];
        $partnerUser = User::findById($partnerId);
        $endStatus = $isUser1 ? 'ended_by_user1' : 'ended_by_user2';

        SecretMeetingRoom::endRoom($roomId, $endStatus);
        User::updateUserStatus($user['id'], 'idle');
        User::updateStep($user['id'], 'idle');
        if ($partnerId) {
            User::updateUserStatus($partnerId, 'idle');
            User::updateStep($partnerId, 'idle');
        }

        $this->bale->answerCallbackQuery($callbackId, 'گفتگو پایان یافت');
        $this->bale->sendMessage($chatId, 
            "✅ *گفتگوی مخفیانه پایان یافت*\n\n"
            . "📝 نظرت درباره این گفتگو چی بود؟\n"
            . "اگه از هم خوشتون اومد، می‌تونید همدیگه رو در بخش پیدا کردن دوست پیدا کنید!\n\n"
            . "🎁 ۱ سکه جایزه برای چت کامل گرفتی!", 
            $this->bale->mainMenuKeyboard()
        );

        if ($partnerUser) {
            $this->bale->sendMessage(
                (int) $partnerUser['bale_id'],
                "👋 طرف مقابل گفتگو را پایان داد.\n\nاگه دوست داشتی دوباره با افراد جدید چت کن:\n🕶 ملاقات مخفیانه",
                $this->bale->mainMenuKeyboard()
            );
        }
    }

    private function handleDeleteMessages(array $user, string $callbackId, int $roomId): void
    {
        $chatId = (int) $user['bale_id'];
        $room = SecretMeetingRoom::getRoomById($roomId);

        if (!$room || $room['status'] !== 'active') {
            $this->bale->answerCallbackQuery($callbackId, '❌ گفتگو پایان یافته', true);
            User::updateUserStatus($user['id'], 'idle');
            User::updateStep($user['id'], 'idle');
            $this->bale->sendMessage($chatId, '✅ گفتگو پایان یافت', $this->bale->mainMenuKeyboard());
            return;
        }

        $isUser1 = (int) $room['user1_id'] === (int) $user['id'];
        $isUser2 = (int) $room['user2_id'] === (int) $user['id'];
        if (!$isUser1 && !$isUser2) {
            $this->bale->answerCallbackQuery($callbackId, '❌ دسترسی ندارید', true);
            return;
        }

        $col = $isUser1 ? 'deleted_by_user1' : 'deleted_by_user2';
        Database::execute("UPDATE messages SET $col = 1 WHERE conversation_type = 'secret_meeting' AND conversation_id = ?", [$roomId]);

        $partnerId = $isUser1 ? (int) $room['user2_id'] : (int) $room['user1_id'];

        $this->bale->answerCallbackQuery($callbackId, '🗑 پیام‌ها برای شما حذف شد');
        $this->bale->sendMessage(
            $chatId,
            '🗑 تاریخچه گفتگو برای شما حذف شد (برای طرف مقابل باقی می‌ماند)',
            $this->bale->secretMeetingChatKeyboard($partnerId, $roomId)
        );
    }

    private function handleReportUser(array $user, string $callbackId, int $partnerId): void
    {
        $chatId = (int) $user['bale_id'];
        $partner = User::findById($partnerId);
        
        if (!$partner) {
            $this->bale->answerCallbackQuery($callbackId, '❌ کاربر یافت نشد', true);
            return;
        }

        // شروع فرآیند گزارش با درخواست دلیل
        User::updateStep($user['id'], 'report_reason', [
            'reported_id' => $partnerId,
            'source' => 'secret_chat',
            'room_id' => $user['current_secret_meeting_room_id'] ?? null,
        ]);

        $this->bale->answerCallbackQuery($callbackId, 'لطفاً دلیل گزارش را بنویسید');
        $this->bale->sendMessage(
            $chatId,
            "🚨 *گزارش کاربر*\n\n"
            . "دلیل گزارش این کاربر را بنویسید:\n"
            . "• محتوای نامناسب\n"
            . "• مزاحمت\n"
            . "• پروفایل فیک\n"
            . "• سایر موارد\n\n"
            . "حداقل ۱۰ کاراکتر بنویسید.\n"
            . "برای انصراف /cancel بزنید",
            $this->bale->removeKeyboard()
        );
    }
}
