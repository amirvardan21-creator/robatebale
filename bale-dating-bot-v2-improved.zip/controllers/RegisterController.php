<?php

/**
 * RegisterController - بهبود یافته
 * - اعتبارسنجی قوی‌تر
 * - پشتیبانی از referral
 * - بهبود UX ثبت‌نام
 * - فیلتر محتوا
 */
class RegisterController
{
    private Bale $bale;

    private const PROVINCES = [
        'تهران','اصفهان','فارس','خراسان رضوی','آذربایجان شرقی',
        'آذربایجان غربی','اردبیل','البرز','ایلام','بوشهر',
        'چهارمحال و بختیاری','خراسان جنوبی','خراسان شمالی','خوزستان','زنجان',
        'سمنان','سیستان و بلوچستان','گیلان','گلستان','همدان',
        'هرمزگان','کردستان','کرمان','کرمانشاه','کهگیلویه و بویراحمد',
        'لرستان','مازندران','مرکزی','قزوین','قم','یزد',
    ];

    public function __construct(Bale $bale)
    {
        $this->bale = $bale;
    }

    private function ageKeyboard(): array
    {
        $rows = [];
        $row  = [];
        for ($i = 18; $i <= 60; $i++) {
            $row[] = ['text' => (string)$i];
            if (count($row) === 5) {
                $rows[] = $row;
                $row = [];
            }
        }
        if ($row) $rows[] = $row;
        $rows[] = [['text' => '🔙 بازگشت']];
        return ['keyboard' => $rows, 'resize_keyboard' => true, 'one_time_keyboard' => true];
    }

    private function provinceKeyboard(): array
    {
        $rows = [];
        $row  = [];
        foreach (self::PROVINCES as $p) {
            $row[] = ['text' => $p];
            if (count($row) === 2) {
                $rows[] = $row;
                $row = [];
            }
        }
        if ($row) $rows[] = $row;
        $rows[] = [['text' => '🔙 بازگشت']];
        return ['keyboard' => $rows, 'resize_keyboard' => true, 'one_time_keyboard' => true];
    }

    private function interestsKeyboard(): array
    {
        return [
            'keyboard' => [
                [['text' => '🎵 موسیقی'], ['text' => '⚽ ورزش'], ['text' => '📚 کتاب']],
                [['text' => '🎬 فیلم'], ['text' => '✈ سفر'], ['text' => '🍳 آشپزی']],
                [['text' => '🎮 گیم'], ['text' => '📸 عکاسی'], ['text' => '💻 تکنولوژی']],
                [['text' => '⏭ رد کردن']],
            ],
            'resize_keyboard' => true,
            'one_time_keyboard' => false,
        ];
    }

    public function start(?array $user, array $from, ?string $referralCode = null): void
    {
        $chatId = (int) $from['id'];

        if (!$user) {
            $referredBy = null;
            if ($referralCode && str_starts_with($referralCode, 'ref_')) {
                $refId = (int) substr($referralCode, 4);
                if ($refId > 0) {
                    $refUser = User::findById($refId);
                    if ($refUser && (int) $refUser['bale_id'] !== $chatId) {
                        $referredBy = $refId;
                    }
                }
            }

            try {
                $userId = User::create(
                    $from['id'],
                    $from['first_name'] ?? 'کاربر',
                    $from['last_name'] ?? null,
                    $from['username'] ?? null,
                    $referredBy
                );
                $user = User::findById($userId);
                
                if ($referredBy) {
                    $refProfile = Profile::findByUserId($referredBy);
                    $refName = $refProfile['name'] ?? 'دوست شما';
                    $this->bale->sendMessage(
                        $chatId,
                        "🎉 شما با دعوت *{$refName}* وارد شدید و " . REFERRAL_BONUS . " سکه جایزه گرفتید!\n\n"
                        . "بیایید پروفایلتان را بسازیم...",
                        $this->bale->removeKeyboard()
                    );
                    sleep(1);
                }
            } catch (Throwable $e) {
                Logger::error("User creation failed: " . $e->getMessage());
                $this->bale->sendMessage($chatId, "❌ خطا در ساخت حساب. لطفاً دوباره /start بزنید.");
                return;
            }
        }

        $profile = Profile::findByUserId($user['id']);

        if ($profile) {
            User::updateStep($user['id'], 'idle');
            
            // جایزه روزانه را بررسی کن
            if (User::canClaimDaily($user['id'])) {
                $daily = User::claimDailyBonus($user['id']);
                if ($daily['success']) {
                    $this->bale->sendMessage($chatId, $daily['message']);
                    sleep(1);
                }
            }

            $level = User::getLevel($user['id']);
            $balance = Coin::getBalance($user['id']);
            
            $this->bale->sendMessage(
                $chatId,
                "سلام {$profile['name']} عزیز! 👋\n\n"
                . "{$level['icon']} *{$level['title']}* | سطح {$level['level']}\n"
                . "💰 موجودی: {$balance} سکه\n"
                . "🔥 استریک: " . ($user['daily_streak'] ?? 0) . " روز\n\n"
                . "به ربات مافیا مچ خوش برگشتی! 😎",
                $this->bale->mainMenuKeyboard()
            );
            return;
        }

        User::updateStep($user['id'], 'register_name');
        $this->bale->sendMessage(
            $chatId,
            "👋 *سلام! به ربات دوستیابی مافیا مچ خوش آمدید*\n\n"
            . "🎩 اینجا جاییه که می‌تونی دوستای جدید پیدا کنی، چت مخفیانه داشته باشی و وارد خانواده مافیا بشی!\n\n"
            . "برای شروع، *نام* خودت رو وارد کن:\n"
            . "(۲ تا ۳۰ کاراکتر، بدون عدد و کاراکتر خاص)",
            $this->bale->removeKeyboard()
        );
    }

    public function handle(array $user, string $text, ?array $photo): void
    {
        $chatId   = (int) $user['bale_id'];
        $step     = $user['step'];
        $stepData = User::getStepData($user) ?? [];

        if ($text === '🔙 بازگشت') {
            // بازگشت به مرحله قبل
            $prevStep = match($step) {
                'register_age' => 'register_name',
                'register_gender' => 'register_age',
                'register_city' => 'register_gender',
                'register_bio' => 'register_city',
                'register_interests' => 'register_bio',
                'register_photo' => 'register_interests',
                default => null
            };
            
            if ($prevStep) {
                User::updateStep($user['id'], $prevStep, $stepData);
                $this->handleBack($user, $prevStep);
                return;
            }
        }

        switch ($step) {
            case 'register_name':
                $text = trim($text);
                if (!Validator::name($text)) {
                    $this->bale->sendMessage($chatId, "❌ *نام نامعتبر*\n\nنام باید:\n• ۲ تا ۳۰ کاراکتر باشد\n• فقط حروف فارسی یا انگلیسی\n• بدون عدد و کاراکتر خاص\n\nلطفاً دوباره وارد کنید:");
                    return;
                }
                
                // فیلتر کلمات نامناسب
                if (ProfanityFilter::containsProfanity($text)) {
                    $this->bale->sendMessage($chatId, "❌ نام شما حاوی کلمات نامناسب است. لطفاً نام دیگری انتخاب کنید.");
                    return;
                }

                $stepData['name'] = htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
                User::updateStep($user['id'], 'register_age', $stepData);
                $this->bale->sendMessage($chatId, "✅ عالیه، {$text}!\n\n🎂 حالا *سن* خودت رو انتخاب کن (۱۸ تا ۸۰):", $this->ageKeyboard());
                break;

            case 'register_age':
                $age = (int) $text;
                if (!Validator::age($age)) {
                    $this->bale->sendMessage($chatId, '❌ سن باید بین ۱۸ تا ۸۰ باشد. لطفاً از دکمه‌ها انتخاب کنید:', $this->ageKeyboard());
                    return;
                }
                $stepData['age'] = $age;
                User::updateStep($user['id'], 'register_gender', $stepData);
                $this->bale->sendMessage($chatId, "✅ سن: {$age} سال\n\n⚧ *جنسیت* خود را انتخاب کن:", [
                    'keyboard' => [[['text' => '👨 آقا'], ['text' => '👩 خانم']], [['text' => '🔙 بازگشت']]],
                    'resize_keyboard' => true,
                    'one_time_keyboard' => true,
                ]);
                break;

            case 'register_gender':
                $gender = null;
                if (str_contains($text, 'آقا') || str_contains($text, 'مرد') || $text === '👨') $gender = 'male';
                elseif (str_contains($text, 'خانم') || str_contains($text, 'زن') || $text === '👩') $gender = 'female';
                
                if (!$gender) {
                    $this->bale->sendMessage($chatId, '❌ لطفاً از دکمه‌ها استفاده کن:', [
                        'keyboard' => [[['text' => '👨 آقا'], ['text' => '👩 خانم']]],
                        'resize_keyboard' => true,
                    ]);
                    return;
                }
                $stepData['gender'] = $gender;
                User::updateStep($user['id'], 'register_city', $stepData);
                $genderText = $gender === 'male' ? 'آقا' : 'خانم';
                $this->bale->sendMessage($chatId, "✅ جنسیت: {$genderText}\n\n📍 *استان* خودت رو انتخاب کن:", $this->provinceKeyboard());
                break;

            case 'register_city':
                if (!Validator::city($text)) {
                    $this->bale->sendMessage($chatId, '❌ لطفاً یک استان معتبر از دکمه‌ها انتخاب کن:', $this->provinceKeyboard());
                    return;
                }
                $stepData['city'] = $text;
                User::updateStep($user['id'], 'register_bio', $stepData);
                $this->bale->sendMessage(
                    $chatId,
                    "✅ استان: {$text}\n\n📝 حالا یه *بیوگرافی جذاب* بنویس:\n"
                    . "(هر چیزی که دوست داری دیگران بدونن - علایق، شخصیت، هدف از آشنایی...)\n\n"
                    . "💡 *نکته:* بیوگرافی خوب شانس مچ شدنت رو بیشتر می‌کنه!\n\n"
                    . "یا اگه فعلاً نمی‌خوای بنویسی:",
                    ['keyboard' => [[['text' => '⏭ رد کردن']], [['text' => '🔙 بازگشت']]], 'resize_keyboard' => true]
                );
                break;

            case 'register_bio':
                if ($text === '⏭ رد کردن') {
                    $stepData['bio'] = null;
                } else {
                    if (!Validator::bio($text)) {
                        $this->bale->sendMessage($chatId, "❌ بیوگرافی باید بین ۳ تا " . MAX_BIO_LENGTH . " کاراکتر باشد:");
                        return;
                    }
                    
                    $check = ProfanityFilter::checkBio($text);
                    if (!$check['valid']) {
                        $this->bale->sendMessage($chatId, "❌ " . $check['message']);
                        return;
                    }

                    $stepData['bio'] = Validator::sanitizeBio($text);
                }
                
                User::updateStep($user['id'], 'register_interests', $stepData);
                $this->bale->sendMessage(
                    $chatId,
                    "✅ ثبت شد!\n\n🎯 *علایقت* چیه؟ چند تا انتخاب کن یا بنویس:",
                    $this->interestsKeyboard()
                );
                break;

            case 'register_interests':
                if ($text === '⏭ رد کردن') {
                    $stepData['interests'] = null;
                } else {
                    // اجازه چند انتخاب
                    $current = $stepData['interests'] ?? '';
                    if (str_contains($text, '🎵') || str_contains($text, '⚽') || str_contains($text, '📚') || 
                        str_contains($text, '🎬') || str_contains($text, '✈') || str_contains($text, '🍳') ||
                        str_contains($text, '🎮') || str_contains($text, '📸') || str_contains($text, '💻')) {
                        
                        // ایموجی را حذف و متن تمیز را نگه دار
                        $clean = trim(str_replace(['🎵','⚽','📚','🎬','✈','🍳','🎮','📸','💻'], '', $text));
                        if ($current) {
                            if (!str_contains($current, $clean)) {
                                $stepData['interests'] = $current . '، ' . $clean;
                            }
                        } else {
                            $stepData['interests'] = $clean;
                        }
                        
                        $this->bale->sendMessage(
                            $chatId,
                            "✅ اضافه شد: {$clean}\n"
                            . "فعلی: {$stepData['interests']}\n\n"
                            . "باز هم انتخاب کن یا برای ادامه:",
                            ['keyboard' => [[['text' => '✅ ادامه']], [['text' => '⏭ رد کردن']], [['text' => '🔙 بازگشت']]], 'resize_keyboard' => true]
                        );
                        User::updateStep($user['id'], 'register_interests', $stepData);
                        return;
                    } elseif ($text === '✅ ادامه') {
                        // ادامه به مرحله بعد
                    } else {
                        // متن سفارشی
                        $stepData['interests'] = htmlspecialchars(mb_substr($text, 0, 200), ENT_QUOTES, 'UTF-8');
                    }
                }
                
                $stepData['looking_for'] = null;
                User::updateStep($user['id'], 'register_photo', $stepData);
                $this->bale->sendMessage(
                    $chatId,
                    "✅ عالی!\n\n📸 آخرین مرحله: *عکس پروفایل* خودت رو بفرست\n\n"
                    . "📷 عکس با کیفیت و واضح بذار تا بیشتر دیده بشی!\n"
                    . "🔒 عکس فقط برای کاربران تایید شده نمایش داده میشه\n\n"
                    . "یا رد کن:",
                    ['keyboard' => [[['text' => '⏭ رد کردن']], [['text' => '🔙 بازگشت']]], 'resize_keyboard' => true]
                );
                break;

            case 'register_photo':
                if ($text === '⏭ رد کردن') {
                    $stepData['photo_file_id'] = null;
                } elseif ($photo) {
                    $stepData['photo_file_id'] = end($photo)['file_id'];
                } else {
                    $this->bale->sendMessage($chatId, '❌ لطفاً یک *عکس* ارسال کن یا دکمه رد کردن رو بزن:');
                    return;
                }
                
                try {
                    Profile::create($user['id'], $stepData);
                    User::updateStep($user['id'], 'idle');
                    
                    $level = User::getLevel($user['id']);
                    
                    $this->bale->sendMessage(
                        $chatId,
                        "🎉 *تبریک! پروفایلت با موفقیت ساخته شد*\n\n"
                        . "👤 نام: {$stepData['name']}\n"
                        . "🎂 سن: {$stepData['age']} | 📍 {$stepData['city']}\n"
                        . "{$level['icon']} سطح: {$level['title']}\n\n"
                        . "🎁 " . START_BONUS . " سکه هدیه ثبت‌نام دریافت کردی!\n\n"
                        . "💡 *چطور شروع کنم؟*\n"
                        . "• ❤️ پیدا کردن دوست - پروفایل‌ها رو ببین و لایک کن\n"
                        . "• 🕶 ملاقات مخفیانه - چت ناشناس با افراد جدید\n"
                        . "• 🎁 جایزه روزانه - هر روز بیا و سکه بگیر\n\n"
                        . "آماده‌ای؟ از منوی پایین شروع کن! 👇",
                        $this->bale->mainMenuKeyboard()
                    );
                    
                    Logger::logUserAction($user['id'], 'registration_completed');
                    
                    // اعلان به ادمین (اختیاری)
                    try {
                        if (ADMIN_BALE_ID > 0 && ADMIN_BALE_ID !== $chatId) {
                            $bale = $this->bale;
                            $bale->sendMessage(
                                ADMIN_BALE_ID,
                                "🆕 کاربر جدید: {$stepData['name']} ({$stepData['age']} ساله، {$stepData['city']})\n"
                                . "ID: {$user['id']} | Bale: {$chatId}"
                            );
                        }
                    } catch (Throwable $e) {}
                    
                } catch (Throwable $e) {
                    Logger::error("Profile creation failed: " . $e->getMessage());
                    $this->bale->sendMessage($chatId, "❌ خطا در ساخت پروفایل: " . $e->getMessage() . "\nلطفاً دوباره تلاش کن یا /start بزن.");
                }
                break;
        }
    }

    private function handleBack(array $user, string $step): void
    {
        $chatId = (int) $user['bale_id'];
        $stepData = User::getStepData($user) ?? [];
        
        $messages = [
            'register_name' => "👤 نام خودت رو وارد کن:",
            'register_age' => "🎂 سن خودت رو انتخاب کن:",
            'register_gender' => "⚧ جنسیت خودت رو انتخاب کن:",
            'register_city' => "📍 استان خودت رو انتخاب کن:",
            'register_bio' => "📝 بیوگرافی خودت رو بنویس:",
            'register_interests' => "🎯 علایقت رو انتخاب کن:",
            'register_photo' => "📸 عکس پروفایلت رو بفرست:",
        ];

        $this->bale->sendMessage($chatId, $messages[$step] ?? "بازگشت...", $this->bale->removeKeyboard());
        
        if ($step === 'register_age') {
            $this->bale->sendMessage($chatId, "سن:", $this->ageKeyboard());
        } elseif ($step === 'register_city') {
            $this->bale->sendMessage($chatId, "استان:", $this->provinceKeyboard());
        }
    }
}
