-- Migration: Add Secret Meeting Chat System Tables and Columns
-- Date: 2026-07-25

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- Create secret_meeting_rooms table
CREATE TABLE `secret_meeting_rooms` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user1_id` INT UNSIGNED NOT NULL,
  `user2_id` INT UNSIGNED NOT NULL,
  `status` ENUM('active', 'ended_by_user1', 'ended_by_user2', 'ended_mutually', 'aborted') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `ended_at` TIMESTAMP NULL DEFAULT NULL,
  `search_type` ENUM('random', 'gender_male', 'gender_female', 'province') NULL DEFAULT NULL,
  `province_filter` VARCHAR(255) NULL DEFAULT NULL,
  `gender_filter` ENUM('male', 'female') NULL DEFAULT NULL,
  FOREIGN KEY (`user1_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`user2_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create secret_meeting_queue table
CREATE TABLE `secret_meeting_queue` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL UNIQUE,
  `search_preference` ENUM('random', 'gender_male', 'gender_female', 'province') NOT NULL,
  `gender_preference` ENUM('male', 'female') NULL DEFAULT NULL,
  `province_preference` VARCHAR(255) NULL DEFAULT NULL,
  `vip_priority` TINYINT(1) DEFAULT 0, -- 0 for regular, 1 for VIP (for future use)
  `queued_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `last_ping_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_search_preference` (`search_preference`),
  INDEX `idx_gender_preference` (`gender_preference`),
  INDEX `idx_province_preference` (`province_preference`),
  INDEX `idx_vip_priority` (`vip_priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add current_status and current_secret_meeting_room_id to users table
ALTER TABLE `users`
ADD COLUMN `current_status` ENUM('idle', 'in_queue', 'in_secret_meeting') DEFAULT 'idle' AFTER `step_data`,
ADD COLUMN `current_secret_meeting_room_id` INT UNSIGNED NULL DEFAULT NULL AFTER `current_status`,
ADD CONSTRAINT `fk_current_secret_meeting_room` FOREIGN KEY (`current_secret_meeting_room_id`) REFERENCES `secret_meeting_rooms`(`id`) ON DELETE SET NULL;

-- Modify messages table for conversation_type and conversation_id
-- First, add the new columns with default values, allowing NULL temporarily
ALTER TABLE `messages`
ADD COLUMN `conversation_type` ENUM('match', 'secret_meeting') DEFAULT 'match' AFTER `match_id`,
ADD COLUMN `conversation_id` INT UNSIGNED DEFAULT NULL AFTER `conversation_type`;

-- Update existing messages to reflect 'match' type and use match_id as conversation_id
UPDATE `messages` SET `conversation_type` = 'match', `conversation_id` = `match_id`;

-- Make conversation_id NOT NULL after updating existing rows
ALTER TABLE `messages`
MODIFY COLUMN `conversation_id` INT UNSIGNED NOT NULL;

-- Add deleted_by_user1 and deleted_by_user2 to messages table
ALTER TABLE `messages`
ADD COLUMN `deleted_by_user1` TINYINT(1) DEFAULT 0 AFTER `type`,
ADD COLUMN `deleted_by_user2` TINYINT(1) DEFAULT 0 AFTER `deleted_by_user1`;

-- Drop the old match_id foreign key constraint and then the column itself
ALTER TABLE `messages`
DROP FOREIGN KEY `messages_ibfk_1`;

ALTER TABLE `messages`
DROP COLUMN `match_id`;

SET FOREIGN_KEY_CHECKS = 1;