<?php
/**
 * CLI Match Maker - نسخه بهبود یافته v2.0
 * 
 * وظایف:
 * ۱. پاکسازی اتاق‌های منقضی شده (>60 دقیقه)
 * ۲. پاکسازی صف stale (>10 دقیقه آفلاین)
 * ۳. پاکسازی وضعیت‌های یتیم
 * ۴. پاکسازی rate_limits قدیمی
 * ۵. پاکسازی VIP منقضی شده
 * ۶. مچ کردن کاربران باقی‌مانده
 * ۷. ارسال آمار به ادمین (اختیاری)
 * 
 * Cron: * * * * * php /path/to/cli_match_maker.php >> logs/cron.log 2>&1
 */

if (php_sapi_name() !== 'cli') {
    die("CLI only\n");
}

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../classes/Database.php';
require_once __DIR__ . '/../classes/Logger.php';
require_once __DIR__ . '/../classes/Bale.php';
require_once __DIR__ . '/../classes/User.php';
require_once __DIR__ . '/../classes/Profile.php';
require_once __DIR__ . '/../classes/Vip.php';
require_once __DIR__ . '/../classes/Coin.php';
require_once __DIR__ . '/../classes/BlockReport.php';
require_once __DIR__ . '/../classes/Schema.php';
require_once __DIR__ . '/../classes/SecretMeetingQueue.php';
require_once __DIR__ . '/../classes/SecretMeetingRoom.php';
require_once __DIR__ . '/../classes/RateLimiter.php';
require_once __DIR__ . '/../classes/MatchModel.php';
require_once __DIR__ . '/../classes/Validator.php';
require_once __DIR__ . '/../classes/ProfanityFilter.php';
require_once __DIR__ . '/../controllers/ChatController.php';

try {
    Schema::ensureAll();
} catch (Throwable $e) {
    Logger::error('cli_match_maker: Schema failed: ' . $e->getMessage());
}

$startTime = microtime(true);
echo "[" . date('Y-m-d H:i:s') . "] Match Maker v2.0 started\n";
Logger::info('cli_match_maker v2.0 started');

$bale = new Bale();

// === CLEANUP PHASE ===
$totalCleaned = 0;

// ۱. اتاق‌های منقضی
$expiredRooms = 0;
try {
    $expiredRooms = SecretMeetingRoom::cleanupExpired();
    echo "✓ Cleaned $expiredRooms expired rooms (>{$bale->getProvinces()[0]} min)\n";
    $totalCleaned += $expiredRooms;
} catch (Throwable $e) {
    echo "✗ Failed to clean expired rooms: {$e->getMessage()}\n";
    Logger::error("Clean expired rooms failed: " . $e->getMessage());
}

// ۲. صف stale
$staleCount = 0;
try {
    $staleCount = SecretMeetingQueue::cleanStaleEntries();
    echo "✓ Cleaned $staleCount stale queue entries\n";
    $totalCleaned += $staleCount;
} catch (Throwable $e) {
    echo "✗ Clean stale failed: {$e->getMessage()}\n";
}

// ۳. وضعیت‌های یتیم
$orphanCount = 0;
try {
    $orphanCount = SecretMeetingQueue::cleanOrphanedStatuses();
    echo "✓ Cleaned $orphanCount orphaned statuses\n";
    $totalCleaned += $orphanCount;
} catch (Throwable $e) {
    echo "✗ Clean orphaned failed: {$e->getMessage()}\n";
}

// ۴. rate_limits
$rateLimitCleaned = 0;
try {
    $rateLimitCleaned = RateLimiter::cleanup();
    echo "✓ Cleaned $rateLimitCleaned old rate limits\n";
    $totalCleaned += $rateLimitCleaned;
} catch (Throwable $e) {
    echo "✗ Rate limit cleanup failed: {$e->getMessage()}\n";
}

// ۵. VIP منقضی
$vipCleaned = 0;
try {
    $vipCleaned = Vip::cleanupExpired();
    if ($vipCleaned > 0) echo "✓ Cleaned $vipCleaned expired VIPs\n";
} catch (Throwable $e) {
    echo "✗ VIP cleanup failed: {$e->getMessage()}\n";
}

// ۶. Reset daily counts if needed (hour 0)
if (date('H') === '00') {
    try {
        // این کار در Profile::resetDailyCountsIfNeeded به صورت lazy انجام می‌شود
        // اما برای اطمینان می‌توان اینجا هم اجرا کرد
        echo "✓ Daily reset check (lazy reset enabled)\n";
    } catch (Throwable $e) {}
}

// === MATCHMAKING PHASE ===
$queuedUsers = [];
try {
    $queuedUsers = Database::fetchAll('SELECT user_id FROM secret_meeting_queue ORDER BY vip_priority DESC, queued_at ASC');
} catch (Throwable $e) {
    echo "✗ Failed to get queue: {$e->getMessage()}\n";
    Logger::error("Get queue failed: " . $e->getMessage());
    exit(1);
}

if (empty($queuedUsers)) {
    $elapsed = round((microtime(true) - $startTime) * 1000);
    echo "No users in queue. Finished in {$elapsed}ms (cleaned $totalCleaned)\n";
    Logger::info("cli_match_maker: no queue, cleaned $totalCleaned, {$elapsed}ms");
    exit(0);
}

echo "Found " . count($queuedUsers) . " users in queue\n";
Logger::info('cli_match_maker: processing ' . count($queuedUsers) . ' users');

$matchedPairs = 0;
$notifiedUsers = 0;

foreach ($queuedUsers as $row) {
    $userId = (int) $row['user_id'];

    $user = User::findById($userId);
    if (!$user || ($user['current_status'] ?? 'idle') !== 'in_queue') {
        try { SecretMeetingQueue::removeFromQueue($userId); } catch (Throwable $e) {}
        continue;
    }

    // اگر کاربر بلاک شده، از صف حذف
    if (User::isBlocked($userId)) {
        try { SecretMeetingQueue::removeFromQueue($userId); } catch (Throwable $e) {}
        echo "User $userId is blocked, removed from queue\n";
        continue;
    }

    $match = SecretMeetingQueue::tryMatchUser($userId);

    if (!$match) {
        echo "No match for $userId\n";
        continue;
    }

    $roomId = (int) $match['room_id'];
    $partnerId = (int) $match['partner_user_id'];
    $partnerBale = (int) $match['partner_bale_id'];
    $myBaleId = (int) $match['my_bale_id'];

    echo "✓ Matched $userId <-> $partnerId in room $roomId\n";
    Logger::info("Matched $userId <-> $partnerId room $roomId");

    $matchedPairs++;

    // پیام جذاب‌تر
    $partnerProfile = Profile::findByUserId($partnerId);
    $partnerName = $partnerProfile['name'] ?? 'کاربری';

    $msg1 = "🎉 *یک نفر پیدا شد!*\n\n"
          . "🕶 چت مخفیانه با {$partnerName} برقرار شد\n"
          . "💬 همین الان پیام بده!\n\n"
          . "⚠️ چت ناشناسه - مراقب اطلاعات شخصی باش";

    $myProfile = Profile::findByUserId($userId);
    $myName = $myProfile['name'] ?? 'کاربری';

    $msg2 = "🎉 *یک نفر پیدا شد!*\n\n"
          . "🕶 چت مخفیانه با {$myName} برقرار شد\n"
          . "💬 همین الان پیام بده!\n\n"
          . "⚠️ چت ناشناسه - مراقب اطلاعات شخصی باش";

    try {
        $bale->sendMessage($myBaleId, $msg1, $bale->secretMeetingChatKeyboard($partnerId, $roomId));
        $bale->sendMessage($partnerBale, $msg2, $bale->secretMeetingChatKeyboard($userId, $roomId));
        $notifiedUsers += 2;
    } catch (Throwable $e) {
        echo "Failed to notify: {$e->getMessage()}\n";
        Logger::error("Notify failed: " . $e->getMessage());
    }

    // کمی تاخیر برای جلوگیری از فشار به API
    usleep(200000); // 0.2s
}

$elapsed = round((microtime(true) - $startTime) * 1000);
echo "[" . date('Y-m-d H:i:s') . "] Finished: matched $matchedPairs pairs, notified $notifiedUsers users, cleaned $totalCleaned, {$elapsed}ms\n";
Logger::info("cli_match_maker finished: matched $matchedPairs, notified $notifiedUsers, cleaned $totalCleaned, {$elapsed}ms");

// آمار روزانه: اگر ساعت 9 صبح است، گزارش به ادمین
if (date('H') === '09' && date('i') < 2) {
    try {
        if (ADMIN_BALE_ID > 0) {
            $stats = [
                'users' => User::count(),
                'active' => User::countActive(),
                'online' => User::countOnline(10),
                'rooms_today' => SecretMeetingRoom::getStats()['today'] ?? 0,
                'vip' => Database::fetch('SELECT COUNT(*) as cnt FROM vip_users WHERE is_active = 1 AND expires_at > NOW()')['cnt'] ?? 0,
            ];
            
            $bale->sendMessage(
                ADMIN_BALE_ID,
                "📊 *گزارش روزانه ربات* (" . date('Y-m-d') . ")\n\n"
                . "👥 کل کاربران: {$stats['users']}\n"
                . "✅ فعال: {$stats['active']}\n"
                . "🟢 آنلاین (۱۰ دقیقه): {$stats['online']}\n"
                . "🕶 چت امروز: {$stats['rooms_today']}\n"
                . "⭐ VIP فعال: {$stats['vip']}\n"
                . "🧹 پاکسازی: {$totalCleaned}\n"
                . "⏱ زمان اجرا: {$elapsed}ms"
            );
        }
    } catch (Throwable $e) {
        Logger::error("Daily report failed: " . $e->getMessage());
    }
}

exit(0);
