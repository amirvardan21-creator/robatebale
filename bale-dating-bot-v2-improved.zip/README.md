# 🎩 ربات دوستیابی بله - مافیا مچ (نسخه 2.0 بهبود یافته)

ربات دوستیابی حرفه‌ای برای پیام‌رسان **بله** - بازطراحی شده با امنیت، سرعت و امکانات بیشتر

> نسخه اصلی از فایل زیپ شما استخراج و به طور کامل بازنویسی و بهبود یافت.

---

## ✨ چی بهبود یافته؟ (نسبت به نسخه 1)

### 🔐 امنیت
- ✅ حذف توکن هاردکد شده از گیت - استفاده از `.env`
- ✅ Rate Limiting ضد اسپم (پیام، لایک، صف)
- ✅ فیلتر کلمات نامناسب و لینک
- ✅ اعتبارسنجی قوی تمام ورودی‌ها (Validator class)
- ✅ CSRF protection پنل ادمین
- ✅ محافظت از لاگ‌ها و آپلودها با `.htaccess`
- ✅ لاگ امنیتی جدا (security.log)
- ✅ تشخیص خودکار کاربران متخلف و گزارش به ادمین

### 🚀 امکانات جدید
- 🎁 **جایزه روزانه** - هر روز بیا و سکه بگیر، استریک بساز و جایزه بیشتر بگیر (`/daily`)
- 👥 **دعوت دوستان** - لینک اختصاصی دعوت، برای هر دعوت ۲۰ سکه (`/invite`)
- 💰 **فروشگاه سکه** - خرید بوست، سوپر لایک، VIP با سکه
- 🏆 **برترین‌ها** - نمایش برترین کاربران بر اساس سکه و محبوبیت (`/top`)
- 💘 **سوپر لایک** - لایک ویژه با اعلان برای طرف مقابل (۵ سکه)
- 📸 **ارسال عکس در چت** - امکان ارسال عکس در چت‌های خصوصی
- 🔥 **سطح کاربری** - سیستم Level: تازه‌وارد تا پدرخوانده
- 📊 **آمار دقیق** - بازدید، لایک، مچ، استریک روزانه
- 🕶 **ملاقات مخفیانه بهبود یافته** - تخمین زمان انتظار، نمایش آنلاین‌ها
- ⭐ **VIP پیشرفته** - پلن‌های روزانه، هفتگی، ماهانه، فصلی، سالانه
- 🚀 **بوست پروفایل** - ۲۴ ساعت در اولویت نمایش (۲۰ سکه)

### 🏗 معماری و کیفیت کد
- ✅ کلاس‌های جدید: `Validator`, `RateLimiter`, `ProfanityFilter`
- ✅ بهبود `Bale.php`: retry logic، مدیریت خطاهای 429، sanitize Markdown
- ✅ بهبود `Database.php`: transaction helper، slow query log، retry اتصال
- ✅ بهبود `Logger.php`: چرخش خودکار، پاکسازی لاگ‌های قدیمی، سطح‌بندی
- ✅ بهبود `Schema.php`: مهاجرت خودکار برای تمام جداول جدید
- ✅ بهبود تمام Controller ها با UX بهتر و پیام‌های جذاب
- ✅ Webhook جدید با پشتیبانی از عکس و referral
- ✅ CLI بهبود یافته با پاکسازی کامل و گزارش روزانه به ادمین
- ✅ `.env` پشتیبانی و `composer.json`
- ✅ نصب‌کننده جدید با بررسی پرمیشن‌ها و راهنمای کامل

### 💬 تجربه کاربری
- پیام‌های فارسی روان و مودبانه با ایموجی
- کیبوردهای هوشمند و منوهای واضح
- پیش‌نمایش پروفایل از دید دیگران
- مدیریت بلاک شده‌ها
- تاریخچه تراکنش‌ها
- راهنمای کامل `/help`

---

## 📁 ساختار پروژه v2

```
bale-dating-bot v2/
├── .env.example              # نمونه تنظیمات
├── composer.json             # وابستگی‌ها
├── config/
│   ├── config.php            # لود .env + تعریف ثابت‌ها
│   └── .htaccess
├── classes/
│   ├── Bale.php              # ✨ بهبود یافته: retry, rate limit handling
│   ├── Database.php          # ✨ transaction, slow query log
│   ├── Logger.php            # ✨ rotation, security log
│   ├── Validator.php         # 🆕 اعتبارسنجی ورودی‌ها
│   ├── RateLimiter.php       # 🆕 ضد اسپم
│   ├── ProfanityFilter.php   # 🆕 فیلتر محتوا
│   ├── User.php              # ✨ referral, daily bonus, level
│   ├── Profile.php           # ✨ boost, stats, online status
│   ├── MatchModel.php        # ✨ super like, unread, history
│   ├── Coin.php              # ✨ transfer, shop, safe deduct
│   ├── Vip.php               # ✨ پلن‌های متنوع، خرید با سکه
│   ├── BlockReport.php       # ✨ auto-check, admin notify
│   ├── SecretMeetingQueue.php
│   ├── SecretMeetingRoom.php # ✨ max duration, stats
│   └── Schema.php            # ✨ تمام جداول جدید
├── controllers/
│   ├── RegisterController.php   # ✨ referral + UX بهتر
│   ├── DiscoveryController.php  # ✨ super like + who liked me
│   ├── ProfileController.php    # ✨ آمار، بلاک لیست، پیش‌نمایش
│   ├── ChatController.php       # ✨ عکس در چت، هدیه بهبود یافته
│   ├── SecretMeetingController.php # ✨ wait time, daily limit
│   └── SettingsController.php   # ✨ shop, VIP, privacy
├── webhook/
│   ├── index.php             # ✨ referral, photo, /daily, /invite, /top
│   └── setup.php             # تنظیم webhook
├── admin/                    # پنل مدیریت (بهبود یافته)
├── cli/
│   └── cli_match_maker.php   # ✨ cleanup کامل + گزارش روزانه
├── database/
│   └── database.sql          # ✨ اسکیما کامل v2 با ایندکس‌های بهتر
├── logs/  (auto created)
├── uploads/ (auto created)
└── install.php               # ✨ نصب‌کننده جدید با چک پرمیشن
```

---

## 🚀 نصب سریع

### 1. آپلود و تنظیم .env
```bash
# فایل‌ها را در public_html/bale/ آپلود کن
cp .env.example .env
nano .env
# مقادیر BOT_TOKEN, DB_*, BASE_URL, ADMIN_BALE_ID را پر کن
```

### 2. نصب دیتابیس
مرورگر: `https://yourdomain.com/bale/install.php`
- جداول ساخته می‌شود
- پوشه logs و uploads چک می‌شود

### 3. پنل ادمین
`https://yourdomain.com/bale/admin/setup_password.php`
- یوزر و پس جدید بساز
- سپس `setup_password.php` و `install.php` را حذف کن!

### 4. Cron Job (الزامی!)
cPanel → Cron Jobs:
```
* * * * * php /home/username/public_html/bale/cli/cli_match_maker.php >> /home/username/public_html/bale/logs/cron.log 2>&1
```

### 5. Webhook
```
https://yourdomain.com/bale/webhook/setup.php?secret=YOUR_SECRET&action=set
```

### 6. تست
در بله به رباتت برو و `/start` بزن!

---

## 🎮 دستورات ربات

| دستور | توضیح |
|-------|-------|
| `/start` | شروع یا بازگشت به منو (پشتیبانی از `ref_123` برای دعوت) |
| `/daily` | دریافت جایزه روزانه + استریک |
| `/coins` | مشاهده موجودی و تاریخچه |
| `/invite` | لینک دعوت و آمار دعوت‌ها |
| `/top` | برترین کاربران |
| `/help` | راهنمای کامل |
| `/cancel` | لغو عملیات فعلی |

### دکمه‌های اصلی
- 🕶 ملاقات مخفیانه - چت ناشناس (شانسی رایگان، جنسیتی ۲ سکه، استانی ۴ سکه)
- ❤️ پیدا کردن دوست - لایک/دیسلایک، سوپر لایک
- 💬 گفتگوهای من - لیست مچ‌ها با پیام آخر و آنلاین بودن
- 📁 پرونده من - پروفایل + آمار + بلاک لیست
- 💰 ثروت من - سکه و تراکنش‌ها
- 🎁 جایزه روزانه - استریک و بونوس
- 👥 دعوت دوستان - لینک و جوایز
- 🏆 برترین‌ها - لیدربورد
- 💎 خرید اشتراک - VIP با سکه
- ⚙ تنظیمات - حریم خصوصی، فروشگاه، گزارش

---

## 💎 سیستم سکه (جدید)

**درآمد سکه:**
- ثبت‌نام: ۱۰ سکه
- هر مچ: ۲ سکه برای هر طرف
- چت مخفیانه کامل (۱۰+ پیام): ۱ سکه
- جایزه روزانه: ۵ + استریک (تا ۱۰)
- دعوت هر دوست: ۲۰ سکه
- هدیه ادمین

**خرج سکه:**
- جستجوی جنسیتی: ۲ سکه
- جستجوی استانی: ۴ سکه
- ارسال هدیه: ۱۰ سکه
- سوپر لایک: ۵ سکه
- بوست پروفایل ۲۴ساعته: ۲۰ سکه
- VIP: روزانه ۱۵، هفتگی ۵۰، ماهانه ۱۰۰، سه ماهه ۲۵۰، سالانه ۸۰۰

---

## 🔒 امنیت - چک‌لیست

- [ ] `.env` را از گیت خارج کن (در .gitignore هست)
- [ ] `config.php` واقعی را کامیت نکن
- [ ] `install.php` را بعد نصب حذف کن
- [ ] `admin/setup_password.php` را حذف کن
- [ ] پوشه `logs/` و `uploads/` را 755 کن و `.htaccess` داخلشان باشد
- [ ] توکن ربات را در جای امن نگه دار
- [ ] SSL (https) الزامی برای webhook
- [ ] Cron Job را فعال کن
- [ ] فایل‌های دیباگ (`debug.php`, `apitest.php`) را در production حذف کن

---

## 🛠 تکنولوژی

- PHP 8.1+ (توصیه 8.2)
- MySQL 5.7+ / MariaDB 10.3+
- PDO, cURL, mbstring, json
- Bale Bot API
- بدون نیاز به فریم‌ورک خارجی (سبک و سریع)
- اختیاری: Composer + vlucas/phpdotenv

---

## 📊 بهینه‌سازی‌های اعمال شده

1. **Query Performance:** ایندکس‌های جدید برای `last_seen_at`, `current_status`, `conversation`, `boost_until`
2. **Race Condition:** `SELECT ... FOR UPDATE` در مچ‌سازی، `transaction` در کسر سکه
3. **Slow Query Log:** لاگ خودکار کوئری‌های کند >500ms
4. **Cache ساده:** `static` memoization برای `tableExists`, `columnExists`
5. **Rate Limit:** جدول `rate_limits` با پاکسازی ساعتی
6. **Log Rotation:** لاگ‌های قدیمی >۷ روز حذف، فایل‌های >۱۰MB چرخش

---

## 🤝 مشارکت

اگر باگ پیدا کردی یا پیشنهادی داری:
- Issue باز کن
- یا به پشتیبانی پیام بده

---

## 📄 لایسنس

MIT - استفاده آزاد با ذکر منبع

---

## 🙏 تشکر

از تیم بله برای API عالی، و از شما برای استفاده از این ربات!

**نسخه:** 2.0.0 - تاریخ: 2026-07-27
**نویسنده بهبود:** Arena Agent - برای amirvardan21-creator/robatebale

> 🎩 به خانواده مافیا خوش اومدی!
