<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../classes/Database.php';
require_once __DIR__ . '/../classes/Logger.php';
require_once __DIR__ . '/../classes/User.php';
require_once __DIR__ . '/../classes/Profile.php';
require_once __DIR__ . '/../classes/MatchModel.php';
require_once __DIR__ . '/../classes/BlockReport.php';
require_once __DIR__ . '/../classes/Bale.php';
require_once __DIR__ . '/../classes/Vip.php';
require_once __DIR__ . '/../classes/Coin.php';
require_once __DIR__ . '/includes/helpers.php';

function adminAuth(): void
{
    if (empty($_SESSION['admin_logged_in'])) {
        header('Location: index.php');
        exit;
    }
}

$error = '';
$page  = $_GET['page'] ?? $_POST['page'] ?? 'login';
$msg   = '';

$protectedPages = ['dashboard', 'users', 'user_detail', 'reports', 'broadcast', 'settings', 'coins'];

if (isset($_SESSION['admin_logged_in']) && $page === 'login') {
    header('Location: index.php?page=dashboard');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $page === 'login') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $admin = Database::fetch('SELECT * FROM admins WHERE username = ?', [$username]);
    if ($admin && password_verify($password, $admin['password_hash'])) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_username']  = $admin['username'];
        // تولید CSRF token جدید بعد از لاگین
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        Database::execute('UPDATE admins SET last_login = NOW() WHERE id = ?', [$admin['id']]);
        header('Location: index.php?page=dashboard');
        exit;
    }
    $error = 'نام کاربری یا رمز عبور اشتباه است.';
}

if ($page === 'logout') {
    session_destroy();
    header('Location: index.php');
    exit;
}

if (isset($_SESSION['admin_logged_in']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    adminAuth();

    // اعتبارسنجی CSRF برای تمام درخواست‌های POST محافظت‌شده
    if (!csrfVerify()) {
        $_SESSION['flash'] = '❌ توکن امنیتی نامعتبر است. لطفاً دوباره تلاش کنید.';
        $rp = in_array($page, $protectedPages, true) ? $page : 'dashboard';
        $extra = isset($_GET['uid']) ? '&uid=' . (int) $_GET['uid'] : '';
        header('Location: index.php?page=' . $rp . $extra);
        exit;
    }

    $action = $_POST['action'] ?? '';

    if ($action === 'block_user') {
        User::block((int) $_POST['user_id']);
        $msg = 'کاربر مسدود شد.';
    } elseif ($action === 'unblock_user') {
        User::unblock((int) $_POST['user_id']);
        $msg = 'مسدودیت برداشته شد.';
    } elseif ($action === 'delete_user') {
        User::delete((int) $_POST['user_id']);
        $msg = 'کاربر حذف شد.';
        header('Location: index.php?page=users');
        $_SESSION['flash'] = $msg;
        exit;
    } elseif ($action === 'grant_vip') {
        Vip::activate((int) $_POST['user_id'], $_POST['plan'] ?? 'monthly');
        $msg = 'VIP فعال شد.';
    } elseif ($action === 'revoke_vip') {
        Database::execute('UPDATE vip_users SET is_active = 0 WHERE user_id = ?', [(int) $_POST['user_id']]);
        $msg = 'VIP لغو شد.';
    } elseif ($action === 'add_coins') {
        $uid    = (int) $_POST['user_id'];
        $amount = (int) $_POST['amount'];
        $desc   = trim($_POST['desc'] ?? 'افزوده شده توسط ادمین');
        if ($amount > 0 && tableExists('coins')) {
            Coin::add($uid, $amount, $desc);
            $msg = "{$amount} سکه اضافه شد.";
        } elseif (!tableExists('coins')) {
            $msg = 'جدول سکه نصب نشده است.';
        }
    } elseif ($action === 'deduct_coins') {
        $uid    = (int) $_POST['user_id'];
        $amount = (int) $_POST['amount'];
        $desc   = trim($_POST['desc'] ?? 'کسر شده توسط ادمین');
        if ($amount > 0 && tableExists('coins')) {
            Coin::deduct($uid, $amount, $desc);
            $msg = "{$amount} سکه کسر شد.";
        }
    } elseif ($action === 'set_coins') {
        $uid    = (int) $_POST['user_id'];
        $amount = (int) $_POST['amount'];
        if (tableExists('coins')) {
            Coin::set($uid, $amount);
            $msg = "موجودی سکه به {$amount} تنظیم شد.";
        }
    } elseif ($action === 'resolve_report') {
        BlockReport::updateReportStatus((int) $_POST['report_id'], 'resolved', $_POST['note'] ?? 'حل شده توسط ادمین');
        $msg = 'گزارش حل شد.';
    } elseif ($action === 'block_from_report') {
        $uid = (int) $_POST['reported_user_id'];
        User::block($uid);
        BlockReport::updateReportStatus((int) $_POST['report_id'], 'resolved', 'کاربر مسدود شد');
        $msg = 'کاربر مسدود و گزارش بسته شد.';
    } elseif ($action === 'update_setting') {
        Database::execute('UPDATE settings SET value = ? WHERE `key` = ?', [$_POST['value'], $_POST['key']]);
        $msg = 'تنظیم ذخیره شد.';
    } elseif ($action === 'broadcast') {
        $bale = new Bale();
        $text = trim($_POST['message'] ?? '');
        if ($text) {
            $users = Database::fetchAll('SELECT bale_id FROM users WHERE is_active = 1 AND is_blocked = 0');
            $sent  = 0;
            foreach ($users as $u) {
                $bale->sendMessage((int) $u['bale_id'], $text);
                usleep(60000);
                $sent++;
            }
            $msg = "پیام برای {$sent} کاربر ارسال شد.";
        }
    } elseif ($action === 'send_dm') {
        $uid  = (int) $_POST['user_id'];
        $text = trim($_POST['message'] ?? '');
        $user = User::findById($uid);
        if ($user && $text) {
            $bale = new Bale();
            $bale->sendMessage((int) $user['bale_id'], "🎩 پیام از مدیریت مافیا مچ:\n\n" . $text);
            $msg = 'پیام ارسال شد.';
        }
    }

    $userActions = ['block_user', 'unblock_user', 'grant_vip', 'revoke_vip', 'add_coins', 'deduct_coins', 'set_coins', 'send_dm'];
    if (in_array($action, $userActions, true) && !empty($_POST['user_id'])) {
        $rp = 'user_detail';
        $extra = '&uid=' . (int) $_POST['user_id'];
    } else {
        $rp = in_array($page, $protectedPages, true) ? $page : 'dashboard';
        $extra = isset($_GET['uid']) ? '&uid=' . (int) $_GET['uid'] : '';
    }
    if ($msg) {
        $_SESSION['flash'] = $msg;
    }
    header('Location: index.php?page=' . $rp . $extra);
    exit;
}

if (isset($_SESSION['flash'])) {
    $msg = $_SESSION['flash'];
    unset($_SESSION['flash']);
}

if (in_array($page, $protectedPages, true)) {
    adminAuth();
}

$pendingReports = 0;
try {
    $row = Database::fetch('SELECT COUNT(*) AS cnt FROM reports WHERE status = "pending"');
    $pendingReports = (int) ($row['cnt'] ?? 0);
} catch (Throwable) {
}

switch ($page) {
    case 'dashboard':
        $stats = [
            'total_users'     => User::count(),
            'active_users'    => User::countActive(),
            'vip_users'       => (int) (Database::fetch('SELECT COUNT(*) AS cnt FROM vip_users WHERE is_active = 1 AND expires_at > NOW()')['cnt'] ?? 0),
            'matches'         => (int) (Database::fetch('SELECT COUNT(*) AS cnt FROM matches WHERE is_active = 1')['cnt'] ?? 0),
            'today_users'     => (int) (Database::fetch('SELECT COUNT(*) AS cnt FROM users WHERE DATE(created_at) = CURDATE()')['cnt'] ?? 0),
            'total_coins'     => safeTotalCoins(),
            'pending_reports' => $pendingReports,
            'blocked_users'   => (int) (Database::fetch('SELECT COUNT(*) AS cnt FROM users WHERE is_blocked = 1')['cnt'] ?? 0),
        ];
        $recentUsers = Database::fetchAll(
            'SELECT u.*, p.name, p.city FROM users u LEFT JOIN profiles p ON u.id = p.user_id ORDER BY u.created_at DESC LIMIT 8'
        );
        $recentReports = Database::fetchAll(
            'SELECT r.*, p1.name AS reporter_name, p2.name AS reported_name
             FROM reports r
             LEFT JOIN profiles p1 ON p1.user_id = r.reporter_id
             LEFT JOIN profiles p2 ON p2.user_id = r.reported_id
             ORDER BY r.created_at DESC LIMIT 6'
        );
        break;

    case 'users':
        $searchQuery = trim($_GET['q'] ?? '');
        $currentPage = max(1, (int) ($_GET['p'] ?? 1));
        $perPage     = 20;
        $offset      = ($currentPage - 1) * $perPage;

        if ($searchQuery) {
            $users = User::search($searchQuery);
            $totalUsers = count($users);
            $users = array_slice($users, $offset, $perPage);
        } else {
            $totalUsers = User::count();
            $users = User::getAll($perPage, $offset);
        }

        foreach ($users as &$u) {
            $u['coins']  = safeCoinBalance((int) $u['id']);
            $u['is_vip'] = Vip::isVip((int) $u['id']);
        }
        unset($u);

        $totalPages = max(1, (int) ceil($totalUsers / $perPage));
        break;

    case 'user_detail':
        $uid = (int) ($_GET['uid'] ?? 0);
        $userDetail = Database::fetch(
            'SELECT u.*, p.id AS profile_id, p.name, p.age, p.gender, p.city, p.bio, p.interests, p.looking_for, p.is_visible,
                    (SELECT COUNT(*) FROM matches m WHERE (m.user1_id = u.id OR m.user2_id = u.id) AND m.is_active = 1) AS match_count
             FROM users u
             LEFT JOIN profiles p ON p.user_id = u.id
             WHERE u.id = ?',
            [$uid]
        );
        break;

    case 'reports':
        $reportStatus = $_GET['status'] ?? 'pending';
        if ($reportStatus === 'all') {
            $reports = Database::fetchAll(
                'SELECT r.*, p1.name AS reporter_name, p2.name AS reported_name,
                        u1.bale_id AS reporter_bale_id, u2.bale_id AS reported_bale_id
                 FROM reports r
                 JOIN users u1 ON r.reporter_id = u1.id
                 JOIN users u2 ON r.reported_id = u2.id
                 LEFT JOIN profiles p1 ON p1.user_id = r.reporter_id
                 LEFT JOIN profiles p2 ON p2.user_id = r.reported_id
                 ORDER BY r.created_at DESC LIMIT 50'
            );
        } else {
            $reports = Database::fetchAll(
                'SELECT r.*, p1.name AS reporter_name, p2.name AS reported_name,
                        u1.bale_id AS reporter_bale_id, u2.bale_id AS reported_bale_id
                 FROM reports r
                 JOIN users u1 ON r.reporter_id = u1.id
                 JOIN users u2 ON r.reported_id = u2.id
                 LEFT JOIN profiles p1 ON p1.user_id = r.reporter_id
                 LEFT JOIN profiles p2 ON p2.user_id = r.reported_id
                 WHERE r.status = ?
                 ORDER BY r.created_at DESC LIMIT 50',
                [$reportStatus]
            );
        }
        break;

    case 'broadcast':
        $broadcastCount = (int) (Database::fetch('SELECT COUNT(*) AS cnt FROM users WHERE is_active = 1 AND is_blocked = 0')['cnt'] ?? 0);
        break;

    case 'settings':
        $settings = Database::fetchAll('SELECT * FROM settings ORDER BY id ASC');
        $settingLabels = [
            'bot_active'           => 'وضعیت ربات',
            'maintenance_message'  => 'پیام حالت تعمیر',
            'free_daily_views'     => 'محدودیت مشاهده روزانه (رایگان)',
            'free_daily_likes'     => 'محدودیت لایک روزانه (رایگان)',
            'vip_monthly_price'    => 'قیمت VIP ماهانه (تومان)',
            'welcome_message'      => 'پیام خوش‌آمد',
        ];
        break;

    case 'coins':
        $totalCoins = safeTotalCoins();
        $topUsers   = safeTopCoinUsers(15);
        $coinHolders = 0;
        $totalTransactions = 0;
        $recentTransactions = [];

        if (tableExists('coins')) {
            $coinHolders = (int) (Database::fetch('SELECT COUNT(*) AS cnt FROM coins WHERE balance > 0')['cnt'] ?? 0);
        }
        if (tableExists('coin_transactions')) {
            $totalTransactions = (int) (Database::fetch('SELECT COUNT(*) AS cnt FROM coin_transactions')['cnt'] ?? 0);
            $recentTransactions = Database::fetchAll(
                'SELECT ct.*, p.name, u.bale_id
                 FROM coin_transactions ct
                 JOIN users u ON ct.user_id = u.id
                 LEFT JOIN profiles p ON p.user_id = u.id
                 ORDER BY ct.created_at DESC LIMIT 15'
            );
        }
        break;
}

if ($page === 'login') {
    include __DIR__ . '/views/login.php';
    exit;
}

if (!in_array($page, $protectedPages, true)) {
    header('Location: index.php?page=dashboard');
    exit;
}

include __DIR__ . '/views/layout.php';
