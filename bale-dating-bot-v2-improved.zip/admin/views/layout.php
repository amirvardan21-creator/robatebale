<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= h(adminPageTitle($page)) ?> | مافیا مچ</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="layout">
    <aside class="sidebar">
        <div class="sidebar-logo">
            <span class="skull">🎩</span>
            <h2>مافیا <span class="brand-accent">مچ</span></h2>
            <span>ربات دوستیابی بله</span>
        </div>

        <nav class="sidebar-nav">
            <div class="nav-section">فرماندهی</div>
            <a href="index.php?page=dashboard" class="nav-item <?= $page === 'dashboard' ? 'active' : '' ?>">
                <span class="icon">📊</span> داشبورد
            </a>
            <a href="index.php?page=users" class="nav-item <?= in_array($page, ['users', 'user_detail']) ? 'active' : '' ?>">
                <span class="icon">👥</span> اعضا
            </a>
            <a href="index.php?page=coins" class="nav-item <?= $page === 'coins' ? 'active' : '' ?>">
                <span class="icon">🪙</span> خزانه سکه
            </a>

            <div class="nav-section">عملیات</div>
            <a href="index.php?page=reports" class="nav-item <?= $page === 'reports' ? 'active' : '' ?>">
                <span class="icon">🚨</span> گزارشات
                <?php if (($pendingReports ?? 0) > 0): ?>
                    <span class="nav-badge"><?= (int) $pendingReports ?></span>
                <?php endif; ?>
            </a>
            <a href="index.php?page=broadcast" class="nav-item <?= $page === 'broadcast' ? 'active' : '' ?>">
                <span class="icon">📢</span> پیام همگانی
            </a>
            <a href="index.php?page=settings" class="nav-item <?= $page === 'settings' ? 'active' : '' ?>">
                <span class="icon">⚙</span> تنظیمات
            </a>
        </nav>

        <div class="sidebar-footer">
            <div class="admin-info">
                <div class="admin-avatar">🎩</div>
                <div>
                    <div class="admin-name"><?= h($_SESSION['admin_username'] ?? 'admin') ?></div>
                    <div class="admin-role">رئیس خانواده</div>
                </div>
            </div>
            <a href="index.php?page=logout" class="btn btn-ghost btn-sm btn-block">خروج</a>
        </div>
    </aside>

    <div class="main">
        <header class="topbar">
            <div class="topbar-title">
                <?= h(adminPageTitle($page)) ?>
                <span>مافیا مچ</span>
            </div>
            <div class="topbar-meta"><?= date('Y/m/d H:i') ?></div>
        </header>

        <div class="content">
            <?php if ($msg): ?>
                <div class="alert alert-success"><?= h($msg) ?></div>
            <?php endif; ?>

            <?php include __DIR__ . '/pages/' . $page . '.php'; ?>
        </div>
    </div>
</div>
</body>
</html>
