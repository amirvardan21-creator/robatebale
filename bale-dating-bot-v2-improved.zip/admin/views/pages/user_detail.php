<?php if (!$userDetail): ?>
    <div class="alert alert-danger">عضو یافت نشد.</div>
    <a href="index.php?page=users" class="btn btn-ghost">بازگشت</a>
<?php else: ?>
<?php
    $u = $userDetail;
    $initial = mb_substr($u['name'] ?? $u['first_name'], 0, 1);
    $isVip = Vip::isVip($u['id']);
    $vipInfo = $isVip ? Vip::getInfo($u['id']) : null;
    $coins = safeCoinBalance($u['id']);
    $transactions = safeCoinTransactions($u['id']);
?>

<a href="index.php?page=users" class="btn btn-ghost btn-sm" style="margin-bottom:20px">← بازگشت به لیست</a>

<div class="user-header">
    <div class="user-avatar-lg"><?= h($initial) ?></div>
    <div class="user-meta">
        <h2><?= h($u['name'] ?? $u['first_name']) ?></h2>
        <p>
            شناسه بله: <code><?= h($u['bale_id']) ?></code>
            <?php if ($u['username']): ?> | @<?= h($u['username']) ?><?php endif; ?>
        </p>
        <div class="user-badges">
            <?php if ($u['is_blocked']): ?>
                <span class="badge badge-blocked">🚫 مسدود</span>
            <?php else: ?>
                <span class="badge badge-active">✅ فعال</span>
            <?php endif; ?>
            <?php if ($isVip): ?>
                <span class="badge badge-vip">⭐ VIP — <?= h($vipInfo['plan'] ?? '') ?></span>
            <?php endif; ?>
            <?php if (!$u['profile_id']): ?>
                <span class="badge badge-pending">پروفایل ناقص</span>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="grid-2">
    <div class="card">
        <div class="card-title"><span class="icon">📋</span> اطلاعات پروفایل</div>
        <div class="info-grid">
            <div class="info-item"><div class="lbl">نام</div><div class="val"><?= h($u['name'] ?? '—') ?></div></div>
            <div class="info-item"><div class="lbl">سن</div><div class="val"><?= h($u['age'] ?? '—') ?></div></div>
            <div class="info-item"><div class="lbl">جنسیت</div><div class="val"><?= genderLabel($u['gender'] ?? null) ?></div></div>
            <div class="info-item"><div class="lbl">شهر</div><div class="val"><?= h($u['city'] ?? '—') ?></div></div>
            <div class="info-item"><div class="lbl">علایق</div><div class="val"><?= h($u['interests'] ?? '—') ?></div></div>
            <div class="info-item"><div class="lbl">دنبال</div><div class="val"><?= h($u['looking_for'] ?? '—') ?></div></div>
            <div class="info-item"><div class="lbl">مچ‌ها</div><div class="val"><?= (int)($u['match_count'] ?? 0) ?></div></div>
            <div class="info-item"><div class="lbl">ثبت‌نام</div><div class="val"><?= formatDate($u['created_at']) ?></div></div>
        </div>
        <?php if (!empty($u['bio'])): ?>
            <hr class="divider">
            <div class="info-item" style="grid-column:1/-1">
                <div class="lbl">بیوگرافی</div>
                <div class="val" style="font-weight:400;margin-top:6px"><?= h($u['bio']) ?></div>
            </div>
        <?php endif; ?>
    </div>

    <div>
        <div class="coin-balance">
            <div class="amount">🪙 <?= number_format($coins) ?></div>
            <div class="label">موجودی سکه</div>
        </div>

        <?php if ($isVip): ?>
        <div class="vip-box">
            <div class="crown">👑</div>
            <h3>عضو ویژه فعال</h3>
            <p>انقضا: <?= formatDate($vipInfo['expires_at'] ?? null) ?></p>
            <p>پلن: <?= h($vipInfo['plan'] ?? 'monthly') ?></p>
        </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-title"><span class="icon">🪙</span> مدیریت سکه</div>
            <form method="POST" class="action-grid">
                <?= csrfField() ?>
                <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                <div class="form-group">
                    <label>افزودن سکه</label>
                    <input type="number" name="amount" min="1" placeholder="مقدار" required>
                </div>
                <div class="form-group">
                    <label>توضیح</label>
                    <input type="text" name="desc" placeholder="دلیل افزودن">
                </div>
                <button type="submit" name="action" value="add_coins" class="btn btn-gold btn-sm">➕ افزودن</button>
            </form>
            <hr class="divider">
            <form method="POST" class="action-grid">
                <?= csrfField() ?>
                <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                <div class="form-group">
                    <label>کسر سکه</label>
                    <input type="number" name="amount" min="1" placeholder="مقدار" required>
                </div>
                <div class="form-group">
                    <label>توضیح</label>
                    <input type="text" name="desc" placeholder="دلیل کسر">
                </div>
                <button type="submit" name="action" value="deduct_coins" class="btn btn-danger btn-sm">➖ کسر</button>
            </form>
            <hr class="divider">
            <form method="POST" style="display:flex;gap:10px;align-items:flex-end">
                <?= csrfField() ?>
                <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                <div class="form-group" style="flex:1;margin:0">
                    <label>تنظیم مستقیم موجودی</label>
                    <input type="number" name="amount" min="0" value="<?= $coins ?>" required>
                </div>
                <button type="submit" name="action" value="set_coins" class="btn btn-ghost btn-sm">تنظیم</button>
            </form>
        </div>
    </div>
</div>

<div class="grid-2">
    <div class="card">
        <div class="card-title"><span class="icon">⭐</span> عضویت ویژه</div>
        <?php if ($isVip): ?>
            <p style="margin-bottom:16px;color:var(--text-secondary);font-size:13px">این عضو در حال حاضر VIP است.</p>
            <form method="POST" onsubmit="return confirm('VIP لغو شود؟')">
                <?= csrfField() ?>
                <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                <button type="submit" name="action" value="revoke_vip" class="btn btn-danger btn-sm">❌ لغو VIP</button>
            </form>
        <?php else: ?>
            <form method="POST">
                <?= csrfField() ?>
                <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                <div class="form-group">
                    <label>پلن VIP</label>
                    <select name="plan">
                        <option value="monthly">ماهانه (۳۰ روز)</option>
                        <option value="quarterly">سه‌ماهه (۹۰ روز)</option>
                        <option value="yearly">سالانه (۳۶۵ روز)</option>
                    </select>
                </div>
                <button type="submit" name="action" value="grant_vip" class="btn btn-gold">👑 اعطای VIP</button>
            </form>
        <?php endif; ?>
    </div>

    <div class="card">
        <div class="card-title"><span class="icon">🛡</span> کنترل دسترسی</div>
        <div class="action-grid">
            <?php if ($u['is_blocked']): ?>
                <form method="POST">
                    <?= csrfField() ?>
                    <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                    <button type="submit" name="action" value="unblock_user" class="btn btn-success btn-sm btn-block">✅ رفع مسدودیت</button>
                </form>
            <?php else: ?>
                <form method="POST" onsubmit="return confirm('این عضو مسدود شود؟')">
                    <?= csrfField() ?>
                    <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                    <button type="submit" name="action" value="block_user" class="btn btn-danger btn-sm btn-block">🚫 مسدود کردن</button>
                </form>
            <?php endif; ?>

            <form method="POST" onsubmit="return confirm('⚠️ این عضو و تمام اطلاعاتش حذف شود؟')">
                <?= csrfField() ?>
                <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                <button type="submit" name="action" value="delete_user" class="btn btn-ghost btn-sm btn-block">🗑 حذف کامل</button>
            </form>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-title"><span class="icon">💬</span> ارسال پیام مستقیم</div>
    <form method="POST">
        <?= csrfField() ?>
        <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
        <div class="form-group">
            <label>پیام به <?= h($u['name'] ?? $u['first_name']) ?> در بله</label>
            <textarea name="message" placeholder="پیام شما..." required></textarea>
        </div>
        <button type="submit" name="action" value="send_dm" class="btn btn-primary">📨 ارسال پیام</button>
    </form>
</div>

<?php if (!empty($transactions)): ?>
<div class="card">
    <div class="card-title"><span class="icon">📜</span> تاریخچه تراکنش سکه</div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>نوع</th>
                    <th>مقدار</th>
                    <th>توضیح</th>
                    <th>تاریخ</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($transactions as $tx): ?>
                <tr>
                    <td>
                        <?php if ($tx['type'] === 'add'): ?>
                            <span class="badge badge-active">➕ افزودن</span>
                        <?php else: ?>
                            <span class="badge badge-blocked">➖ کسر</span>
                        <?php endif; ?>
                    </td>
                    <td><strong><?= number_format(abs((int)$tx['amount'])) ?></strong></td>
                    <td><?= h($tx['description'] ?? '—') ?></td>
                    <td><?= formatDate($tx['created_at']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php endif; ?>
