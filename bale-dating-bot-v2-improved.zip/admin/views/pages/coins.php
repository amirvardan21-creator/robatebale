<?php if (!tableExists('coins')): ?>
<div class="alert alert-danger">
    🪙 جدول سکه نصب نشده. فایل <code>add_coins_table.php</code> یا <code>install.php</code> را اجرا کنید.
</div>
<?php endif; ?>

<div class="stats-grid" style="grid-template-columns:repeat(3,1fr)">
    <div class="stat-card gold">
        <div class="stat-icon">🪙</div>
        <div class="stat-value"><?= number_format($totalCoins) ?></div>
        <div class="stat-label">کل سکه در گردش</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">👤</div>
        <div class="stat-value"><?= number_format($coinHolders) ?></div>
        <div class="stat-label">دارنده سکه</div>
    </div>
    <div class="stat-card green">
        <div class="stat-icon">📜</div>
        <div class="stat-value"><?= number_format($totalTransactions) ?></div>
        <div class="stat-label">تراکنش‌ها</div>
    </div>
</div>

<div class="grid-2">
    <div class="card">
        <div class="card-title"><span class="icon">🏆</span> ثروتمندترین اعضا</div>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>رتبه</th>
                        <th>نام</th>
                        <th>شناسه بله</th>
                        <th>سکه</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($topUsers)): ?>
                    <tr><td colspan="5" class="empty-cell">داده‌ای وجود ندارد</td></tr>
                <?php else: ?>
                    <?php foreach ($topUsers as $i => $u): ?>
                    <tr>
                        <td><?= $i + 1 ?></td>
                        <td><strong><?= h($u['name'] ?? '—') ?></strong></td>
                        <td><code><?= h($u['bale_id']) ?></code></td>
                        <td><span class="coin-inline">🪙 <?= number_format($u['balance']) ?></span></td>
                        <td><a href="index.php?page=user_detail&uid=<?= (int)$u['user_id'] ?>" class="btn btn-xs btn-ghost">مدیریت</a></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <div class="card-title"><span class="icon">⚡</span> مدیریت سریع سکه</div>
        <p class="card-desc">شناسه داخلی عضو (ID) را وارد کنید:</p>
        <form method="GET" class="search-bar">
            <input type="hidden" name="page" value="user_detail">
            <input type="number" name="uid" placeholder="شناسه عضو (ID)" required min="1">
            <button type="submit" class="btn btn-primary btn-sm">رفتن به پروفایل</button>
        </form>

        <hr class="divider">

        <div class="card-title" style="margin-top:0"><span class="icon">🔍</span> جستجو با شناسه بله</div>
        <form method="GET" class="search-bar">
            <input type="hidden" name="page" value="users">
            <input type="text" name="q" placeholder="شناسه بله...">
            <button type="submit" class="btn btn-ghost btn-sm">جستجو</button>
        </form>
    </div>
</div>

<?php if (!empty($recentTransactions)): ?>
<div class="card">
    <div class="card-title"><span class="icon">📜</span> آخرین تراکنش‌ها</div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>عضو</th>
                    <th>نوع</th>
                    <th>مقدار</th>
                    <th>توضیح</th>
                    <th>تاریخ</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recentTransactions as $tx): ?>
                <tr>
                    <td>
                        <strong><?= h($tx['name'] ?? '—') ?></strong>
                        <br><code style="font-size:11px"><?= h($tx['bale_id'] ?? '') ?></code>
                    </td>
                    <td>
                        <?php if ($tx['type'] === 'add'): ?>
                            <span class="badge badge-active">➕</span>
                        <?php else: ?>
                            <span class="badge badge-blocked">➖</span>
                        <?php endif; ?>
                    </td>
                    <td><strong><?= number_format(abs((int)$tx['amount'])) ?></strong></td>
                    <td><?= h($tx['description'] ?? '—') ?></td>
                    <td><?= formatDate($tx['created_at']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>
