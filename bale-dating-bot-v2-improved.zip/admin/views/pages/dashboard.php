<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon">👥</div>
        <div class="stat-value"><?= number_format($stats['total_users']) ?></div>
        <div class="stat-label">کل اعضا</div>
    </div>
    <div class="stat-card green">
        <div class="stat-icon">✅</div>
        <div class="stat-value"><?= number_format($stats['active_users']) ?></div>
        <div class="stat-label">اعضای فعال</div>
    </div>
    <div class="stat-card gold">
        <div class="stat-icon">⭐</div>
        <div class="stat-value"><?= number_format($stats['vip_users']) ?></div>
        <div class="stat-label">عضو ویژه</div>
    </div>
    <div class="stat-card blue">
        <div class="stat-icon">💘</div>
        <div class="stat-value"><?= number_format($stats['matches']) ?></div>
        <div class="stat-label">مچ فعال</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">🆕</div>
        <div class="stat-value"><?= number_format($stats['today_users']) ?></div>
        <div class="stat-label">عضو جدید امروز</div>
    </div>
    <div class="stat-card gold">
        <div class="stat-icon">🪙</div>
        <div class="stat-value"><?= number_format($stats['total_coins']) ?></div>
        <div class="stat-label">کل سکه در گردش</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">🚨</div>
        <div class="stat-value"><?= number_format($stats['pending_reports']) ?></div>
        <div class="stat-label">گزارش در انتظار</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">🚫</div>
        <div class="stat-value"><?= number_format($stats['blocked_users']) ?></div>
        <div class="stat-label">مسدود شده</div>
    </div>
</div>

<div class="grid-2">
    <div class="card">
        <div class="card-title"><span class="icon">🆕</span> آخرین اعضا</div>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>نام</th>
                        <th>شناسه بله</th>
                        <th>شهر</th>
                        <th>تاریخ</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($recentUsers)): ?>
                    <tr><td colspan="5" class="empty-cell">هنوز عضوی ثبت نشده</td></tr>
                <?php else: ?>
                    <?php foreach ($recentUsers as $u): ?>
                    <tr>
                        <td><strong><?= h($u['name'] ?? $u['first_name']) ?></strong></td>
                        <td><code><?= h($u['bale_id']) ?></code></td>
                        <td><?= h($u['city'] ?? '—') ?></td>
                        <td><?= formatDate($u['created_at']) ?></td>
                        <td><a href="index.php?page=user_detail&uid=<?= (int)$u['id'] ?>" class="btn btn-xs btn-ghost">مشاهده</a></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <div class="card-title"><span class="icon">🚨</span> آخرین گزارشات</div>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>گزارش‌دهنده</th>
                        <th>متهم</th>
                        <th>دلیل</th>
                        <th>وضعیت</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($recentReports)): ?>
                    <tr><td colspan="4" class="empty-cell">گزارشی وجود ندارد</td></tr>
                <?php else: ?>
                    <?php foreach ($recentReports as $r): ?>
                    <tr>
                        <td><?= h($r['reporter_name'] ?? '—') ?></td>
                        <td><?= h($r['reported_name'] ?? '—') ?></td>
                        <td><?= h(mb_substr($r['reason'], 0, 40)) ?></td>
                        <td>
                            <?php if ($r['status'] === 'pending'): ?>
                                <span class="badge badge-pending">در انتظار</span>
                            <?php elseif ($r['status'] === 'resolved'): ?>
                                <span class="badge badge-active">حل شده</span>
                            <?php else: ?>
                                <span class="badge badge-blocked"><?= h($r['status']) ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if ($stats['pending_reports'] > 0): ?>
            <div style="margin-top:16px">
                <a href="index.php?page=reports" class="btn btn-primary btn-sm">بررسی گزارشات (<?= (int)$stats['pending_reports'] ?>)</a>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="card">
    <div class="card-title"><span class="icon">⚡</span> دسترسی سریع</div>
    <div class="quick-actions">
        <a href="index.php?page=users" class="quick-btn">👥 مدیریت اعضا</a>
        <a href="index.php?page=coins" class="quick-btn">🪙 خزانه سکه</a>
        <a href="index.php?page=broadcast" class="quick-btn">📢 پیام همگانی</a>
        <a href="index.php?page=settings" class="quick-btn">⚙ تنظیمات ربات</a>
    </div>
</div>
