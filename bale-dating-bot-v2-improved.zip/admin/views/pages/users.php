<div class="card">
    <div class="card-title"><span class="icon">🔍</span> جستجوی اعضا</div>
    <form method="GET" class="search-bar">
        <input type="hidden" name="page" value="users">
        <input type="text" name="q" value="<?= h($searchQuery) ?>" placeholder="نام، شناسه بله، یوزرنیم...">
        <button type="submit" class="btn btn-primary">جستجو</button>
        <?php if ($searchQuery): ?>
            <a href="index.php?page=users" class="btn btn-ghost">پاک کردن</a>
        <?php endif; ?>
    </form>
</div>

<div class="card">
    <div class="card-title">
        <span class="icon">👥</span>
        لیست اعضا
        <span class="card-subtitle"><?= number_format($totalUsers) ?> عضو</span>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>نام</th>
                    <th>شناسه بله</th>
                    <th>سن</th>
                    <th>شهر</th>
                    <th>جنسیت</th>
                    <th>سکه</th>
                    <th>وضعیت</th>
                    <th>عضویت</th>
                    <th>عملیات</th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($users)): ?>
                <tr><td colspan="10" class="empty-cell">عضوی یافت نشد</td></tr>
            <?php else: ?>
                <?php foreach ($users as $u): ?>
                <tr>
                    <td><?= (int)$u['id'] ?></td>
                    <td><strong><?= h($u['name'] ?? $u['first_name']) ?></strong></td>
                    <td><code><?= h($u['bale_id']) ?></code></td>
                    <td><?= h($u['age'] ?? '—') ?></td>
                    <td><?= h($u['city'] ?? '—') ?></td>
                    <td><?= genderLabel($u['gender'] ?? null) ?></td>
                    <td><span class="coin-inline">🪙 <?= number_format($u['coins'] ?? 0) ?></span></td>
                    <td>
                        <?php if ($u['is_blocked']): ?>
                            <span class="badge badge-blocked">🚫 مسدود</span>
                        <?php elseif ($u['is_active']): ?>
                            <span class="badge badge-active">✅ فعال</span>
                        <?php else: ?>
                            <span class="badge badge-pending">غیرفعال</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($u['is_vip']): ?>
                            <span class="badge badge-vip">⭐ VIP</span>
                        <?php else: ?>
                            <span class="text-muted">عادی</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="index.php?page=user_detail&uid=<?= (int)$u['id'] ?>" class="btn btn-xs btn-primary">مدیریت</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if ($totalPages > 1): ?>
    <div class="pagination">
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <a href="index.php?page=users&p=<?= $i ?><?= $searchQuery ? '&q=' . urlencode($searchQuery) : '' ?>"
               class="page-btn <?= $i === $currentPage ? 'active' : '' ?>"><?= $i ?></a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>
</div>
