<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ورود | مافیا مچ</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="login-wrap">
    <div class="login-box">
        <div class="login-logo">
            <span class="skull">🎩</span>
            <h1>مافیا <span class="brand-accent">مچ</span></h1>
            <p>پنل مدیریت — بله</p>
            <div class="brand-tag">MAFIA MATCH</div>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger">🩸 <?= h($error) ?></div>
        <?php endif; ?>

        <form method="POST" action="index.php?page=login">
            <?= csrfField() ?>
            <div class="form-group">
                <label>نام کاربری</label>
                <input type="text" name="username" placeholder="admin" required autofocus>
            </div>
            <div class="form-group">
                <label>رمز عبور</label>
                <input type="password" name="password" placeholder="••••••••" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">ورود به اتاق فرمان</button>
        </form>

        <p class="login-footer">🔒 دسترسی فقط برای رئیس خانواده</p>
    </div>
</div>
</body>
</html>
