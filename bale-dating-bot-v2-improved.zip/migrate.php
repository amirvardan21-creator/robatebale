<?php
/**
 * اسکریپت مهاجرت دیتابیس — نسخه پیشرفته
 * آدرس: https://a7vbot.ir/bale/migrate.php
 *
 * این اسکریپت:
 *  - همه جداول و ستون‌های مورد نیاز را بررسی می‌کند
 *  - موارد مفقود را اضافه می‌کند
 *  - با MySQL و MariaDB سازگار است (بدون استفاده از ADD COLUMN IF NOT EXISTS)
 *  - Idempotent است — اجرای مکرر مشکلی ایجاد نمی‌کند
 *  - گزارش کاملی از وضعیت می‌دهد
 *
 * بعد از اجرا، این فایل را حذف کنید!
 */

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/classes/Database.php';
require_once __DIR__ . '/classes/Logger.php';
require_once __DIR__ . '/classes/Schema.php';

$log = [];
$success = true;

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    $log[] = ['ok', 'اتصال به دیتابیس: ' . DB_NAME];
} catch (PDOException $e) {
    die('<p style="color:red;font-family:Tahoma;direction:rtl">خطای اتصال: ' . htmlspecialchars($e->getMessage()) . '</p>');
}

// helper: بررسی ستون
function columnExists(PDO $pdo, string $table, string $column): bool {
    try {
        $stmt = $pdo->prepare("SHOW COLUMNS FROM `{$table}` LIKE ?");
        $stmt->execute([$column]);
        return (bool) $stmt->fetch();
    } catch (Throwable $e) {
        return false;
    }
}

// helper: بررسی جدول
function tableExists(PDO $pdo, string $table): bool {
    try {
        $stmt = $pdo->prepare("SHOW TABLES LIKE ?");
        $stmt->execute([$table]);
        return (bool) $stmt->fetch();
    } catch (Throwable $e) {
        return false;
    }
}

// helper: افزودن ستون
function addColumn(PDO $pdo, string $table, string $column, string $definition, array &$log): void {
    if (columnExists($pdo, $table, $column)) {
        $log[] = ['ok', "ستون {$table}.{$column} از قبل وجود دارد"];
        return;
    }
    try {
        $pdo->exec("ALTER TABLE `{$table}` ADD COLUMN `{$column}` {$definition}");
        $log[] = ['ok', "ستون {$table}.{$column} اضافه شد"];
    } catch (PDOException $e) {
        $log[] = ['err', "خطا در افزودن {$table}.{$column}: " . $e->getMessage()];
    }
}

// helper: افزودن ایندکس
function addIndex(PDO $pdo, string $table, string $indexName, string $columns, array &$log): void {
    try {
        $stmt = $pdo->prepare("SELECT 1 FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = ? AND index_name = ?");
        $stmt->execute([$table, $indexName]);
        if ($stmt->fetch()) {
            $log[] = ['ok', "ایندکس {$indexName} روی {$table} از قبل وجود دارد"];
            return;
        }
        $pdo->exec("CREATE INDEX `{$indexName}` ON `{$table}` ({$columns})");
        $log[] = ['ok', "ایندکس {$indexName} روی {$table} ساخته شد"];
    } catch (PDOException $e) {
        $log[] = ['warn', "ایندکس {$indexName}: " . $e->getMessage()];
    }
}

// helper: ساخت جدول
function createTable(PDO $pdo, string $name, string $sql, array &$log): void {
    if (tableExists($pdo, $name)) {
        $log[] = ['ok', "جدول {$name} از قبل وجود دارد"];
        return;
    }
    try {
        $pdo->exec($sql);
        $log[] = ['ok', "جدول {$name} ساخته شد"];
    } catch (PDOException $e) {
        $log[] = ['err', "خطا در ساخت {$name}: " . $e->getMessage()];
    }
}

// ===== 1. جدول users — ستون‌های جدید =====
addColumn($pdo, 'users', 'current_status', "ENUM('idle','in_queue','in_secret_meeting') DEFAULT 'idle'", $log);
addColumn($pdo, 'users', 'current_secret_meeting_room_id', 'INT UNSIGNED NULL DEFAULT NULL', $log);
addColumn($pdo, 'users', 'last_seen_at', 'TIMESTAMP NULL DEFAULT NULL', $log);
addIndex($pdo, 'users', 'idx_last_seen', '`last_seen_at`', $log);
addIndex($pdo, 'users', 'idx_current_status', '`current_status`', $log);

// ===== 2. جدول secret_meeting_rooms =====
createTable($pdo, 'secret_meeting_rooms', "CREATE TABLE `secret_meeting_rooms` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user1_id` INT UNSIGNED NOT NULL,
  `user2_id` INT UNSIGNED NOT NULL,
  `status` ENUM('active','ended_by_user1','ended_by_user2','ended_mutually','aborted') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `ended_at` TIMESTAMP NULL DEFAULT NULL,
  `search_type` ENUM('random','gender_male','gender_female','province') NULL DEFAULT NULL,
  `province_filter` VARCHAR(255) NULL DEFAULT NULL,
  `gender_filter` ENUM('male','female') NULL DEFAULT NULL,
  INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci", $log);

// ===== 3. جدول secret_meeting_queue =====
createTable($pdo, 'secret_meeting_queue', "CREATE TABLE `secret_meeting_queue` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL UNIQUE,
  `search_preference` ENUM('random','gender_male','gender_female','province') NOT NULL,
  `gender_preference` ENUM('male','female') NULL DEFAULT NULL,
  `province_preference` VARCHAR(255) NULL DEFAULT NULL,
  `vip_priority` TINYINT(1) DEFAULT 0,
  `queued_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `last_ping_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_search_preference` (`search_preference`),
  INDEX `idx_gender_preference` (`gender_preference`),
  INDEX `idx_province_preference` (`province_preference`),
  INDEX `idx_vip_priority` (`vip_priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci", $log);

// ===== 4. جدول coins و coin_transactions =====
createTable($pdo, 'coins', "CREATE TABLE `coins` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL,
  `balance` INT UNSIGNED DEFAULT 0,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_user_id` (`user_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci", $log);

createTable($pdo, 'coin_transactions', "CREATE TABLE `coin_transactions` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL,
  `amount` INT NOT NULL,
  `type` ENUM('add','deduct','spend') DEFAULT 'add',
  `description` VARCHAR(255) DEFAULT NULL,
  `admin_id` INT UNSIGNED DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci", $log);

// ===== 5. جدول messages — migration از match_id به conversation_type/conversation_id =====

// اگر جدول messages وجود ندارد، آن را با اسکیمای جدید بساز
if (!tableExists($pdo, 'messages')) {
    createTable($pdo, 'messages', "CREATE TABLE `messages` (
      `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      `conversation_type` ENUM('match','secret_meeting') NOT NULL DEFAULT 'match',
      `conversation_id` INT UNSIGNED NOT NULL,
      `sender_id` INT UNSIGNED NOT NULL,
      `content` TEXT NOT NULL,
      `type` ENUM('text','photo') DEFAULT 'text',
      `deleted_by_user1` TINYINT(1) DEFAULT 0,
      `deleted_by_user2` TINYINT(1) DEFAULT 0,
      `is_read` TINYINT(1) DEFAULT 0,
      `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      INDEX `idx_conversation` (`conversation_type`, `conversation_id`),
      INDEX `idx_sender` (`sender_id`),
      FOREIGN KEY (`sender_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci", $log);
} else {
    // جدول وجود دارد — ستون‌های جدید را اضافه کن
    addColumn($pdo, 'messages', 'conversation_type', "ENUM('match','secret_meeting') DEFAULT 'match'", $log);
    addColumn($pdo, 'messages', 'conversation_id', 'INT UNSIGNED NULL DEFAULT NULL', $log);
    addColumn($pdo, 'messages', 'deleted_by_user1', 'TINYINT(1) DEFAULT 0', $log);
    addColumn($pdo, 'messages', 'deleted_by_user2', 'TINYINT(1) DEFAULT 0', $log);
    addIndex($pdo, 'messages', 'idx_conversation', '`conversation_type`, `conversation_id`', $log);

    // اگر ستون قدیمی match_id هنوز وجود دارد، migration کن
    if (columnExists($pdo, 'messages', 'match_id')) {
        try {
            // کپی مقادیر
            $cnt = $pdo->exec("UPDATE `messages` SET `conversation_type` = 'match', `conversation_id` = `match_id` WHERE `conversation_id` IS NULL");
            $log[] = ['ok', "migration: {$cnt} ردیف از match_id به conversation_id منتقل شد"];

            // حذف FK اگر وجود دارد
            $fks = $pdo->query("SELECT CONSTRAINT_NAME FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'messages' AND COLUMN_NAME = 'match_id' AND REFERENCED_TABLE_NAME IS NOT NULL")->fetchAll(PDO::FETCH_COLUMN);
            foreach ($fks as $fk) {
                try {
                    $pdo->exec("ALTER TABLE `messages` DROP FOREIGN KEY `{$fk}`");
                    $log[] = ['ok', "FK {$fk} حذف شد"];
                } catch (PDOException $e) {
                    $log[] = ['warn', "حذف FK {$fk}: " . $e->getMessage()];
                }
            }

            // حذف ایندکس قدیمی idx_match_id اگر وجود دارد
            try {
                $pdo->exec("ALTER TABLE `messages` DROP INDEX `idx_match_id`");
                $log[] = ['ok', "ایندکس idx_match_id حذف شد"];
            } catch (PDOException $e) {
                // ignore if not exists
            }

            // حذف ستون match_id
            $pdo->exec("ALTER TABLE `messages` DROP COLUMN `match_id`");
            $log[] = ['ok', "ستون messages.match_id حذف شد"];
        } catch (PDOException $e) {
            $log[] = ['err', 'migration messages: ' . $e->getMessage()];
        }
    }
}

// ===== 6. پاکسازی وضعیت‌های یتیم =====
try {
    $cnt = $pdo->exec("UPDATE `users` SET `current_status` = 'idle', `current_secret_meeting_room_id` = NULL WHERE `current_status` IS NULL");
    if ($cnt > 0) {
        $log[] = ['ok', "تعداد {$cnt} کاربر با current_status NULL به idle تغییر یافت"];
    }
} catch (PDOException $e) {
    $log[] = ['warn', "پاکسازی current_status: " . $e->getMessage()];
}

// ===== 7. بررسی نهایی =====
$checks = [
    'users.current_status' => columnExists($pdo, 'users', 'current_status'),
    'users.current_secret_meeting_room_id' => columnExists($pdo, 'users', 'current_secret_meeting_room_id'),
    'users.last_seen_at' => columnExists($pdo, 'users', 'last_seen_at'),
    'messages.conversation_type' => columnExists($pdo, 'messages', 'conversation_type'),
    'messages.conversation_id' => columnExists($pdo, 'messages', 'conversation_id'),
    'table secret_meeting_rooms' => tableExists($pdo, 'secret_meeting_rooms'),
    'table secret_meeting_queue' => tableExists($pdo, 'secret_meeting_queue'),
    'table coins' => tableExists($pdo, 'coins'),
    'table coin_transactions' => tableExists($pdo, 'coin_transactions'),
];

foreach ($checks as $name => $exists) {
    if (!$exists) {
        $log[] = ['err', "بررسی نهایی: {$name} هنوز مفقود است!"];
        $success = false;
    }
}

if ($success) {
    $log[] = ['ok', '✅ همه جداول و ستون‌های مورد نیاز آماده هستند'];
}

?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>مهاجرت دیتابیس</title>
<style>
body{font-family:Tahoma,Arial,sans-serif;background:#f5f5f5;padding:30px;direction:rtl}
.box{max-width:700px;margin:0 auto;background:#fff;border-radius:10px;padding:25px;box-shadow:0 2px 10px rgba(0,0,0,.1)}
h2{margin-bottom:20px;color:#333}
.item{padding:10px 15px;border-radius:6px;margin-bottom:8px;font-size:14px;font-family:Tahoma,Arial,sans-serif}
.ok{background:#d4edda;color:#155724}
.err{background:#f8d7da;color:#721c24}
.warn{background:#fff3cd;color:#856404}
.done{background:#d1ecf1;color:#0c5460;padding:20px;border-radius:8px;text-align:center;margin-top:20px;font-size:15px}
.warn-box{background:#fff3cd;color:#856404;padding:15px;border-radius:8px;margin-top:15px;font-size:13px}
code{direction:ltr;display:inline-block;background:#eee;padding:2px 6px;border-radius:3px}
</style>
</head>
<body>
<div class="box">
    <h2>🛠 مهاجرت دیتابیس ربات بله</h2>

    <?php foreach ($log as [$type, $msg]): ?>
    <div class="item <?= $type ?>">
        <?= $type === 'ok' ? '✅' : ($type === 'warn' ? '⚠️' : '❌') ?> <?= htmlspecialchars($msg) ?>
    </div>
    <?php endforeach; ?>

    <?php if ($success): ?>
    <div class="done">
        🎉 مهاجرت با موفقیت انجام شد!<br><br>
        <strong>قدم بعدی:</strong><br><br>
        ۱. به بله برو و <strong>/start</strong> بفرست<br>
        ۲. دکمه «<strong>🕶 ملاقات مخفیانه</strong>» را بزن<br>
        ۳. نوع جستجو را انتخاب کن و منتظر مچ بمان<br><br>
        <strong style="color:red">این فایل (migrate.php) را حذف کن!</strong>
    </div>
    <?php else: ?>
    <div class="item err" style="margin-top:15px">
        ❌ خطاهایی وجود دارد. اطلاعات بالا را بررسی کن و دوباره این صفحه را باز کن.
    </div>
    <?php endif; ?>

    <div class="warn-box">
        💡 <strong>نکته:</strong> برای پاکسازی کاربران stale در صف ملاقات ناشناس، cron job زیر را تنظیم کن:<br>
        <code>* * * * * php /home/youruser/public_html/bale/cli/cli_match_maker.php >> /home/youruser/public_html/bale/logs/cron.log 2>&1</code>
    </div>
</div>
</body>
</html>
