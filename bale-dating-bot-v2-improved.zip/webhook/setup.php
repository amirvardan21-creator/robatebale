<?php
/**
 * Webhook Setup - v2.0 بهبود یافته
 * امنیت + نمایش اطلاعات کامل
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../classes/Bale.php';
require_once __DIR__ . '/../classes/Logger.php';
require_once __DIR__ . '/../classes/Database.php';

$secret = $_GET['secret'] ?? '';
if ($secret !== WEBHOOK_SECRET) {
    http_response_code(403);
    die('<h2 style="font-family:Tahoma;direction:rtl;text-align:center;margin-top:50px">⛔ دسترسی غیرمجاز<br><small>secret اشتباه است</small></h2>');
}

$bale = new Bale();
$action = $_GET['action'] ?? 'info';

header('Content-Type: text/html; charset=utf-8');

function pretty($data) {
    return json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Webhook Setup</title>
<style>
body{font-family:Tahoma;background:#f8f9fa;padding:20px;direction:rtl}
.box{max-width:700px;margin:20px auto;background:#fff;border-radius:12px;padding:25px;box-shadow:0 2px 15px rgba(0,0,0,.1)}
h2{color:#333;margin-top:0}
pre{background:#2d3436;color:#dfe6e9;padding:15px;border-radius:8px;overflow:auto;direction:ltr;text-align:left}
.btn{display:inline-block;padding:10px 20px;border-radius:8px;text-decoration:none;color:#fff;margin:5px;font-weight:bold}
.green{background:#00b894}
.red{background:#d63031}
.blue{background:#0984e3}
.orange{background:#e17055}
.info{background:#dfe6e9;color:#2d3436;padding:15px;border-radius:8px;margin:15px 0}
code{background:#eee;padding:2px 6px;border-radius:4px;direction:ltr;display:inline-block}
</style>
</head>
<body>
<div class="box">
<h2>🔗 مدیریت Webhook ربات بله</h2>

<div class="info">
<strong>اطلاعات فعلی:</strong><br>
BOT_USERNAME: <code><?= htmlspecialchars(BOT_USERNAME) ?></code><br>
BASE_URL: <code><?= htmlspecialchars(BASE_URL) ?></code><br>
WEBHOOK_URL: <code><?= htmlspecialchars(BASE_URL . '/webhook/index.php') ?></code><br>
BOT_TOKEN: <code><?= substr(BOT_TOKEN, 0, 10) ?>...<?= substr(BOT_TOKEN, -5) ?></code> (طول: <?= strlen(BOT_TOKEN) ?>)
</div>

<p>
<a class="btn blue" href="?secret=<?= htmlspecialchars($secret) ?>&action=info">ℹ️ اطلاعات Webhook</a>
<a class="btn green" href="?secret=<?= htmlspecialchars($secret) ?>&action=set">✅ تنظیم Webhook</a>
<a class="btn red" href="?secret=<?= htmlspecialchars($secret) ?>&action=delete">🗑 حذف Webhook</a>
<a class="btn orange" href="?secret=<?= htmlspecialchars($secret) ?>&action=getme">🤖 اطلاعات ربات</a>
</p>

<hr>

<?php
try {
    if ($action === 'set') {
        $webhookUrl = BASE_URL . '/webhook/index.php';
        echo "<h3>در حال تنظیم Webhook به:</h3><code>$webhookUrl</code><br><br>";
        $result = $bale->setWebhook($webhookUrl);
        echo "<h3>نتیجه:</h3><pre>" . htmlspecialchars(pretty($result)) . "</pre>";
        if ($result) {
            echo '<div class="info" style="background:#d4edda;color:#155724">✅ Webhook با موفقیت تنظیم شد! حالا به ربات در بله پیام دهید.</div>';
        } else {
            echo '<div class="info" style="background:#f8d7da;color:#721c24">❌ خطا در تنظیم Webhook. لاگ‌ها را بررسی کنید.</div>';
        }

    } elseif ($action === 'delete') {
        $result = $bale->deleteWebhook();
        echo "<h3>حذف Webhook:</h3><pre>" . htmlspecialchars(pretty($result)) . "</pre>";

    } elseif ($action === 'info') {
        $result = $bale->getWebhookInfo();
        echo "<h3>ℹ️ اطلاعات Webhook:</h3><pre>" . htmlspecialchars(pretty($result)) . "</pre>";

        if (!empty($result['url'])) {
            $lastError = $result['last_error_message'] ?? 'ندارد';
            $pending = $result['pending_update_count'] ?? 0;
            echo "<div class='info'>";
            echo "URL: <code>{$result['url']}</code><br>";
            echo "Pending updates: {$pending}<br>";
            echo "Last error: {$lastError}<br>";
            if (!empty($result['last_error_date'])) {
                echo "Last error date: " . date('Y-m-d H:i:s', $result['last_error_date']) . "<br>";
            }
            echo "</div>";
            
            if ($pending > 10) {
                echo '<div class="info" style="background:#fff3cd">⚠️ تعداد آپدیت‌های معلق زیاد است. ممکن است webhook کند باشد یا خطا داشته باشد.</div>';
            }
        } else {
            echo '<div class="info" style="background:#fff3cd">⚠️ Webhook تنظیم نشده است. دکمه تنظیم را بزنید.</div>';
        }

    } elseif ($action === 'getme') {
        $result = $bale->getMe();
        echo "<h3>🤖 اطلاعات ربات:</h3><pre>" . htmlspecialchars(pretty($result)) . "</pre>";
    }

    // تست دیتابیس
    echo "<h3>🔍 تست سیستم:</h3>";
    try {
        $pdo = Database::getInstance();
        $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
        echo "<div class='info'>✅ اتصال دیتابیس OK - جداول: " . count($tables) . "<br><small>" . implode(', ', array_slice($tables, 0, 10)) . "...</small></div>";
    } catch (Throwable $e) {
        echo "<div class='info' style='background:#f8d7da'>❌ خطای دیتابیس: " . htmlspecialchars($e->getMessage()) . "</div>";
    }

    // تست پوشه‌ها
    $logsOk = is_dir(LOG_PATH) && is_writable(LOG_PATH);
    $uploadsOk = is_dir(UPLOAD_PATH) && is_writable(UPLOAD_PATH);
    echo "<div class='info'>";
    echo ($logsOk ? '✅' : '❌') . " LOG_PATH: " . LOG_PATH . " - " . ($logsOk ? 'قابل نوشتن' : 'غیر قابل نوشتن! chmod 755') . "<br>";
    echo ($uploadsOk ? '✅' : '❌') . " UPLOAD_PATH: " . UPLOAD_PATH . " - " . ($uploadsOk ? 'قابل نوشتن' : 'غیر قابل نوشتن!') . "<br>";
    echo "</div>";

} catch (Throwable $e) {
    echo "<pre style='background:#f8d7da;color:#721c24'>خطا: " . htmlspecialchars($e->getMessage()) . "\n" . htmlspecialchars($e->getTraceAsString()) . "</pre>";
}
?>

<hr>
<p style="font-size:13px;color:#636e72;text-align:center">
v2.0 | بعد از تنظیم webhook، این صفحه را بوکمارک نکنید چون secret داخل URL است
</p>

</div>
</body>
</html>
