<?php
/**
 * نمونه فایل تنظیمات - این را به config.php کپی کن
 * یا از .env استفاده کن (پیشنهادی)
 * 
 * روش پیشنهادی: فایل .env از .env.example کپی کن و پر کن
 * این فایل فقط برای سازگاری قدیمی است
 */

define('BOT_TOKEN', 'YOUR_BALE_BOT_TOKEN_HERE');
define('BOT_USERNAME', 'your_bot_username');
define('BALE_API_URL', 'https://tapi.bale.ai/bot' . BOT_TOKEN . '/');
define('WEBHOOK_SECRET', 'CHANGE_THIS_TO_RANDOM_STRING_32_CHARS');

define('DB_HOST', 'localhost');
define('DB_NAME', 'your_db_name');
define('DB_USER', 'your_db_user');
define('DB_PASS', 'your_db_password');
define('DB_CHARSET', 'utf8mb4');
define('DB_PORT', 3306);

define('ADMIN_BALE_ID', 0); // شناسه عددی ادمین

define('UPLOAD_PATH', __DIR__ . '/../uploads/');
define('LOG_PATH', __DIR__ . '/../logs/');
define('BASE_URL', 'https://yourdomain.com/bale');

define('FREE_DAILY_LIKES', 20);
define('FREE_DAILY_VIEWS', 30);
define('FREE_DAILY_SECRET', 5);
define('MAX_BIO_LENGTH', 500);

// هزینه‌ها
define('COST_RANDOM', 0);
define('COST_GENDER', 2);
define('COST_PROVINCE', 4);
define('COST_GIFT', 10);

// جایزه‌ها
define('DAILY_BONUS_COINS', 5);
define('REFERRAL_BONUS', 20);
define('START_BONUS', 10);

define('RATE_LIMIT_MESSAGES', 20);
define('RATE_LIMIT_WINDOW', 60);

define('ADMIN_USERNAME', 'admin');
define('ADMIN_PASSWORD', 'change_this_password');
