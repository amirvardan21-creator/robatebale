<?php
/**
 * نصب خودکار دیتابیس - نسخه بهبود یافته v2.0
 * بعد از نصب حذف کنید!
 */

require_once __DIR__ . '/config/config.php';

$log = [];
$success = true;

function addLog(&$log, $type, $msg) {
    $log[] = [$type, $msg];
}

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET,
        DB_USER,
        DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );
    addLog($log, 'ok', 'اتصال به دیتابیس: ' . DB_NAME . ' @ ' . DB_HOST);
} catch (PDOException $e) {
    die('<div style="color:red;font-family:Tahoma;direction:rtl;padding:20px">❌ خطای اتصال: ' . htmlspecialchars($e->getMessage()) . '<br><br>config/config.php یا .env را بررسی کنید</div>');
}

// خواندن فایل SQL اصلی
$sqlFile = __DIR__ . '/database/database.sql';
if (file_exists($sqlFile)) {
    $sqlContent = file_get_contents($sqlFile);
    // حذف کامنت‌ها و تقسیم به دستورات
    $sqlContent = preg_replace('/--.*$/m', '', $sqlContent);
    $sqlContent = preg_replace('/\/\*.*?\*\//s', '', $sqlContent);
    
    $statements = array_filter(array_map('trim', explode(';', $sqlContent)));
    
    foreach ($statements as $stmt) {
        if (empty($stmt) || stripos($stmt, 'SET ') === 0 || stripos($stmt, 'USE ') === 0) continue;
        try {
            $pdo->exec($stmt);
        } catch (PDOException $e) {
            // نادیده گرفتن خطاهای "already exists"
            if (strpos($e->getMessage(), 'already exists') === false && strpos($e->getMessage(), 'Duplicate') === false) {
                addLog($log, 'err', substr($stmt, 0, 100) . '... : ' . $e->getMessage());
            }
        }
    }
    addLog($log, 'ok', 'اسکیمای اصلی از database.sql اجرا شد');
} else {
    // fallback: ساخت دستی
    addLog($log, 'err', 'فایل database.sql یافت نشد - ساخت دستی انجام می‌شود');
    
    // در اینجا می‌توان ساخت دستی را ادامه داد اما چون فایل وجود دارد، نیاز نیست
}

// بررسی نهایی جداول
$expectedTables = ['users','profiles','likes','matches','messages','blocked_users','reports','admins','vip_users','settings','coins','coin_transactions','secret_meeting_rooms','secret_meeting_queue','referrals','rate_limits','daily_checkins'];
foreach ($expectedTables as $table) {
    try {
        $exists = $pdo->query("SHOW TABLES LIKE '$table'")->fetch();
        if ($exists) {
            addLog($log, 'ok', "جدول $table وجود دارد");
        } else {
            addLog($log, 'err', "جدول $table وجود ندارد!");
            $success = false;
        }
    } catch (PDOException $e) {
        addLog($log, 'err', "بررسی $table: " . $e->getMessage());
    }
}

// تنظیمات پیش‌فرض
try {
    $count = (int)$pdo->query("SELECT COUNT(*) FROM settings")->fetchColumn();
    if ($count == 0) {
        $pdo->exec("INSERT INTO settings (`key`, `value`) VALUES
            ('bot_active', '1'),
            ('maintenance_message', '🔧 ربات در حال بروزرسانی است، لطفاً دقایقی دیگر تلاش کنید.'),
            ('free_daily_views', '30'),
            ('free_daily_likes', '20'),
            ('free_daily_secret', '5'),
            ('vip_monthly_price', '100'),
            ('welcome_message', 'به ربات دوستیابی مافیا مچ خوش آمدید! 🎩')
        ");
        addLog($log, 'ok', 'تنظیمات پیش‌فرض درج شد');
    }
} catch (PDOException $e) {
    addLog($log, 'err', 'تنظیمات: ' . $e->getMessage());
}

// ادمین پیش‌فرض
try {
    $count = (int)$pdo->query("SELECT COUNT(*) FROM admins")->fetchColumn();
    if ($count == 0) {
        $hash = password_hash('admin123', PASSWORD_BCRYPT, ['cost' => 10]);
        $stmt = $pdo->prepare("INSERT INTO admins (username, password_hash) VALUES (?, ?)");
        $stmt->execute(['admin', $hash]);
        addLog($log, 'ok', 'ادمین پیش‌فرض: admin / admin123');
    }
} catch (PDOException $e) {
    addLog($log, 'err', 'ادمین: ' . $e->getMessage());
}

// ساخت پوشه‌ها
$dirs = [LOG_PATH, UPLOAD_PATH, __DIR__ . '/logs', __DIR__ . '/uploads'];
foreach ($dirs as $dir) {
    if (!is_dir($dir)) {
        if (@mkdir($dir, 0755, true)) {
            addLog($log, 'ok', "پوشه ساخته شد: $dir");
        } else {
            addLog($log, 'err', "خطا در ساخت پوشه: $dir - chmod 755 را دستی بزنید");
        }
    }
    // فایل .htaccess برای امنیت
    $htaccess = $dir . '/.htaccess';
    if (!file_exists($htaccess)) {
        @file_put_contents($htaccess, "Deny from all\n");
    }
}

// بررسی قابلیت نوشتن
foreach ([LOG_PATH, UPLOAD_PATH] as $dir) {
    if (is_writable($dir)) {
        addLog($log, 'ok', "قابل نوشتن: $dir");
    } else {
        addLog($log, 'err', "غیر قابل نوشتن: $dir - chmod 755 لازم است");
        $success = false;
    }
}

// تست Bale توکن
if (defined('BOT_TOKEN') && BOT_TOKEN !== 'YOUR_TOKEN_HERE' && strlen(BOT_TOKEN) > 20) {
    addLog($log, 'ok', 'توکن ربات تنظیم شده (طول: ' . strlen(BOT_TOKEN) . ')');
} else {
    addLog($log, 'err', 'توکن ربات تنظیم نشده! config/config.php یا .env را چک کنید');
    $success = false;
}

?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>نصب ربات - نسخه 2.0</title>
<style>
*{box-sizing:border-box}
body{font-family:Tahoma,Arial,sans-serif;background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);min-height:100vh;padding:20px;margin:0;direction:rtl}
.box{max-width:700px;margin:20px auto;background:#fff;border-radius:15px;padding:30px;box-shadow:0 10px 30px rgba(0,0,0,.2)}
h2{margin:0 0 20px;color:#333;text-align:center;font-size:22px}
.item{padding:12px 15px;border-radius:8px;margin-bottom:8px;font-size:14px;display:flex;align-items:center;gap:10px}
.ok{background:#d4edda;color:#155724;border:1px solid #c3e6cb}
.err{background:#f8d7da;color:#721c24;border:1px solid #f5c6cb}
.done{background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);color:#fff;padding:25px;border-radius:12px;text-align:center;margin-top:20px;line-height:1.8}
.warn{background:#fff3cd;color:#856404;padding:15px;border-radius:8px;margin-top:15px;border:1px solid #ffeaa7}
a{color:#fff;text-decoration:underline;font-weight:bold}
code{direction:ltr;display:block;background:#2d3436;color:#dfe6e9;padding:10px;border-radius:6px;margin:10px 0;font-size:13px;overflow:auto}
.btn{display:inline-block;background:#00b894;color:#fff;padding:12px 25px;border-radius:25px;text-decoration:none;margin:10px 5px;font-weight:bold}
.btn:hover{background:#00a085}
.progress{height:6px;background:#eee;border-radius:3px;margin:20px 0;overflow:hidden}
.progress-bar{height:100%;background:linear-gradient(90deg,#00b894,#00cec9);width:<?= $success ? '100' : '70' ?>%;transition:width 1s}
</style>
</head>
<body>
<div class="box">
    <h2>🎩 نصب ربات دوستیابی مافیا مچ v2.0</h2>
    <div class="progress"><div class="progress-bar"></div></div>

    <?php foreach ($log as [$type, $msg]): ?>
    <div class="item <?= $type ?>">
        <?= $type === 'ok' ? '✅' : '❌' ?> <?= htmlspecialchars($msg) ?>
    </div>
    <?php endforeach; ?>

    <?php if ($success): ?>
    <div class="done">
        🎉 <strong>نصب با موفقیت کامل شد!</strong><br><br>
        <strong>قدم‌های بعدی:</strong><br><br>
        ۱. <a href="admin/setup_password.php">🔑 رمز ادمین را تنظیم کن</a><br><br>
        ۲. <strong>تنظیم Cron Job (الزامی):</strong><br>
        <code>* * * * * php <?= realpath(__DIR__ . '/cli/cli_match_maker.php') ?> >> <?= realpath(LOG_PATH) ?: LOG_PATH ?>/cron.log 2>&1</code>
        <small style="display:block;margin-top:5px;opacity:.9">cPanel → Cron Jobs → هر دقیقه</small><br>
        ۳. <a href="webhook/setup.php?secret=<?= WEBHOOK_SECRET ?>&action=set">🔗 تنظیم Webhook</a><br><br>
        ۴. در بله به ربات برو و <strong>/start</strong> بفرست!<br><br>
        <span style="background:#d63031;padding:5px 15px;border-radius:20px;font-size:13px">⚠️ این فایل (install.php) را حذف کن!</span>
    </div>
    <div class="warn">
        <strong>🔐 امنیت:</strong><br>
        • رمز پیش‌فرض ادمین: <code>admin123</code><br>
        • حتماً از <a href="admin/setup_password.php" style="color:#856404">اینجا</a> رمز را عوض کن!<br>
        • فایل <code>install.php</code> و <code>admin/setup_password.php</code> را حذف کن<br>
        • توکن ربات را در <code>.env</code> یا <code>config.php</code> امن نگه دار
    </div>
    <?php else: ?>
    <div class="item err" style="margin-top:15px">
        ❌ خطاهایی وجود دارد. موارد قرمز بالا را برطرف کن و دوباره این صفحه را رفرش کن.
    </div>
    <?php endif; ?>

    <div style="text-align:center;margin-top:20px">
        <a href="admin/" class="btn">🛠 ورود به پنل ادمین</a>
        <a href="webhook/setup.php?secret=<?= WEBHOOK_SECRET ?>&action=info" class="btn" style="background:#0984e3">ℹ️ اطلاعات Webhook</a>
    </div>

    <div style="text-align:center;margin-top:20px;font-size:12px;color:#636e72">
        نسخه 2.0 - بهبود یافته با امکانات: جایزه روزانه، دعوت دوستان، فروشگاه سکه، ضد اسپم، و بیشتر...
    </div>
</div>
</body>
</html>
