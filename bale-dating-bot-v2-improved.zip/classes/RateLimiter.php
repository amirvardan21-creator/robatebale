<?php

/**
 * RateLimiter - جلوگیری از اسپم و حملات
 * استفاده از فایل ساده یا دیتابیس
 */
class RateLimiter
{
    private const TABLE = 'rate_limits';

    public static function ensureTable(): void
    {
        if (Database::tableExists(self::TABLE)) return;
        
        try {
            Database::execute("
                CREATE TABLE IF NOT EXISTS `rate_limits` (
                    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    `identifier` VARCHAR(100) NOT NULL,
                    `action` VARCHAR(50) NOT NULL,
                    `count` INT UNSIGNED DEFAULT 1,
                    `first_attempt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    `last_attempt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    UNIQUE KEY `idx_identifier_action` (`identifier`, `action`),
                    INDEX `idx_last_attempt` (`last_attempt`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ");
        } catch (Throwable $e) {
            Logger::error("RateLimiter table creation failed: " . $e->getMessage());
        }
    }

    /**
     * بررسی آیا کاربر مجاز به انجام عملیات است
     */
    public static function check(int $userId, string $action, int $maxAttempts = 10, int $windowSeconds = 60): bool
    {
        self::ensureTable();

        $identifier = (string) $userId;
        $now = time();

        try {
            $row = Database::fetch(
                "SELECT * FROM rate_limits WHERE identifier = ? AND action = ?",
                [$identifier, $action]
            );

            if (!$row) {
                Database::execute(
                    "INSERT INTO rate_limits (identifier, action, count) VALUES (?, ?, 1)",
                    [$identifier, $action]
                );
                return true;
            }

            $firstTime = strtotime($row['first_attempt']);
            $elapsed = $now - $firstTime;

            // اگر پنجره گذشته، ریست کن
            if ($elapsed > $windowSeconds) {
                Database::execute(
                    "UPDATE rate_limits SET count = 1, first_attempt = NOW() WHERE identifier = ? AND action = ?",
                    [$identifier, $action]
                );
                return true;
            }

            // اگر داخل پنجره و تعداد کمتر از حد مجاز
            if ((int) $row['count'] < $maxAttempts) {
                Database::execute(
                    "UPDATE rate_limits SET count = count + 1 WHERE identifier = ? AND action = ?",
                    [$identifier, $action]
                );
                return true;
            }

            // رد شد
            Logger::security("Rate limit exceeded", [
                'user_id' => $userId,
                'action' => $action,
                'count' => $row['count']
            ]);
            return false;

        } catch (Throwable $e) {
            Logger::error("RateLimiter check failed: " . $e->getMessage());
            return true; // در صورت خطا، اجازه بده
        }
    }

    /**
     * بررسی خاص برای پیام
     */
    public static function checkMessage(int $userId): bool
    {
        return self::check($userId, 'send_message', RATE_LIMIT_MESSAGES, RATE_LIMIT_WINDOW);
    }

    /**
     * بررسی برای لایک
     */
    public static function checkLike(int $userId): bool
    {
        return self::check($userId, 'like', 30, 60);
    }

    /**
     * بررسی برای ورود به صف
     */
    public static function checkQueue(int $userId): bool
    {
        return self::check($userId, 'queue_join', 10, 60);
    }

    public static function getRemainingAttempts(int $userId, string $action, int $maxAttempts, int $windowSeconds): int
    {
        $row = Database::fetch(
            "SELECT * FROM rate_limits WHERE identifier = ? AND action = ?",
            [(string) $userId, $action]
        );

        if (!$row) return $maxAttempts;

        $firstTime = strtotime($row['first_attempt']);
        $elapsed = time() - $firstTime;

        if ($elapsed > $windowSeconds) {
            return $maxAttempts;
        }

        return max(0, $maxAttempts - (int) $row['count']);
    }

    public static function cleanup(): int
    {
        try {
            return Database::execute(
                "DELETE FROM rate_limits WHERE last_attempt < DATE_SUB(NOW(), INTERVAL 1 HOUR)"
            );
        } catch (Throwable $e) {
            return 0;
        }
    }
}
