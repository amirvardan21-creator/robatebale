<?php

/**
 * BlockReport - بهبود یافته
 * - سیستم اخطار
 * - بلاک خودکار پس از گزارش‌های متعدد
 */
class BlockReport
{
    public const AUTO_BLOCK_THRESHOLD = 3; // بعد از ۳ گزارش تایید شده، بلاک خودکار

    public static function block(int $blockerId, int $blockedId): void
    {
        if ($blockerId === $blockedId) return;

        Database::execute(
            'INSERT IGNORE INTO blocked_users (blocker_id, blocked_id) VALUES (?, ?)',
            [$blockerId, $blockedId]
        );

        // غیرفعال کردن مچ موجود
        $u1 = min($blockerId, $blockedId);
        $u2 = max($blockerId, $blockedId);
        Database::execute(
            'UPDATE matches SET is_active = 0 WHERE user1_id = ? AND user2_id = ?',
            [$u1, $u2]
        );

        // پایان دادن چت مخفیانه اگر فعال است
        try {
            $rooms = Database::fetchAll(
                'SELECT id FROM secret_meeting_rooms WHERE ((user1_id = ? AND user2_id = ?) OR (user1_id = ? AND user2_id = ?)) AND status = "active"',
                [$blockerId, $blockedId, $blockedId, $blockerId]
            );
            foreach ($rooms as $r) {
                SecretMeetingRoom::endRoom((int) $r['id'], 'aborted');
            }
            // حذف از صف
            SecretMeetingQueue::removeFromQueue($blockedId);
        } catch (Throwable $e) {}

        Logger::logUserAction($blockerId, 'block_user', ['blocked_id' => $blockedId]);
    }

    public static function unblock(int $blockerId, int $blockedId): void
    {
        Database::execute(
            'DELETE FROM blocked_users WHERE blocker_id = ? AND blocked_id = ?',
            [$blockerId, $blockedId]
        );
        Logger::logUserAction($blockerId, 'unblock_user', ['unblocked_id' => $blockedId]);
    }

    public static function isBlocked(int $blockerId, int $blockedId): bool
    {
        $row = Database::fetch(
            'SELECT id FROM blocked_users WHERE blocker_id = ? AND blocked_id = ?',
            [$blockerId, $blockedId]
        );
        return (bool) $row;
    }

    public static function isBlockedEither(int $userId1, int $userId2): bool
    {
        return self::isBlocked($userId1, $userId2) || self::isBlocked($userId2, $userId1);
    }

    public static function getBlockedUsers(int $userId): array
    {
        return Database::fetchAll(
            'SELECT b.*, p.name, p.age, p.city FROM blocked_users b
             LEFT JOIN profiles p ON p.user_id = b.blocked_id
             WHERE b.blocker_id = ? ORDER BY b.created_at DESC',
            [$userId]
        );
    }

    public static function report(int $reporterId, int $reportedId, string $reason): int
    {
        if ($reporterId === $reportedId) {
            throw new InvalidArgumentException('نمی‌توانید خودتان را گزارش کنید');
        }

        // جلوگیری از اسپم گزارش
        $recent = Database::fetch(
            'SELECT id FROM reports WHERE reporter_id = ? AND reported_id = ? AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)',
            [$reporterId, $reportedId]
        );
        if ($recent) {
            throw new RuntimeException('شما اخیراً این کاربر را گزارش کرده‌اید');
        }

        // فیلتر دلیل
        $reason = trim($reason);
        if (mb_strlen($reason) < 5) {
            throw new InvalidArgumentException('دلیل گزارش خیلی کوتاه است');
        }
        $reason = mb_substr(htmlspecialchars($reason), 0, 500);

        $id = Database::insert(
            'INSERT INTO reports (reporter_id, reported_id, reason) VALUES (?, ?, ?)',
            [$reporterId, $reportedId, $reason]
        );

        Logger::security("New report: $reporterId reported $reportedId", ['reason' => $reason, 'report_id' => $id]);

        // بررسی بلاک خودکار
        self::checkAutoBlock($reportedId);

        // اعلان به ادمین
        try {
            if (ADMIN_BALE_ID > 0) {
                $bale = new Bale();
                $reporter = User::findById($reporterId);
                $reported = User::findById($reportedId);
                $bale->sendMessage(
                    ADMIN_BALE_ID,
                    "🚨 *گزارش جدید*\n\n"
                    . "گزارش‌دهنده: {$reporter['bale_id']} (ID: $reporterId)\n"
                    . "گزارش‌شونده: {$reported['bale_id']} (ID: $reportedId)\n"
                    . "دلیل: $reason\n\n"
                    . "برای بررسی به پنل ادمین بروید."
                );
            }
        } catch (Throwable $e) {}

        return $id;
    }

    private static function checkAutoBlock(int $userId): void
    {
        try {
            $count = Database::fetch(
                'SELECT COUNT(*) as cnt FROM reports WHERE reported_id = ? AND status != "resolved" AND created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)',
                [$userId]
            );
            if ((int) ($count['cnt'] ?? 0) >= self::AUTO_BLOCK_THRESHOLD) {
                // هشدار به ادمین برای بررسی و بلاک احتمالی، نه بلاک خودکار کامل (برای جلوگیری از سوء استفاده)
                Logger::security("User $userId has " . $count['cnt'] . " reports in last 7 days - needs review");
            }
        } catch (Throwable $e) {}
    }

    public static function getPendingReports(int $limit = 50): array
    {
        return Database::fetchAll(
            'SELECT r.*, 
                p1.name as reporter_name, p2.name as reported_name,
                u1.bale_id as reporter_bale_id, u2.bale_id as reported_bale_id
             FROM reports r
             JOIN users u1 ON r.reporter_id = u1.id
             JOIN users u2 ON r.reported_id = u2.id
             LEFT JOIN profiles p1 ON p1.user_id = r.reporter_id
             LEFT JOIN profiles p2 ON p2.user_id = r.reported_id
             WHERE r.status = "pending"
             ORDER BY r.created_at DESC LIMIT ?',
            [$limit]
        );
    }

    public static function getReportsByStatus(string $status, int $limit = 50): array
    {
        if ($status === 'all') {
            return Database::fetchAll(
                'SELECT r.*, p1.name as reporter_name, p2.name as reported_name,
                        u1.bale_id as reporter_bale_id, u2.bale_id as reported_bale_id
                 FROM reports r
                 JOIN users u1 ON r.reporter_id = u1.id
                 JOIN users u2 ON r.reported_id = u2.id
                 LEFT JOIN profiles p1 ON p1.user_id = r.reporter_id
                 LEFT JOIN profiles p2 ON p2.user_id = r.reported_id
                 ORDER BY r.created_at DESC LIMIT ?',
                [$limit]
            );
        }

        return Database::fetchAll(
            'SELECT r.*, p1.name as reporter_name, p2.name as reported_name,
                    u1.bale_id as reporter_bale_id, u2.bale_id as reported_bale_id
             FROM reports r
             JOIN users u1 ON r.reporter_id = u1.id
             JOIN users u2 ON r.reported_id = u2.id
             LEFT JOIN profiles p1 ON p1.user_id = r.reporter_id
             LEFT JOIN profiles p2 ON p2.user_id = r.reported_id
             WHERE r.status = ?
             ORDER BY r.created_at DESC LIMIT ?',
            [$status, $limit]
        );
    }

    public static function updateReportStatus(int $reportId, string $status, ?string $note = null): void
    {
        $valid = ['pending', 'reviewed', 'resolved', 'dismissed'];
        if (!in_array($status, $valid, true)) {
            throw new InvalidArgumentException('وضعیت نامعتبر');
        }

        Database::execute(
            'UPDATE reports SET status = ?, admin_note = ?, updated_at = NOW() WHERE id = ?',
            [$status, $note, $reportId]
        );
    }

    public static function getUserReportCount(int $userId): int
    {
        $row = Database::fetch('SELECT COUNT(*) as cnt FROM reports WHERE reported_id = ?', [$userId]);
        return (int) ($row['cnt'] ?? 0);
    }
}
