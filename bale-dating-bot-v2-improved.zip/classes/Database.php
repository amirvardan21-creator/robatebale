<?php

/**
 * Database - نسخه بهبود یافته
 * - Connection pooling (singleton)
 * - Query logging و تشخیص slow query
 * - Transaction helpers
 * - Retry logic برای خطاهای موقت
 */
class Database
{
    private static ?PDO $instance = null;
    private static int $queryCount = 0;
    private static float $totalQueryTime = 0;

    public static function getInstance(): PDO
    {
        if (self::$instance === null) {
            $dsn = sprintf(
                'mysql:host=%s;port=%d;dbname=%s;charset=%s',
                DB_HOST,
                DB_PORT,
                DB_NAME,
                DB_CHARSET
            );
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::ATTR_PERSISTENT         => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . DB_CHARSET . " COLLATE utf8mb4_unicode_ci",
                PDO::ATTR_TIMEOUT            => 5,
            ];
            
            $retries = 3;
            while ($retries > 0) {
                try {
                    self::$instance = new PDO($dsn, DB_USER, DB_PASS, $options);
                    break;
                } catch (PDOException $e) {
                    $retries--;
                    if ($retries === 0) {
                        Logger::error("Database connection failed after 3 retries: " . $e->getMessage());
                        throw $e;
                    }
                    usleep(500000); // 0.5 ثانیه صبر
                }
            }
        }
        return self::$instance;
    }

    public static function query(string $sql, array $params = []): PDOStatement
    {
        $start = microtime(true);
        try {
            $stmt = self::getInstance()->prepare($sql);
            
            // بایند هوشمند برای LIMIT که int نیاز دارد
            foreach ($params as $i => $param) {
                $type = is_int($param) ? PDO::PARAM_INT : (is_bool($param) ? PDO::PARAM_BOOL : PDO::PARAM_STR);
                if (is_int($i)) {
                    $stmt->bindValue($i + 1, $param, $type);
                } else {
                    $stmt->bindValue($i, $param, $type);
                }
            }
            
            // اگر آرایه عددی ساده است، execute مستقیم
            if (array_keys($params) === range(0, count($params) - 1) || empty($params)) {
                if (empty($params)) {
                    $stmt->execute();
                } else {
                    // قبلا bind کردیم، ولی برای سازگاری execute هم می‌کنیم
                    $stmt->execute($params);
                }
            } else {
                $stmt->execute();
            }
            
            $time = (microtime(true) - $start) * 1000;
            self::$queryCount++;
            self::$totalQueryTime += $time;
            
            if ($time > 500) {
                Logger::warning("Slow query detected", [
                    'sql' => substr($sql, 0, 500),
                    'time_ms' => round($time, 2)
                ]);
            }
            
            return $stmt;
        } catch (PDOException $e) {
            $time = (microtime(true) - $start) * 1000;
            Logger::error("Query failed: " . $e->getMessage(), [
                'sql' => substr($sql, 0, 500),
                'params' => $params,
                'time_ms' => round($time, 2)
            ]);
            throw $e;
        }
    }

    public static function fetch(string $sql, array $params = []): ?array
    {
        return self::query($sql, $params)->fetch() ?: null;
    }

    public static function fetchAll(string $sql, array $params = []): array
    {
        return self::query($sql, $params)->fetchAll();
    }

    public static function fetchColumn(string $sql, array $params = []): mixed
    {
        return self::query($sql, $params)->fetchColumn();
    }

    public static function insert(string $sql, array $params = []): int
    {
        self::query($sql, $params);
        return (int) self::getInstance()->lastInsertId();
    }

    public static function execute(string $sql, array $params = []): int
    {
        return self::query($sql, $params)->rowCount();
    }

    public static function beginTransaction(): void
    {
        self::getInstance()->beginTransaction();
    }

    public static function commit(): void
    {
        self::getInstance()->commit();
    }

    public static function rollBack(): void
    {
        if (self::getInstance()->inTransaction()) {
            self::getInstance()->rollBack();
        }
    }

    /**
     * اجرای تابع داخل transaction با rollback خودکار در صورت خطا
     */
    public static function transaction(callable $callback): mixed
    {
        self::beginTransaction();
        try {
            $result = $callback();
            self::commit();
            return $result;
        } catch (Throwable $e) {
            self::rollBack();
            throw $e;
        }
    }

    public static function getStats(): array
    {
        return [
            'queries' => self::$queryCount,
            'total_time_ms' => round(self::$totalQueryTime, 2),
            'avg_time_ms' => self::$queryCount > 0 ? round(self::$totalQueryTime / self::$queryCount, 2) : 0
        ];
    }

    public static function tableExists(string $table): bool
    {
        try {
            $row = self::fetch(
                "SELECT 1 FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ? LIMIT 1",
                [$table]
            );
            return (bool) $row;
        } catch (Throwable $e) {
            return false;
        }
    }
}
