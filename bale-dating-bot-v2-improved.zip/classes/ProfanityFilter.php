<?php

/**
 * ProfanityFilter - فیلتر کلمات نامناسب
 */
class ProfanityFilter
{
    private static ?array $badWords = null;
    private static ?array $patterns = null;

    private static function loadBadWords(): array
    {
        if (self::$badWords !== null) {
            return self::$badWords;
        }

        // لیست پایه - در عمل از دیتابیس یا فایل بخوان
        self::$badWords = [
            // فارسی - نمونه‌ها باید واقعی شوند
            // 'کلمه_زشت' => '***'
        ];

        // می‌توان از فایل خارجی هم خواند
        $file = __DIR__ . '/../config/badwords.txt';
        if (file_exists($file)) {
            $words = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            foreach ($words as $w) {
                $w = trim($w);
                if ($w && !str_starts_with($w, '#')) {
                    self::$badWords[$w] = str_repeat('*', mb_strlen($w));
                }
            }
        }

        return self::$badWords;
    }

    public static function containsProfanity(string $text): bool
    {
        $text = mb_strtolower($text);
        $badWords = self::loadBadWords();

        foreach (array_keys($badWords) as $word) {
            if (mb_strpos($text, mb_strtolower($word)) !== false) {
                return true;
            }
        }

        // تشخیص تلاش برای دور زدن فیلتر با فاصله یا کاراکتر
        // مثلا: ک...ل...م...ه
        return false;
    }

    public static function censor(string $text): string
    {
        $badWords = self::loadBadWords();
        foreach ($badWords as $word => $replace) {
            $text = str_ireplace($word, $replace, $text);
        }
        return $text;
    }

    public static function checkBio(string $bio): array
    {
        if (self::containsProfanity($bio)) {
            return [
                'valid' => false,
                'message' => 'متن شما حاوی کلمات نامناسب است. لطفاً ویرایش کنید.',
                'censored' => self::censor($bio)
            ];
        }

        // بررسی لینک
        if (preg_match('/(https?:\/\/|www\.|t\.me\/|@\w+)/i', $bio)) {
            return [
                'valid' => false,
                'message' => 'ارسال لینک یا آیدی در بیوگرافی مجاز نیست.',
            ];
        }

        return ['valid' => true];
    }
}
