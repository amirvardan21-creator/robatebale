<?php

/**
 * Validator - اعتبارسنجی ورودی‌های کاربر
 */
class Validator
{
    public static function name(string $name): bool
    {
        $len = mb_strlen(trim($name));
        return $len >= 2 && $len <= 30 && !preg_match('/[0-9@#$%^&*()_+=\[\]{}|\\\\:;"\'<>,.?\/`~]/u', $name);
    }

    public static function age(int $age): bool
    {
        return $age >= 18 && $age <= 80;
    }

    public static function gender(string $gender): bool
    {
        return in_array($gender, ['male', 'female'], true);
    }

    public static function city(string $city): bool
    {
        $provinces = [
            'تهران', 'اصفهان', 'فارس', 'خراسان رضوی', 'آذربایجان شرقی',
            'آذربایجان غربی', 'اردبیل', 'البرز', 'ایلام', 'بوشهر',
            'چهارمحال و بختیاری', 'خراسان جنوبی', 'خراسان شمالی', 'خوزستان', 'زنجان',
            'سمنان', 'سیستان و بلوچستان', 'گیلان', 'گلستان', 'همدان',
            'هرمزگان', 'کردستان', 'کرمان', 'کرمانشاه', 'کهگیلویه و بویراحمد',
            'لرستان', 'مازندران', 'مرکزی', 'قزوین', 'قم', 'یزد',
        ];
        return in_array($city, $provinces, true);
    }

    public static function bio(?string $bio): bool
    {
        if ($bio === null || $bio === '') return true;
        $len = mb_strlen($bio);
        return $len <= MAX_BIO_LENGTH && $len >= 3;
    }

    public static function textMessage(string $text): array
    {
        $text = trim($text);
        
        if (mb_strlen($text) === 0) {
            return ['valid' => false, 'error' => 'پیام خالی است'];
        }
        if (mb_strlen($text) > 2000) {
            return ['valid' => false, 'error' => 'پیام خیلی طولانی است (حداکثر ۲۰۰۰ کاراکتر)'];
        }
        // تشخیص اسپم ساده: تکرار کاراکتر
        if (preg_match('/(.)\1{10,}/u', $text)) {
            return ['valid' => false, 'error' => 'پیام اسپم تشخیص داده شد'];
        }
        // لینک‌ها را مسدود کن (اختیاری)
        if (preg_match('/https?:\/\//i', $text) || preg_match('/\b(?:t\.me|telegram\.me)\b/i', $text)) {
            return ['valid' => false, 'error' => 'ارسال لینک مجاز نیست'];
        }

        return ['valid' => true, 'clean' => htmlspecialchars($text, ENT_QUOTES, 'UTF-8')];
    }

    public static function profanityCheck(string $text): bool
    {
        // لیست ساده - می‌تواند از فایل یا دیتابیس خوانده شود
        $badWords = ['کلمه_زشت_نمونه']; // اینجا لیست واقعی اضافه کن
        $lower = mb_strtolower($text);
        foreach ($badWords as $word) {
            if (mb_strpos($lower, $word) !== false) {
                return false;
            }
        }
        return true;
    }

    public static function sanitizeBio(string $bio): string
    {
        $bio = trim($bio);
        $bio = mb_substr($bio, 0, MAX_BIO_LENGTH);
        $bio = htmlspecialchars($bio, ENT_QUOTES, 'UTF-8');
        // حذف ایموجی‌های بیش از حد (اختیاری)
        return $bio;
    }
}
