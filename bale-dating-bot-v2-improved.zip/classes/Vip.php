<?php

/**
 * Vip - مدیریت اشتراک ویژه بهبود یافته
 */
class Vip
{
    public static function isVip(int $userId): bool
    {
        $vip = Database::fetch(
            'SELECT id FROM vip_users WHERE user_id = ? AND is_active = 1 AND expires_at > NOW()',
            [$userId]
        );
        return (bool) $vip;
    }

    public static function getInfo(int $userId): ?array
    {
        return Database::fetch(
            'SELECT * FROM vip_users WHERE user_id = ? AND is_active = 1 ORDER BY expires_at DESC LIMIT 1',
            [$userId]
        );
    }

    public static function activate(int $userId, string $plan = 'monthly'): void
    {
        $days = match($plan) {
            'daily' => 1,
            'weekly' => 7,
            'quarterly' => 90,
            'yearly'    => 365,
            default     => 30,
        };
        
        Database::execute(
            'INSERT INTO vip_users (user_id, plan, started_at, expires_at) VALUES (?, ?, NOW(), DATE_ADD(NOW(), INTERVAL ? DAY))
             ON DUPLICATE KEY UPDATE plan = VALUES(plan), started_at = NOW(), expires_at = DATE_ADD(NOW(), INTERVAL ? DAY), is_active = 1',
            [$userId, $plan, $days, $days]
        );

        Logger::info("VIP activated for user $userId, plan $plan ($days days)");
        try {
            Coin::add($userId, 50, "جایزه فعال‌سازی VIP $plan");
        } catch (Throwable $e) {}
    }

    public static function deactivate(int $userId): void
    {
        Database::execute('UPDATE vip_users SET is_active = 0 WHERE user_id = ?', [$userId]);
    }

    public static function canView(int $userId): bool
    {
        if (self::isVip($userId)) return true;
        Profile::resetDailyCountsIfNeeded($userId);
        $profile = Profile::findByUserId($userId);
        $limit = self::getDailyLimit('free_daily_views', FREE_DAILY_VIEWS);
        return $profile && $profile['daily_views'] < $limit;
    }

    public static function canLike(int $userId): bool
    {
        if (self::isVip($userId)) return true;
        Profile::resetDailyCountsIfNeeded($userId);
        $profile = Profile::findByUserId($userId);
        $limit = self::getDailyLimit('free_daily_likes', FREE_DAILY_LIKES);
        return $profile && $profile['daily_likes'] < $limit;
    }

    public static function canSecretMeeting(int $userId): bool
    {
        if (self::isVip($userId)) return true;
        // کاربران عادی روزانه 5 چت مخفیانه رایگان
        $todayCount = Database::fetch(
            'SELECT COUNT(*) as cnt FROM secret_meeting_rooms WHERE (user1_id = ? OR user2_id = ?) AND DATE(created_at) = CURDATE()',
            [$userId, $userId]
        );
        return (int) ($todayCount['cnt'] ?? 0) < FREE_DAILY_SECRET;
    }

    public static function getRemainingViews(int $userId): int
    {
        if (self::isVip($userId)) return 999;
        Profile::resetDailyCountsIfNeeded($userId);
        $profile = Profile::findByUserId($userId);
        if (!$profile) return 0;
        $limit = self::getDailyLimit('free_daily_views', FREE_DAILY_VIEWS);
        return max(0, $limit - (int) $profile['daily_views']);
    }

    public static function getRemainingLikes(int $userId): int
    {
        if (self::isVip($userId)) return 999;
        Profile::resetDailyCountsIfNeeded($userId);
        $profile = Profile::findByUserId($userId);
        if (!$profile) return 0;
        $limit = self::getDailyLimit('free_daily_likes', FREE_DAILY_LIKES);
        return max(0, $limit - (int) $profile['daily_likes']);
    }

    private static function getDailyLimit(string $key, int $default): int
    {
        try {
            $row = Database::fetch('SELECT value FROM settings WHERE `key` = ?', [$key]);
            return $row ? (int) $row['value'] : $default;
        } catch (Throwable $e) {
            return $default;
        }
    }

    public static function getPlans(): array
    {
        return [
            'daily' => ['days' => 1, 'price_coins' => 15, 'title' => 'یک روزه', 'icon' => '⭐'],
            'weekly' => ['days' => 7, 'price_coins' => 50, 'title' => 'هفتگی', 'icon' => '🌟'],
            'monthly' => ['days' => 30, 'price_coins' => 100, 'title' => 'ماهانه', 'icon' => '💎', 'popular' => true],
            'quarterly' => ['days' => 90, 'price_coins' => 250, 'title' => 'سه ماهه', 'icon' => '👑', 'discount' => '۱۷٪ تخفیف'],
            'yearly' => ['days' => 365, 'price_coins' => 800, 'title' => 'سالانه', 'icon' => '🏆', 'discount' => '۳۳٪ تخفیف'],
        ];
    }

    public static function purchaseWithCoins(int $userId, string $plan): array
    {
        $plans = self::getPlans();
        if (!isset($plans[$plan])) {
            return ['success' => false, 'message' => 'پلن نامعتبر'];
        }

        $price = $plans[$plan]['price_coins'];
        if (Coin::getBalance($userId) < $price) {
            return ['success' => false, 'message' => "موجودی کافی نیست. نیاز: $price سکه، موجودی: " . Coin::getBalance($userId)];
        }

        if (!Coin::deduct($userId, $price, "خرید اشتراک $plan")) {
            return ['success' => false, 'message' => 'خطا در کسر سکه'];
        }

        self::activate($userId, $plan);
        return ['success' => true, 'message' => "✅ اشتراک {$plans[$plan]['title']} با موفقیت فعال شد!"];
    }

    public static function cleanupExpired(): int
    {
        try {
            return Database::execute('UPDATE vip_users SET is_active = 0 WHERE is_active = 1 AND expires_at < NOW()');
        } catch (Throwable $e) {
            return 0;
        }
    }
}
