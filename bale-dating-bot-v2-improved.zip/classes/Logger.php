<?php

/**
 * Logger - نسخه بهبود یافته
 * - چرخش خودکار لاگ (روزانه)
 * - سطوح مختلف
 * - فرمت JSON برای پردازش آسان
 * - حذف خودکار لاگ‌های قدیمی (۷ روز)
 */
class Logger
{
    private static ?string $fallbackUsed = null;
    private const RETENTION_DAYS = 7;
    private const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB

    public static function error(string $message, array $context = []): void
    {
        self::write('ERROR', $message, $context);
    }

    public static function info(string $message, array $context = []): void
    {
        self::write('INFO', $message, $context);
    }

    public static function warning(string $message, array $context = []): void
    {
        self::write('WARNING', $message, $context);
    }

    public static function debug(string $message, array $context = []): void
    {
        if (!env('APP_DEBUG', false)) return;
        self::write('DEBUG', $message, $context);
    }

    public static function security(string $message, array $context = []): void
    {
        self::write('SECURITY', $message, $context);
        // لاگ امنیتی در فایل جدا
        self::writeToFile(LOG_PATH . 'security-' . date('Y-m-d') . '.log', 'SECURITY', $message, $context);
    }

    private static function write(string $level, string $message, array $context = []): void
    {
        self::writeToFile(LOG_PATH . date('Y-m-d') . '.log', $level, $message, $context);

        // پاکسازی دوره‌ای (10% شانس در هر درخواست)
        if (rand(1, 10) === 1) {
            self::cleanup();
        }
    }

    private static function writeToFile(string $file, string $level, string $message, array $context = []): void
    {
        $timestamp = date('Y-m-d H:i:s');
        $contextStr = !empty($context) ? ' | ' . json_encode($context, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : '';
        $line = "[$timestamp] [$level] $message$contextStr" . PHP_EOL;

        $written = @file_put_contents($file, $line, FILE_APPEND | LOCK_EX);

        if ($written === false) {
            if (self::$fallbackUsed !== $file) {
                self::$fallbackUsed = $file;
                error_log("[BaleBot] Logger: cannot write to $file. Fallback to error_log.");
            }
            error_log("[BaleBot][$level] $message $contextStr");
            return;
        }

        // چرخش اگر فایل خیلی بزرگ شد
        if (filesize($file) > self::MAX_FILE_SIZE) {
            @rename($file, $file . '.' . time() . '.bak');
        }
    }

    private static function cleanup(): void
    {
        try {
            $files = glob(LOG_PATH . '*.log*');
            $cutoff = time() - (self::RETENTION_DAYS * 86400);
            foreach ($files as $f) {
                if (filemtime($f) < $cutoff) {
                    @unlink($f);
                }
            }
        } catch (Throwable $e) {
            // ignore
        }
    }

    public static function logQuery(string $sql, array $params = [], float $timeMs = 0): void
    {
        if (!env('LOG_QUERIES', false)) return;
        if ($timeMs > 1000) { // فقط کوئری‌های کند
            self::warning("Slow query ({$timeMs}ms): $sql", ['params' => $params]);
        }
    }

    public static function logUserAction(int $userId, string $action, array $data = []): void
    {
        self::info("User $userId: $action", $data);
    }
}
