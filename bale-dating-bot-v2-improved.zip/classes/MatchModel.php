<?php

/**
 * MatchModel - بهبود یافته
 * - سوپر لایک
 * - بوست
 * - آمار دقیق‌تر
 */
class MatchModel
{
    public static function addLike(int $fromUserId, int $toUserId, string $action, string $type = 'normal'): void
    {
        if ($fromUserId === $toUserId) return;

        // بررسی بلاک
        if (BlockReport::isBlockedEither($fromUserId, $toUserId)) {
            return;
        }

        Database::execute(
            'INSERT INTO likes (from_user_id, to_user_id, action, type) VALUES (?, ?, ?, ?) 
             ON DUPLICATE KEY UPDATE action = VALUES(action), type = VALUES(type), created_at = NOW()',
            [$fromUserId, $toUserId, $action, $type]
        );

        if ($action === 'like') {
            Profile::incrementLikes($toUserId);
            Logger::logUserAction($fromUserId, 'like', ['to' => $toUserId, 'type' => $type]);
            
            // اعلان به کاربری که لایک شده (اگر آنلاین باشد و تنظیمات اجازه دهد)
            // می‌توان در آینده push notification اضافه کرد
        }
    }

    public static function addSuperLike(int $fromUserId, int $toUserId): bool
    {
        // هزینه سوپر لایک
        if (Coin::getBalance($fromUserId) < 5) {
            return false;
        }

        if (!Coin::deduct($fromUserId, 5, "سوپر لایک به $toUserId")) {
            return false;
        }

        self::addLike($fromUserId, $toUserId, 'like', 'super');
        return true;
    }

    public static function checkMutualLike(int $userId1, int $userId2): bool
    {
        $like1 = Database::fetch(
            'SELECT id FROM likes WHERE from_user_id = ? AND to_user_id = ? AND action = "like"',
            [$userId1, $userId2]
        );
        $like2 = Database::fetch(
            'SELECT id FROM likes WHERE from_user_id = ? AND to_user_id = ? AND action = "like"',
            [$userId2, $userId1]
        );
        return (bool) $like1 && (bool) $like2;
    }

    public static function createMatch(int $userId1, int $userId2): int
    {
        $existing = self::getMatch($userId1, $userId2);
        if ($existing) {
            // فعال کردن مجدد اگر غیرفعال بوده
            if (empty($existing['is_active'])) {
                Database::execute('UPDATE matches SET is_active = 1 WHERE id = ?', [$existing['id']]);
            }
            return $existing['id'];
        }

        $u1 = min($userId1, $userId2);
        $u2 = max($userId1, $userId2);
        
        $id = Database::insert(
            'INSERT IGNORE INTO matches (user1_id, user2_id, created_at) VALUES (?, ?, NOW())',
            [$u1, $u2]
        );

        if ($id > 0) {
            Logger::info("New match created: $u1 <-> $u2 (id=$id)");
            // جایزه سکه برای مچ شدن (تشویقی)
            try {
                Coin::add($userId1, 2, "جایزه مچ با $userId2");
                Coin::add($userId2, 2, "جایزه مچ با $userId1");
            } catch (Throwable $e) {}
        }

        return $id ?: ($existing['id'] ?? 0);
    }

    public static function getMatch(int $userId1, int $userId2): ?array
    {
        $u1 = min($userId1, $userId2);
        $u2 = max($userId1, $userId2);
        return Database::fetch(
            'SELECT * FROM matches WHERE user1_id = ? AND user2_id = ?',
            [$u1, $u2]
        );
    }

    public static function getUserMatches(int $userId, int $limit = 20): array
    {
        return Database::fetchAll(
            'SELECT m.*, 
                CASE WHEN m.user1_id = ? THEN m.user2_id ELSE m.user1_id END as partner_id,
                p.name as partner_name, p.photo_file_id, p.age, p.city, p.gender,
                u.last_seen_at,
                (SELECT COUNT(*) FROM messages WHERE conversation_type = "match" AND conversation_id = m.id AND is_read = 0 AND sender_id != ?) as unread_count,
                (SELECT content FROM messages WHERE conversation_type = "match" AND conversation_id = m.id ORDER BY created_at DESC LIMIT 1) as last_message,
                (SELECT created_at FROM messages WHERE conversation_type = "match" AND conversation_id = m.id ORDER BY created_at DESC LIMIT 1) as last_message_time
             FROM matches m
             JOIN profiles p ON p.user_id = CASE WHEN m.user1_id = ? THEN m.user2_id ELSE m.user1_id END
             JOIN users u ON u.id = p.user_id
             WHERE (m.user1_id = ? OR m.user2_id = ?) AND m.is_active = 1
             ORDER BY last_message_time DESC, m.created_at DESC
             LIMIT ?',
            [$userId, $userId, $userId, $userId, $userId, $limit]
        );
    }

    public static function deleteMatch(int $matchId, int $userId): void
    {
        Database::execute(
            'UPDATE matches SET is_active = 0 WHERE id = ? AND (user1_id = ? OR user2_id = ?)',
            [$matchId, $userId, $userId]
        );
        Logger::logUserAction($userId, 'delete_match', ['match_id' => $matchId]);
    }

    public static function isMatched(int $userId1, int $userId2): bool
    {
        $match = self::getMatch($userId1, $userId2);
        return $match && ($match['is_active'] ?? 0) == 1;
    }

    public static function saveMessage(int $conversationId, int $senderId, string $content, string $type = 'text', string $conversationType = 'match'): int
    {
        // فیلتر محتوا
        if (ProfanityFilter::containsProfanity($content)) {
            $content = ProfanityFilter::censor($content);
        }

        $id = Database::insert(
            'INSERT INTO messages (conversation_id, conversation_type, sender_id, content, type) VALUES (?, ?, ?, ?, ?)',
            [$conversationId, $conversationType, $senderId, $content, $type]
        );

        // آپدیت last_message در جدول matches یا secret_meeting_rooms
        try {
            if ($conversationType === 'match') {
                Database::execute('UPDATE matches SET last_message_at = NOW() WHERE id = ?', [$conversationId]);
            }
        } catch (Throwable $e) {}

        return $id;
    }

    public static function getMessages(int $conversationId, string $conversationType = 'match', int $limit = 30, int $offset = 0): array
    {
        try {
            return Database::fetchAll(
                'SELECT m.*, p.name as sender_name FROM messages m 
                 JOIN profiles p ON p.user_id = m.sender_id 
                 WHERE m.conversation_type = ? AND m.conversation_id = ? 
                 ORDER BY m.created_at DESC LIMIT ? OFFSET ?',
                [$conversationType, $conversationId, $limit, $offset]
            );
        } catch (Throwable $e) {
            // fallback برای اسکیما قدیمی
            try {
                return Database::fetchAll(
                    'SELECT m.*, p.name as sender_name FROM messages m JOIN profiles p ON p.user_id = m.sender_id WHERE m.match_id = ? ORDER BY m.created_at DESC LIMIT ? OFFSET ?',
                    [$conversationId, $limit, $offset]
                );
            } catch (Throwable $e2) {
                return [];
            }
        }
    }

    public static function markAsRead(int $conversationId, string $conversationType, int $readerId): void
    {
        try {
            Database::execute(
                'UPDATE messages SET is_read = 1 WHERE conversation_type = ? AND conversation_id = ? AND sender_id != ? AND is_read = 0',
                [$conversationType, $conversationId, $readerId]
            );
        } catch (Throwable $e) {}
    }

    public static function getLikeStats(int $userId): array
    {
        $sent = Database::fetch('SELECT COUNT(*) as cnt FROM likes WHERE from_user_id = ? AND action = "like"', [$userId]);
        $received = Database::fetch('SELECT COUNT(*) as cnt FROM likes WHERE to_user_id = ? AND action = "like"', [$userId]);
        $matches = Database::fetch('SELECT COUNT(*) as cnt FROM matches WHERE (user1_id = ? OR user2_id = ?) AND is_active = 1', [$userId, $userId]);

        return [
            'sent' => (int) ($sent['cnt'] ?? 0),
            'received' => (int) ($received['cnt'] ?? 0),
            'matches' => (int) ($matches['cnt'] ?? 0),
        ];
    }

    public static function whoLikedMe(int $userId, int $limit = 20): array
    {
        return Database::fetchAll(
            'SELECT l.*, p.name, p.age, p.city, p.photo_file_id FROM likes l
             JOIN profiles p ON p.user_id = l.from_user_id
             JOIN users u ON u.id = l.from_user_id
             WHERE l.to_user_id = ? AND l.action = "like" AND u.is_blocked = 0
             ORDER BY l.created_at DESC LIMIT ?',
            [$userId, $limit]
        );
    }
}
