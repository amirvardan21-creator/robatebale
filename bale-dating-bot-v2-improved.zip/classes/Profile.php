<?php

/**
 * Profile - مدیریت پروفایل با بهبودهای جدید
 */
class Profile
{
    public static function findByUserId(int $userId): ?array
    {
        return Database::fetch('SELECT * FROM profiles WHERE user_id = ?', [$userId]);
    }

    public static function create(int $userId, array $data): int
    {
        // اعتبارسنجی نهایی
        if (!Validator::name($data['name'] ?? '')) {
            throw new InvalidArgumentException('نام نامعتبر');
        }
        if (!Validator::age((int) ($data['age'] ?? 0))) {
            throw new InvalidArgumentException('سن نامعتبر');
        }

        return Database::insert(
            'INSERT INTO profiles (user_id, name, age, gender, city, bio, interests, looking_for, photo_file_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [
                $userId,
                $data['name'],
                $data['age'],
                $data['gender'],
                $data['city'],
                $data['bio'] ?? null,
                $data['interests'] ?? null,
                $data['looking_for'] ?? null,
                $data['photo_file_id'] ?? null
            ]
        );
    }

    public static function update(int $userId, array $data): void
    {
        if (empty($data)) return;
        
        $fields = [];
        $params = [];
        foreach ($data as $key => $value) {
            $fields[] = "`$key` = ?";
            $params[] = $value;
        }
        $params[] = $userId;
        Database::execute('UPDATE profiles SET ' . implode(', ', $fields) . ' WHERE user_id = ?', $params);
    }

    public static function getForDiscovery(int $userId, array $filters = [], int $limit = 1): array
    {
        $seenIds = Database::fetchAll(
            'SELECT to_user_id FROM likes WHERE from_user_id = ? AND (action = "like" OR (action = "dislike" AND created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)))',
            [$userId]
        );
        $excludeIds = array_column($seenIds, 'to_user_id');
        $excludeIds[] = $userId;

        $blockedByMe = Database::fetchAll('SELECT blocked_id FROM blocked_users WHERE blocker_id = ?', [$userId]);
        $blockedMe = Database::fetchAll('SELECT blocker_id FROM blocked_users WHERE blocked_id = ?', [$userId]);
        $excludeIds = array_merge($excludeIds, array_column($blockedByMe, 'blocked_id'), array_column($blockedMe, 'blocker_id'));
        $excludeIds = array_unique(array_filter($excludeIds));

        $sql = 'SELECT p.*, u.bale_id, u.last_seen_at FROM profiles p JOIN users u ON p.user_id = u.id WHERE p.is_visible = 1 AND u.is_blocked = 0 AND u.is_active = 1';
        $params = [];

        if (!empty($excludeIds)) {
            $placeholders = implode(',', array_fill(0, count($excludeIds), '?'));
            $sql .= " AND p.user_id NOT IN ($placeholders)";
            $params = array_merge($params, $excludeIds);
        }

        if (!empty($filters['gender'])) {
            $sql .= ' AND p.gender = ?';
            $params[] = $filters['gender'];
        }
        if (!empty($filters['city'])) {
            $sql .= ' AND p.city = ?';
            $params[] = $filters['city'];
        }
        if (!empty($filters['age_min'])) {
            $sql .= ' AND p.age >= ?';
            $params[] = (int) $filters['age_min'];
        }
        if (!empty($filters['age_max'])) {
            $sql .= ' AND p.age <= ?';
            $params[] = (int) $filters['age_max'];
        }

        // اولویت: کاربران آنلاین، سپس کسانی که عکس دارند، سپس تصادفی
        // همچنین VIP ها اولویت دارند
        $sql .= ' ORDER BY 
            (CASE WHEN u.last_seen_at >= DATE_SUB(NOW(), INTERVAL 10 MINUTE) THEN 0 ELSE 1 END) ASC,
            (CASE WHEN p.photo_file_id IS NOT NULL AND p.photo_file_id != "" THEN 0 ELSE 1 END) ASC,
            RAND() 
            LIMIT ?';

        $stmt = Database::getInstance()->prepare($sql);
        foreach ($params as $i => $v) {
            $stmt->bindValue($i + 1, $v, is_int($v) ? PDO::PARAM_INT : PDO::PARAM_STR);
        }
        $stmt->bindValue(count($params) + 1, $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public static function resetDailyCountsIfNeeded(int $userId): void
    {
        $profile = self::findByUserId($userId);
        if (!$profile) return;
        $today = date('Y-m-d');
        if (($profile['last_reset_date'] ?? '') !== $today) {
            Database::execute(
                'UPDATE profiles SET daily_views = 0, daily_likes = 0, last_reset_date = ? WHERE user_id = ?',
                [$today, $userId]
            );
        }
    }

    public static function incrementViews(int $userId): void
    {
        Database::execute('UPDATE profiles SET daily_views = daily_views + 1, total_views = total_views + 1 WHERE user_id = ?', [$userId]);
    }

    public static function incrementLikes(int $userId): void
    {
        Database::execute('UPDATE profiles SET daily_likes = daily_likes + 1, total_likes = total_likes + 1 WHERE user_id = ?', [$userId]);
    }

    public static function findOnlinePartner(int $userId, array $filters = [], int $onlineMinutes = 10): ?array
    {
        $seenIds = Database::fetchAll(
            'SELECT to_user_id FROM likes WHERE from_user_id = ? AND (action = "like" OR (action = "dislike" AND created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)))',
            [$userId]
        );
        $blockedByMe = Database::fetchAll('SELECT blocked_id FROM blocked_users WHERE blocker_id = ?', [$userId]);
        $blockedMe = Database::fetchAll('SELECT blocker_id FROM blocked_users WHERE blocked_id = ?', [$userId]);
        $excludeIds = array_merge(
            [$userId],
            array_column($seenIds, 'to_user_id'),
            array_column($blockedByMe, 'blocked_id'),
            array_column($blockedMe, 'blocker_id')
        );
        $excludeIds = array_unique(array_filter($excludeIds));

        $sql = 'SELECT p.*, u.bale_id FROM profiles p
                JOIN users u ON p.user_id = u.id
                WHERE p.is_visible = 1
                AND u.is_blocked = 0
                AND u.is_active = 1
                AND u.step != "chatting"';
        $params = [];

        if (User::hasLastSeenColumn()) {
            $sql .= ' AND u.last_seen_at IS NOT NULL AND u.last_seen_at >= DATE_SUB(NOW(), INTERVAL ? MINUTE)';
            $params[] = $onlineMinutes;
        }

        if (!empty($excludeIds)) {
            $placeholders = implode(',', array_fill(0, count($excludeIds), '?'));
            $sql .= " AND p.user_id NOT IN ($placeholders)";
            $params = array_merge($params, $excludeIds);
        }

        if (!empty($filters['gender'])) {
            $sql .= ' AND p.gender = ?';
            $params[] = $filters['gender'];
        }
        if (!empty($filters['city'])) {
            $sql .= ' AND p.city = ?';
            $params[] = $filters['city'];
        }

        $sql .= ' ORDER BY RAND() LIMIT 1';

        return Database::fetch($sql, $params) ?: null;
    }

    public static function formatCard(array $profile, bool $full = true): string
    {
        $name = $profile['name'] ?? 'کاربر ناشناس';
        $age = $profile['age'] ?? '؟';
        $city = $profile['city'] ?? 'نامشخص';
        $gender = $profile['gender'] ?? '';
        $genderFa = $gender === 'male' ? '👨 آقا' : ($gender === 'female' ? '👩 خانم' : '⚧ نامشخص');
        $bio = $profile['bio'] ?? '';
        $interests = $profile['interests'] ?? '';
        $lookingFor = $profile['looking_for'] ?? '';
        $isVip = !empty($profile['is_vip']);

        $text = '';
        if ($isVip) $text .= "⭐ *عضو ویژه*\n";
        $text .= "👤 *{$name}*";
        if ($isVip) $text .= " ✅";
        $text .= "\n";
        $text .= "🎂 {$age} ساله | {$genderFa}\n";
        $text .= "📍 {$city}\n";

        // آنلاین بودن
        if (!empty($profile['last_seen_at'])) {
            $lastSeen = strtotime($profile['last_seen_at']);
            $diff = time() - $lastSeen;
            if ($diff < 600) {
                $text .= "🟢 آنلاین\n";
            } elseif ($diff < 3600) {
                $mins = floor($diff / 60);
                $text .= "🟡 {$mins} دقیقه پیش آنلاین بود\n";
            }
        }

        if ($full) {
            if (!empty($bio)) {
                $text .= "\n📝 *درباره من:*\n{$bio}\n";
            }
            if (!empty($interests)) {
                $text .= "\n🎯 *علایق:* {$interests}\n";
            }
            if (!empty($lookingFor)) {
                $text .= "\n💘 *دنبال:* {$lookingFor}\n";
            }
        }

        // آمار
        if ($full && isset($profile['total_views'])) {
            $text .= "\n👁 {$profile['total_views']} بازدید | ❤️ {$profile['total_likes']} لایک";
        }

        return $text;
    }

    public static function formatShort(array $profile): string
    {
        return self::formatCard($profile, false);
    }

    public static function searchByCity(string $city, int $excludeUserId, int $limit = 10): array
    {
        return Database::fetchAll(
            'SELECT p.*, u.bale_id FROM profiles p JOIN users u ON p.user_id = u.id 
             WHERE p.city = ? AND p.is_visible = 1 AND u.is_blocked = 0 AND p.user_id != ? 
             ORDER BY RAND() LIMIT ?',
            [$city, $excludeUserId, $limit]
        );
    }

    public static function getTopProfiles(int $limit = 10): array
    {
        return Database::fetchAll(
            'SELECT p.*, u.bale_id, (p.total_views + p.total_likes * 2) as score
             FROM profiles p JOIN users u ON p.user_id = u.id
             WHERE p.is_visible = 1 AND u.is_blocked = 0
             ORDER BY score DESC, p.created_at DESC LIMIT ?',
            [$limit]
        );
    }
}
