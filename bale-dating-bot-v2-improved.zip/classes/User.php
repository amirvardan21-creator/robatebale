<?php

/**
 * User - مدیریت کاربران با امکانات جدید
 * - سیستم دعوت (Referral)
 * - جایزه روزانه
 * - بهبود last_seen
 * - امتیاز و سطح کاربری
 */
class User
{
    public static function findByBaleId(int $baleId): ?array
    {
        return Database::fetch('SELECT * FROM users WHERE bale_id = ?', [$baleId]);
    }

    public static function findById(int $id): ?array
    {
        return Database::fetch('SELECT * FROM users WHERE id = ?', [$id]);
    }

    public static function create(int $baleId, string $firstName, ?string $lastName, ?string $username, ?int $referredBy = null): int
    {
        $id = Database::insert(
            'INSERT INTO users (bale_id, first_name, last_name, username, referred_by) VALUES (?, ?, ?, ?, ?)',
            [$baleId, $firstName, $lastName, $username, $referredBy]
        );

        // جایزه ثبت‌نام
        try {
            if (Database::tableExists('coins')) {
                Coin::add($id, START_BONUS, 'جایزه ثبت‌نام');
            }
        } catch (Throwable $e) {
            // ignore
        }

        // جایزه به دعوت‌کننده
        if ($referredBy) {
            try {
                Coin::add($referredBy, REFERRAL_BONUS, "دعوت کاربر $id");
                // ثبت در جدول referrals اگر وجود دارد
                if (Database::tableExists('referrals')) {
                    Database::execute(
                        'INSERT INTO referrals (referrer_id, referred_id, bonus) VALUES (?, ?, ?)',
                        [$referredBy, $id, REFERRAL_BONUS]
                    );
                }
            } catch (Throwable $e) {
                Logger::error("Referral bonus failed: " . $e->getMessage());
            }
        }

        Logger::logUserAction($id, 'user_created', ['bale_id' => $baleId, 'referred_by' => $referredBy]);
        return $id;
    }

    public static function updateStep(int $userId, string $step, ?array $stepData = null): void
    {
        Database::execute(
            'UPDATE users SET step = ?, step_data = ? WHERE id = ?',
            [$step, $stepData ? json_encode($stepData, JSON_UNESCAPED_UNICODE) : null, $userId]
        );
    }

    public static function updateUserStatus(int $userId, string $status, ?int $roomId = null): void
    {
        $sql = 'UPDATE users SET current_status = ?';
        $params = [$status];

        if ($status === 'in_secret_meeting' && $roomId !== null) {
            $sql .= ', current_secret_meeting_room_id = ?';
            $params[] = $roomId;
        } elseif ($status !== 'in_secret_meeting') {
            $sql .= ', current_secret_meeting_room_id = NULL';
        }

        $sql .= ' WHERE id = ?';
        $params[] = $userId;

        Database::execute($sql, $params);
    }

    public static function getStepData(array $user): ?array
    {
        if (empty($user['step_data'])) return null;
        if (is_array($user['step_data'])) return $user['step_data'];
        return json_decode($user['step_data'], true);
    }

    public static function isBlocked(int $userId): bool
    {
        $user = Database::fetch('SELECT is_blocked FROM users WHERE id = ?', [$userId]);
        return $user && $user['is_blocked'] == 1;
    }

    public static function block(int $userId, string $reason = ''): void
    {
        Database::execute('UPDATE users SET is_blocked = 1 WHERE id = ?', [$userId]);
        Logger::security("User $userId blocked", ['reason' => $reason]);
        
        // حذف از صف
        try {
            SecretMeetingQueue::removeFromQueue($userId);
        } catch (Throwable $e) {}
    }

    public static function unblock(int $userId): void
    {
        Database::execute('UPDATE users SET is_blocked = 0 WHERE id = ?', [$userId]);
        Logger::info("User $userId unblocked");
    }

    public static function delete(int $userId): void
    {
        Logger::security("User $userId deleted");
        Database::execute('DELETE FROM users WHERE id = ?', [$userId]);
    }

    public static function getAll(int $limit = 50, int $offset = 0): array
    {
        return Database::fetchAll(
            'SELECT u.*, p.name, p.age, p.city FROM users u LEFT JOIN profiles p ON u.id = p.user_id ORDER BY u.created_at DESC LIMIT ? OFFSET ?',
            [$limit, $offset]
        );
    }

    public static function count(): int
    {
        $row = Database::fetch('SELECT COUNT(*) as cnt FROM users');
        return (int) ($row['cnt'] ?? 0);
    }

    public static function countActive(): int
    {
        $row = Database::fetch('SELECT COUNT(*) as cnt FROM users WHERE is_active = 1 AND is_blocked = 0');
        return (int) ($row['cnt'] ?? 0);
    }

    public static function countOnline(int $minutes = 5): int
    {
        if (!self::hasLastSeenColumn()) return 0;
        try {
            $row = Database::fetch(
                'SELECT COUNT(*) as cnt FROM users WHERE last_seen_at >= DATE_SUB(NOW(), INTERVAL ? MINUTE) AND is_blocked = 0',
                [$minutes]
            );
            return (int) ($row['cnt'] ?? 0);
        } catch (Throwable $e) {
            return 0;
        }
    }

    public static function search(string $query): array
    {
        return Database::fetchAll(
            'SELECT u.*, p.name, p.age, p.city FROM users u LEFT JOIN profiles p ON u.id = p.user_id WHERE u.bale_id LIKE ? OR u.username LIKE ? OR p.name LIKE ? LIMIT 50',
            ["%$query%", "%$query%", "%$query%"]
        );
    }

    public static function touchLastSeen(int $userId): void
    {
        try {
            if (!self::ensureLastSeenColumn()) return;
            Database::execute('UPDATE users SET last_seen_at = NOW() WHERE id = ?', [$userId]);
        } catch (Throwable $e) {
            Logger::error('touchLastSeen failed: ' . $e->getMessage());
        }
    }

    public static function hasLastSeenColumn(): bool
    {
        return self::ensureLastSeenColumn();
    }

    private static function ensureLastSeenColumn(): bool
    {
        static $ready = null;
        if ($ready !== null) return $ready;

        try {
            $col = Database::fetch("SHOW COLUMNS FROM users LIKE 'last_seen_at'");
            if (!$col) {
                Database::execute('ALTER TABLE users ADD COLUMN last_seen_at TIMESTAMP NULL DEFAULT NULL');
                try {
                    Database::execute('CREATE INDEX idx_last_seen ON users (last_seen_at)');
                } catch (Throwable $e) {}
            }
            
            // ستون‌های جدید
            $col2 = Database::fetch("SHOW COLUMNS FROM users LIKE 'referred_by'");
            if (!$col2) {
                Database::execute('ALTER TABLE users ADD COLUMN referred_by INT UNSIGNED NULL DEFAULT NULL');
            }
            
            $col3 = Database::fetch("SHOW COLUMNS FROM users LIKE 'daily_streak'");
            if (!$col3) {
                Database::execute('ALTER TABLE users ADD COLUMN daily_streak INT DEFAULT 0');
            }

            $col4 = Database::fetch("SHOW COLUMNS FROM users LIKE 'last_daily_bonus'");
            if (!$col4) {
                Database::execute('ALTER TABLE users ADD COLUMN last_daily_bonus DATE NULL DEFAULT NULL');
            }

            $ready = true;
        } catch (Throwable $e) {
            Logger::error('ensureLastSeenColumn failed: ' . $e->getMessage());
            $ready = false;
        }

        return $ready;
    }

    /**
     * جایزه روزانه
     */
    public static function claimDailyBonus(int $userId): array
    {
        $user = self::findById($userId);
        if (!$user) return ['success' => false, 'message' => 'کاربر یافت نشد'];

        $today = date('Y-m-d');
        $lastBonus = $user['last_daily_bonus'] ?? null;

        if ($lastBonus === $today) {
            return ['success' => false, 'message' => 'شما امروز جایزه خود را دریافت کرده‌اید. فردا دوباره بیایید!'];
        }

        $streak = (int) ($user['daily_streak'] ?? 0);
        $yesterday = date('Y-m-d', strtotime('-1 day'));
        
        if ($lastBonus === $yesterday) {
            $streak++; // ادامه streak
        } else if ($lastBonus !== $today) {
            $streak = 1; // شروع جدید
        }

        // محاسبه جایزه بر اساس streak
        $bonus = DAILY_BONUS_COINS + min($streak - 1, 5); // هر روز ۱ سکه اضافه تا ۵

        Database::execute(
            'UPDATE users SET daily_streak = ?, last_daily_bonus = ? WHERE id = ?',
            [$streak, $today, $userId]
        );

        try {
            Coin::add($userId, $bonus, "جایزه روزانه (روز $streak)");
        } catch (Throwable $e) {
            Logger::error("Daily bonus coin add failed: " . $e->getMessage());
        }

        return [
            'success' => true,
            'bonus' => $bonus,
            'streak' => $streak,
            'message' => "🎁 تبریک! $bonus سکه جایزه روزانه دریافت کردی!\n🔥 streak فعلی: $streak روز"
        ];
    }

    public static function canClaimDaily(int $userId): bool
    {
        $user = self::findById($userId);
        if (!$user) return false;
        $today = date('Y-m-d');
        return ($user['last_daily_bonus'] ?? '') !== $today;
    }

    public static function getReferralLink(int $userId): string
    {
        $botUsername = BOT_USERNAME;
        return "https://ble.ir/{$botUsername}?start=ref_{$userId}";
    }

    public static function getReferralStats(int $userId): array
    {
        try {
            if (!Database::tableExists('referrals')) {
                $count = Database::fetch('SELECT COUNT(*) as cnt FROM users WHERE referred_by = ?', [$userId]);
                return ['count' => (int) ($count['cnt'] ?? 0), 'earned' => 0];
            }
            
            $stats = Database::fetch(
                'SELECT COUNT(*) as cnt, COALESCE(SUM(bonus),0) as earned FROM referrals WHERE referrer_id = ?',
                [$userId]
            );
            return [
                'count' => (int) ($stats['cnt'] ?? 0),
                'earned' => (int) ($stats['earned'] ?? 0)
            ];
        } catch (Throwable $e) {
            return ['count' => 0, 'earned' => 0];
        }
    }

    public static function getLevel(int $userId): array
    {
        try {
            $balance = Coin::getBalance($userId);
            $profile = Profile::findByUserId($userId);
            $matches = Database::fetch('SELECT COUNT(*) as cnt FROM matches WHERE (user1_id = ? OR user2_id = ?) AND is_active = 1', [$userId, $userId]);
            $matchCount = (int) ($matches['cnt'] ?? 0);
            
            $score = $balance + ($matchCount * 10) + (($profile['daily_views'] ?? 0) * 2);
            
            if ($score < 50) return ['level' => 1, 'title' => 'تازه‌وارد', 'icon' => '🌱'];
            if ($score < 150) return ['level' => 2, 'title' => 'فعال', 'icon' => '⭐'];
            if ($score < 400) return ['level' => 3, 'title' => 'حرفه‌ای', 'icon' => '🔥'];
            if ($score < 800) return ['level' => 4, 'title' => 'مافیای سطح بالا', 'icon' => '🎩'];
            return ['level' => 5, 'title' => 'پدرخوانده', 'icon' => '👑'];
        } catch (Throwable $e) {
            return ['level' => 1, 'title' => 'تازه‌وارد', 'icon' => '🌱'];
        }
    }
}
