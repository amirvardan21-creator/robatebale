<?php

/**
 * Bale API Client - نسخه بهبود یافته
 * - پشتیبانی از ارسال عکس، فایل، ویرایش پیام
 * - Retry logic
 * - Rate limiting handling
 * - بهبود مدیریت خطا
 */
class Bale
{
    private string $apiUrl;
    private int $timeout = 15;
    private int $maxRetries = 2;

    public function __construct()
    {
        $this->apiUrl = BALE_API_URL;
    }

    private function request(string $method, array $params = [], bool $isMultipart = false): ?array
    {
        $url = $this->apiUrl . $method;

        // reply_markup باید JSON string باشد
        if (isset($params['reply_markup']) && is_array($params['reply_markup'])) {
            $params['reply_markup'] = json_encode($params['reply_markup'], JSON_UNESCAPED_UNICODE);
        }

        $attempt = 0;
        $lastError = '';

        while ($attempt <= $this->maxRetries) {
            $ch = curl_init($url);
            
            $options = [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT        => $this->timeout,
                CURLOPT_CONNECTTIMEOUT => 5,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
                CURLOPT_USERAGENT      => 'BaleDatingBot/2.0',
            ];

            if ($isMultipart) {
                $options[CURLOPT_POST] = true;
                $options[CURLOPT_POSTFIELDS] = $params;
            } else {
                $options[CURLOPT_POST] = true;
                $options[CURLOPT_POSTFIELDS] = http_build_query($params);
            }

            curl_setopt_array($ch, $options);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlError = curl_error($ch);
            $curlErrno = curl_errno($ch);
            curl_close($ch);

            if ($curlError) {
                $lastError = "cURL [$curlErrno]: $curlError";
                Logger::warning("Bale API cURL error (attempt $attempt): $lastError", ['method' => $method]);
                $attempt++;
                if ($attempt <= $this->maxRetries) {
                    usleep(500000 * $attempt); // exponential backoff
                    continue;
                }
                Logger::error("[$method] cURL failed after retries: $lastError");
                return null;
            }

            $data = json_decode($response, true);
            
            if (!$data) {
                $lastError = "Invalid JSON response: " . substr($response, 0, 500);
                Logger::error("[$method] Invalid JSON: $response");
                return null;
            }

            if (!$data['ok']) {
                $errorCode = $data['error_code'] ?? 0;
                $description = $data['description'] ?? 'Unknown error';
                
                // خطاهای قابل retry
                if (in_array($errorCode, [429, 500, 502, 503, 504]) && $attempt < $this->maxRetries) {
                    Logger::warning("[$method] Retriable error $errorCode: $description (attempt $attempt)");
                    $attempt++;
                    $sleep = $errorCode === 429 ? 2 : 1;
                    sleep($sleep);
                    continue;
                }

                // خطاهای معروف که لاگ کمتر مهم دارند
                if (str_contains($description, 'message to delete not found')) {
                    Logger::info("[$method] Message not found for deletion (ok - maybe already deleted)");
                    return null;
                }
                if (str_contains($description, 'message is not modified')) {
                    return null; // تغییری نکرده - ok
                }

                Logger::error("[$method] API error (HTTP $httpCode, Code $errorCode): $description | Response: " . substr($response, 0, 1000));
                return null;
            }

            return $data['result'] ?? null;
        }

        return null;
    }

    public function sendMessage(int $chatId, string $text, array $replyMarkup = [], string $parseMode = 'Markdown'): ?array
    {
        // محدودیت طول پیام بله: 4096 کاراکتر
        if (mb_strlen($text) > 4000) {
            $text = mb_substr($text, 0, 4000) . '...';
        }

        $params = [
            'chat_id' => $chatId,
            'text'    => $text,
        ];
        
        if ($parseMode) {
            $params['parse_mode'] = $parseMode;
        }
        
        if (!empty($replyMarkup)) {
            $params['reply_markup'] = $replyMarkup;
        }

        $result = $this->request('sendMessage', $params);
        
        // اگر Markdown شکست خورد، بدون parse_mode امتحان کن
        if ($result === null && $parseMode !== '') {
            unset($params['parse_mode']);
            $result = $this->request('sendMessage', $params);
        }
        
        // آخرین تلاش: پاکسازی کاراکترهای مشکل‌ساز Markdown
        if ($result === null && $parseMode === 'Markdown') {
            $params['text'] = $this->sanitizeMarkdown($text);
            $params['parse_mode'] = 'Markdown';
            $result = $this->request('sendMessage', $params);
            
            if ($result === null) {
                unset($params['parse_mode']);
                $result = $this->request('sendMessage', $params);
            }
        }

        return $result;
    }

    public function sendPhoto(int $chatId, string $photoFileId, string $caption = '', array $replyMarkup = []): ?array
    {
        if (mb_strlen($caption) > 1000) {
            $caption = mb_substr($caption, 0, 1000) . '...';
        }

        $params = [
            'chat_id' => $chatId,
            'photo'   => $photoFileId,
            'caption' => $caption,
        ];
        
        if (!empty($caption)) {
            $params['parse_mode'] = 'Markdown';
        }
        if (!empty($replyMarkup)) {
            $params['reply_markup'] = $replyMarkup;
        }

        $result = $this->request('sendPhoto', $params);
        
        if ($result === null && !empty($caption)) {
            unset($params['parse_mode']);
            $result = $this->request('sendPhoto', $params);
        }

        // fallback به متن اگر عکس ارسال نشد (مثلاً file_id منقضی شده)
        if ($result === null) {
            Logger::warning("sendPhoto failed for chat $chatId, file_id: $photoFileId, falling back to text");
            $text = $caption ?: '🖼 عکس پروفایل';
            return $this->sendMessage($chatId, $text, $replyMarkup);
        }

        return $result;
    }

    public function sendChatAction(int $chatId, string $action = 'typing'): ?array
    {
        return $this->request('sendChatAction', [
            'chat_id' => $chatId,
            'action'  => $action,
        ]);
    }

    public function editMessageText(int $chatId, int $messageId, string $text, array $replyMarkup = []): ?array
    {
        $params = [
            'chat_id'    => $chatId,
            'message_id' => $messageId,
            'text'       => $text,
        ];
        if (!empty($replyMarkup)) {
            $params['reply_markup'] = $replyMarkup;
        }
        return $this->request('editMessageText', $params);
    }

    public function answerCallbackQuery(string $callbackQueryId, string $text = '', bool $showAlert = false): ?array
    {
        if ($callbackQueryId === '') {
            return null;
        }
        return $this->request('answerCallbackQuery', [
            'callback_query_id' => $callbackQueryId,
            'text'              => $text,
            'show_alert'        => $showAlert,
        ]);
    }

    public function deleteMessage(int $chatId, int $messageId): ?array
    {
        return $this->request('deleteMessage', [
            'chat_id'    => $chatId,
            'message_id' => $messageId,
        ]);
    }

    public function setWebhook(string $url): ?array
    {
        return $this->request('setWebhook', ['url' => $url]);
    }

    public function deleteWebhook(): ?array
    {
        return $this->request('deleteWebhook');
    }

    public function getWebhookInfo(): ?array
    {
        return $this->request('getWebhookInfo');
    }

    public function getMe(): ?array
    {
        return $this->request('getMe');
    }

    public function getFile(string $fileId): ?array
    {
        return $this->request('getFile', ['file_id' => $fileId]);
    }

    public function getUpdate(): ?array
    {
        $input = file_get_contents('php://input');
        if (empty($input)) return null;
        $data = json_decode($input, true);
        return $data ?: null;
    }

    // ===== Keyboard Builders =====

    public function mainMenuKeyboard(): array
    {
        return [
            'keyboard' => [
                [['text' => '🕶 ملاقات مخفیانه']],
                [['text' => '🔎 جستجوی پیشرفته'], ['text' => '❤️ پیدا کردن دوست']],
                [['text' => '💰 ثروت من'], ['text' => '📁 پرونده من'], ['text' => '💬 گفتگوهای من']],
                [['text' => '🎁 جایزه روزانه'], ['text' => '👥 دعوت دوستان'], ['text' => '🏆 برترین‌ها']],
                [['text' => '💎 خرید اشتراک'], ['text' => '⚙ تنظیمات']],
            ],
            'resize_keyboard'   => true,
            'one_time_keyboard' => false,
        ];
    }

    public function inlineKeyboard(array $buttons): array
    {
        return ['inline_keyboard' => $buttons];
    }

    public function removeKeyboard(): array
    {
        return ['remove_keyboard' => true];
    }

    public function secretMeetingKeyboard(): array
    {
        $randomCost = COST_RANDOM > 0 ? COST_RANDOM . ' سکه' : 'رایگان';
        return [
            'keyboard' => [
                [['text' => "🎲 جستجوی شانسی ($randomCost)"]],
                [['text' => '👨 جستجوی پسر (' . COST_GENDER . ' سکه)'], ['text' => '👩 جستجوی دختر (' . COST_GENDER . ' سکه)']],
                [['text' => '🗺 جستجوی بر اساس استان (' . COST_PROVINCE . ' سکه)']],
                [['text' => '🔙 بازگشت']],
            ],
            'resize_keyboard'   => true,
            'one_time_keyboard' => false,
        ];
    }

    public function secretMeetingChatKeyboard(int $partnerId, int $roomId): array
    {
        return [
            'keyboard' => [
                [['text' => '👤 مشاهده پرونده مخاطب']],
                [['text' => '🎁 هدیه دادن'], ['text' => '🚨 گزارش کاربر']],
                [['text' => '🗑 حذف پیام‌ها'], ['text' => '❌ پایان گفت‌وگو']],
            ],
            'resize_keyboard'   => true,
            'one_time_keyboard' => false,
        ];
    }

    public function discoveryKeyboard(int $targetUserId): array
    {
        return $this->inlineKeyboard([
            [
                ['text' => '❤️ پسندیدن', 'callback_data' => 'like_' . $targetUserId],
                ['text' => '❌ رد کردن', 'callback_data' => 'dislike_' . $targetUserId],
            ],
            [
                ['text' => '⏭ بعدی', 'callback_data' => 'next_' . $targetUserId],
                ['text' => '🚨 گزارش', 'callback_data' => 'report_' . $targetUserId],
            ],
        ]);
    }

    public function genderKeyboard(): array
    {
        return [
            'keyboard' => [
                [['text' => '👨 مرد'], ['text' => '👩 زن']],
                [['text' => '🔙 بازگشت']],
            ],
            'resize_keyboard'   => true,
            'one_time_keyboard' => true,
        ];
    }

    public function ageKeyboard(): array
    {
        $rows = [];
        $row = [];
        for ($i = 18; $i <= 50; $i++) {
            $row[] = ['text' => (string)$i];
            if (count($row) === 5) {
                $rows[] = $row;
                $row = [];
            }
        }
        if ($row) $rows[] = $row;
        $rows[] = [['text' => '🔙 بازگشت']];
        return ['keyboard' => $rows, 'resize_keyboard' => true, 'one_time_keyboard' => true];
    }

    public function provinceKeyboard(): array
    {
        $provinces = $this->getProvinces();
        $rows = [];
        $row = [];
        foreach ($provinces as $p) {
            $row[] = ['text' => $p];
            if (count($row) === 2) {
                $rows[] = $row;
                $row = [];
            }
        }
        if ($row) $rows[] = $row;
        $rows[] = [['text' => '🔙 بازگشت']];

        return [
            'keyboard'          => $rows,
            'resize_keyboard'   => true,
            'one_time_keyboard' => true,
        ];
    }

    public function getProvinces(): array
    {
        return [
            'تهران', 'اصفهان', 'فارس', 'خراسان رضوی', 'آذربایجان شرقی',
            'آذربایجان غربی', 'اردبیل', 'البرز', 'ایلام', 'بوشهر',
            'چهارمحال و بختیاری', 'خراسان جنوبی', 'خراسان شمالی', 'خوزستان', 'زنجان',
            'سمنان', 'سیستان و بلوچستان', 'گیلان', 'گلستان', 'همدان',
            'هرمزگان', 'کردستان', 'کرمان', 'کرمانشاه', 'کهگیلویه و بویراحمد',
            'لرستان', 'مازندران', 'مرکزی', 'قزوین', 'قم', 'یزد',
        ];
    }

    private function sanitizeMarkdown(string $text): string
    {
        // حذف کاراکترهای مشکل‌ساز Markdown که باعث خطا می‌شوند
        // اما ایموجی‌ها را نگه دار
        $text = str_replace(['`', '[', ']'], ['\'', '(', ')'], $text);
        // حذف ** ناقص - ساده‌ترین راه: جایگزینی با *
        // از regex برای پیدا کردن ** بدون جفت استفاده می‌کنیم - فعلا ساده حذف می‌کنیم
        return $text;
    }
}
