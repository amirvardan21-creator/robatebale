<?php

/**
 * SecretMeetingRoom - بهبود یافته
 * - مدیریت زمان اتاق
 * - آمار
 * - پایان خودکار
 */
class SecretMeetingRoom
{
    public const STATUS_ACTIVE = 'active';
    public const STATUS_ENDED_BY_USER1 = 'ended_by_user1';
    public const STATUS_ENDED_BY_USER2 = 'ended_by_user2';
    public const STATUS_ENDED_MUTUALLY = 'ended_mutually';
    public const STATUS_ABORTED = 'aborted';
    public const STATUS_EXPIRED = 'expired';

    public const MAX_DURATION_MINUTES = 60; // حداکثر زمان چت مخفیانه

    public static function createRoom(
        int $user1Id,
        int $user2Id,
        string $searchType,
        ?string $provinceFilter,
        ?string $genderFilter
    ): int {
        return Database::insert(
            'INSERT INTO secret_meeting_rooms (user1_id, user2_id, status, search_type, province_filter, gender_filter, created_at) 
             VALUES (?, ?, "active", ?, ?, ?, NOW())',
            [$user1Id, $user2Id, $searchType, $provinceFilter, $genderFilter]
        );
    }

    public static function getRoomById(int $roomId): ?array
    {
        return Database::fetch('SELECT * FROM secret_meeting_rooms WHERE id = ?', [$roomId]);
    }

    public static function getActiveRoomByUserId(int $userId): ?array
    {
        return Database::fetch(
            'SELECT * FROM secret_meeting_rooms WHERE (user1_id = ? OR user2_id = ?) AND status = "active" ORDER BY created_at DESC LIMIT 1',
            [$userId, $userId]
        );
    }

    public static function endRoom(int $roomId, string $endedBy): void
    {
        $validStatuses = ['ended_by_user1', 'ended_by_user2', 'ended_mutually', 'aborted', 'expired', 'active'];
        if (!in_array($endedBy, $validStatuses, true)) {
            $endedBy = 'aborted';
        }

        Database::execute(
            'UPDATE secret_meeting_rooms SET status = ?, ended_at = NOW() WHERE id = ? AND status = "active"',
            [$endedBy, $roomId]
        );

        Logger::info("Secret room $roomId ended by $endedBy");

        // آزادسازی کاربران
        try {
            $room = self::getRoomById($roomId);
            if ($room) {
                // اگر اتاق بیش از 10 پیام داشته، هر دو 1 سکه جایزه می‌گیرند
                $msgCount = Database::fetch(
                    'SELECT COUNT(*) as cnt FROM messages WHERE conversation_type = "secret_meeting" AND conversation_id = ?',
                    [$roomId]
                );
                if ((int) ($msgCount['cnt'] ?? 0) >= 10) {
                    Coin::add($room['user1_id'], 1, "جایزه چت مخفیانه اتاق $roomId");
                    Coin::add($room['user2_id'], 1, "جایزه چت مخفیانه اتاق $roomId");
                }
            }
        } catch (Throwable $e) {}
    }

    public static function getRoomWithPartner(int $roomId, int $userId): ?array
    {
        $room = self::getRoomById($roomId);
        if (!$room) return null;

        if ((int) $room['user1_id'] !== $userId && (int) $room['user2_id'] !== $userId) {
            return null; // کاربر عضو اتاق نیست
        }

        $partnerId = (int) $room['user1_id'] === $userId ? (int) $room['user2_id'] : (int) $room['user1_id'];
        $partner = User::findById($partnerId);
        $partnerProfile = Profile::findByUserId($partnerId);

        $room['partner_id'] = $partnerId;
        $room['partner'] = $partner;
        $room['partner_profile'] = $partnerProfile;

        return $room;
    }

    public static function getUserActiveRooms(int $userId): array
    {
        return Database::fetchAll(
            'SELECT * FROM secret_meeting_rooms WHERE (user1_id = ? OR user2_id = ?) AND status = "active"',
            [$userId, $userId]
        );
    }

    public static function cleanupExpired(): int
    {
        try {
            // اتاق‌های فعال بیش از MAX_DURATION
            $expired = Database::fetchAll(
                'SELECT id FROM secret_meeting_rooms WHERE status = "active" AND created_at < DATE_SUB(NOW(), INTERVAL ? MINUTE)',
                [self::MAX_DURATION_MINUTES]
            );

            $count = 0;
            foreach ($expired as $room) {
                self::endRoom((int) $room['id'], self::STATUS_EXPIRED);
                $count++;
            }

            if ($count > 0) {
                Logger::info("Cleaned $count expired secret rooms");
            }

            return $count;
        } catch (Throwable $e) {
            Logger::error("cleanupExpired failed: " . $e->getMessage());
            return 0;
        }
    }

    public static function getStats(): array
    {
        try {
            $active = Database::fetch('SELECT COUNT(*) as cnt FROM secret_meeting_rooms WHERE status = "active"');
            $today = Database::fetch('SELECT COUNT(*) as cnt FROM secret_meeting_rooms WHERE DATE(created_at) = CURDATE()');
            $total = Database::fetch('SELECT COUNT(*) as cnt FROM secret_meeting_rooms');

            return [
                'active' => (int) ($active['cnt'] ?? 0),
                'today' => (int) ($today['cnt'] ?? 0),
                'total' => (int) ($total['cnt'] ?? 0),
            ];
        } catch (Throwable $e) {
            return ['active' => 0, 'today' => 0, 'total' => 0];
        }
    }

    public static function isUserInActiveRoom(int $userId): bool
    {
        return self::getActiveRoomByUserId($userId) !== null;
    }
}
