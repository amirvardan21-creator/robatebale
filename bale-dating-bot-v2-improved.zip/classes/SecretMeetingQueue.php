<?php

/**
 * Secret Meeting Queue — منطق صف و Matchmaking
 *
 * طراحی:
 *  - هر کاربر فقط در یک صف حضور دارد (UNIQUE constraint روی user_id در DB).
 *  - addToQueue به صورت Idempotent است (INSERT ... ON DUPLICATE KEY UPDATE).
 *  - tryMatchUser یک تراکنش اتمیک انجام می‌دهد:
 *      1. صف خود کاربر را قفل می‌کند (SELECT ... FOR UPDATE).
 *      2. تمام صف‌های دیگر را در ترتیب user_id قفل می‌کند (جلوگیری از Deadlock).
 *      3. اولین کاربر سازگار را برمی‌کند (VIP اول، سپس قدیمی‌ترین).
 *      4. اتاق می‌سازد، هر دو را از صف حذف می‌کند، وضعیت هر دو را به
 *         in_secret_meeting تغییر می‌دهد — همه داخل همان تراکنش.
 *  - Race-condition ایمن: هم‌زمانی دو webhook با هم هیچ کاربری را دو بار مچ نمی‌کنند.
 */
class SecretMeetingQueue
{
    /**
     * مدت زمانی که بعد از آن یک کاربر در صف به‌عنوان "غیرفعال" در نظر گرفته می‌شود.
     */
    private const STALE_TIMEOUT_MINUTES = 10;

    /**
     * افزودن کاربر به صف. اگر قبلاً در صف است، ترجیحاتش آپدیت می‌شود.
     */
    public static function addToQueue(
        int $userId,
        string $searchPreference,
        ?string $genderPreference,
        ?string $provincePreference,
        int $vipPriority = 0
    ): void {
        Database::execute(
            'INSERT INTO secret_meeting_queue
                (user_id, search_preference, gender_preference, province_preference, vip_priority, queued_at, last_ping_at)
             VALUES (?, ?, ?, ?, ?, NOW(), NOW())
             ON DUPLICATE KEY UPDATE
                search_preference   = VALUES(search_preference),
                gender_preference   = VALUES(gender_preference),
                province_preference = VALUES(province_preference),
                vip_priority        = VALUES(vip_priority),
                queued_at           = NOW(),
                last_ping_at        = NOW()',
            [$userId, $searchPreference, $genderPreference, $provincePreference, $vipPriority]
        );
        User::updateUserStatus($userId, 'in_queue');
    }

    /**
     * حذف کاربر از صف و بازگشت وضعیت به idle.
     */
    public static function removeFromQueue(int $userId): void
    {
        Database::execute(
            'DELETE FROM secret_meeting_queue WHERE user_id = ?',
            [$userId]
        );
        User::updateUserStatus($userId, 'idle');
    }

    /**
     * بررسی وجود کاربر در صف.
     */
    public static function findUserInQueue(int $userId): ?array
    {
        return Database::fetch('SELECT * FROM secret_meeting_queue WHERE user_id = ?', [$userId]);
    }

    /**
     * منطق سازگاری: آیا کاربر A (با صف QA و پروفایل PA) کاربر B (با پروفایل PB) را می‌پذیرد؟
     *
     * قوانین:
     *  - random: همه را می‌پذیرد.
     *  - gender_male: فقط مرد.
     *  - gender_female: فقط زن.
     *  - province: باید same province + same gender preference باشد.
     */
    private static function userAccepts(array $queueA, array $profileA, array $profileB): bool
    {
        switch ($queueA['search_preference']) {
            case 'random':
                return true;

            case 'gender_male':
                return ($profileB['gender'] ?? '') === 'male';

            case 'gender_female':
                return ($profileB['gender'] ?? '') === 'female';

            case 'province':
                if (empty($queueA['province_preference'])) {
                    return false;
                }
                if (($profileB['city'] ?? '') !== $queueA['province_preference']) {
                    return false;
                }
                if (!empty($queueA['gender_preference'])) {
                    if (($profileB['gender'] ?? '') !== $queueA['gender_preference']) {
                        return false;
                    }
                }
                return true;

            default:
                return false;
        }
    }

    /**
     * تلاش برای مچ کردن کاربر با کسی در صف.
     *
     * این متد یک تراکنش اتمیک انجام می‌دهد که شامل:
     *  - قفل کردن صف خود کاربر و تمام صف‌های دیگر
     *  - یافتن اولین کاربر سازگار (VIP اول، سپس قدیمی‌ترین)
     *  - ساخت اتاق، حذف هر دو از صف، آپدیت وضعیت هر دو به in_secret_meeting
     *
     * @return array|null در صورت موفقیت: ['room_id', 'partner_user_id', 'partner_bale_id']
     *                    در غیر این صورت null.
     */
    public static function tryMatchUser(int $userId): ?array
    {
        $pdo = Database::getInstance();

        try {
            $pdo->beginTransaction();

            // قفل کردن تمام ردیف‌های صف در ترتیب user_id (جلوگیری از Deadlock)
            // این کار تمام تراکنش‌های هم‌زمان را سریال می‌کند؛ برای ربات‌های کوچک تا متوسط کاملاً مناسب است.
            $stmt = $pdo->prepare(
                'SELECT sq.*, p.gender, p.city, u.bale_id AS user_bale_id
                 FROM secret_meeting_queue sq
                 JOIN users u ON sq.user_id = u.id
                 JOIN profiles p ON sq.user_id = p.user_id
                 WHERE u.current_status = "in_queue"
                   AND u.is_blocked = 0
                   AND u.is_active = 1
                   AND (u.last_seen_at IS NULL OR u.last_seen_at >= DATE_SUB(NOW(), INTERVAL ? MINUTE))
                 ORDER BY sq.user_id ASC
                 FOR UPDATE'
            );
            $stmt->execute([self::STALE_TIMEOUT_MINUTES]);
            $allRows = $stmt->fetchAll();

            // پیدا کردن ردیف خود کاربر
            $myQueue = null;
            $myProfile = null;
            $myBaleId = 0;
            foreach ($allRows as $row) {
                if ((int) $row['user_id'] === $userId) {
                    $myQueue = $row;
                    $myProfile = ['gender' => $row['gender'], 'city' => $row['city']];
                    $myBaleId = (int) $row['user_bale_id'];
                    break;
                }
            }

            if (!$myQueue || !$myProfile) {
                $pdo->commit();
                return null; // کاربر در صف نیست یا پروفایل ندارد
            }

            // مرتب‌سازی در PHP: VIP اول، سپس قدیمی‌ترین queued_at
            usort($allRows, function ($a, $b) {
                $vipA = (int) ($a['vip_priority'] ?? 0);
                $vipB = (int) ($b['vip_priority'] ?? 0);
                if ($vipA !== $vipB) {
                    return $vipB - $vipA; // DESC
                }
                return strcmp($a['queued_at'] ?? '', $b['queued_at'] ?? ''); // ASC
            });

            $matchedPartner = null;

            foreach ($allRows as $candidate) {
                $candidateUserId = (int) $candidate['user_id'];
                if ($candidateUserId === $userId) {
                    continue;
                }

                $partnerProfile = [
                    'gender' => $candidate['gender'],
                    'city'   => $candidate['city'],
                ];
                $partnerQueue = [
                    'search_preference'   => $candidate['search_preference'],
                    'gender_preference'   => $candidate['gender_preference'],
                    'province_preference' => $candidate['province_preference'],
                ];

                // من باید او را بپذیرم
                if (!self::userAccepts($myQueue, $myProfile, $partnerProfile)) {
                    continue;
                }
                // و او باید مرا بپذیرد
                if (!self::userAccepts($partnerQueue, $partnerProfile, $myProfile)) {
                    continue;
                }

                $matchedPartner = $candidate;
                break;
            }

            if (!$matchedPartner) {
                $pdo->commit();
                return null; // هیچ کاربر سازگاری پیدا نشد
            }

            $partnerUserId = (int) $matchedPartner['user_id'];
            $partnerBaleId = (int) $matchedPartner['user_bale_id'];

            // ساخت اتاق داخل تراکنش
            $stmt = $pdo->prepare(
                'INSERT INTO secret_meeting_rooms
                    (user1_id, user2_id, status, search_type, province_filter, gender_filter, created_at)
                 VALUES (?, ?, "active", ?, ?, ?, NOW())'
            );
            $stmt->execute([
                $userId,
                $partnerUserId,
                $myQueue['search_preference'],
                $myQueue['province_preference'],
                $myQueue['gender_preference'],
            ]);
            $roomId = (int) $pdo->lastInsertId();

            // حذف هر دو از صف
            $stmt = $pdo->prepare('DELETE FROM secret_meeting_queue WHERE user_id IN (?, ?)');
            $stmt->execute([$userId, $partnerUserId]);

            // آپدیت وضعیت هر دو به in_secret_meeting + step به chatting
            $stmt = $pdo->prepare(
                'UPDATE users
                 SET current_status = "in_secret_meeting",
                     current_secret_meeting_room_id = ?,
                     step = "chatting",
                     step_data = ?
                 WHERE id = ?'
            );
            $stmt->execute([
                $roomId,
                json_encode(['secret_meeting_room_id' => $roomId, 'partner_id' => $partnerUserId]),
                $userId,
            ]);
            $stmt->execute([
                $roomId,
                json_encode(['secret_meeting_room_id' => $roomId, 'partner_id' => $userId]),
                $partnerUserId,
            ]);

            $pdo->commit();

            return [
                'room_id'         => $roomId,
                'partner_user_id' => $partnerUserId,
                'partner_bale_id' => $partnerBaleId,
                'my_bale_id'      => $myBaleId,
            ];
        } catch (Throwable $e) {
            try {
                $pdo->rollBack();
            } catch (Throwable) {
                // ignore
            }
            Logger::error('tryMatchUser failed (user=' . $userId . '): ' . $e->getMessage());
            return null;
        }
    }

    /**
     * پاکسازی صف از کاربرانی که مدت طولانی است آنلاین نبوده‌اند.
     * این متد توسط cron job فراخوانی می‌شود.
     *
     * @return int تعداد ردیف‌های پاک شده
     */
    public static function cleanStaleEntries(int $timeoutMinutes = self::STALE_TIMEOUT_MINUTES): int
    {
        try {
            $stale = Database::fetchAll(
                'SELECT sq.user_id FROM secret_meeting_queue sq
                 JOIN users u ON sq.user_id = u.id
                 WHERE u.last_seen_at IS NULL
                    OR u.last_seen_at < DATE_SUB(NOW(), INTERVAL ? MINUTE)',
                [$timeoutMinutes]
            );

            $count = 0;
            foreach ($stale as $row) {
                self::removeFromQueue((int) $row['user_id']);
                $count++;
            }
            return $count;
        } catch (Throwable $e) {
            Logger::error('cleanStaleEntries failed: ' . $e->getMessage());
            return 0;
        }
    }

    /**
     * پاکسازی اتاق‌های متروکه (کاربر در in_secret_meeting ولی اتاق ending شده یا ناقص).
     * برای جلوگیری از گیر کردن کاربران در وضعیت in_secret_meeting.
     *
     * @return int تعداد کاربرانی که وضعیتشان پاکسازی شد
     */
    public static function cleanOrphanedStatuses(): int
    {
        try {
            // کاربرانی که در in_secret_meeting هستند ولی اتاقشان دیگر active نیست
            $orphans = Database::fetchAll(
                'SELECT u.id, u.current_secret_meeting_room_id
                 FROM users u
                 LEFT JOIN secret_meeting_rooms r ON r.id = u.current_secret_meeting_room_id
                 WHERE u.current_status = "in_secret_meeting"
                   AND (r.id IS NULL OR r.status != "active")'
            );

            $count = 0;
            foreach ($orphans as $row) {
                User::updateUserStatus((int) $row['id'], 'idle');
                $count++;
            }
            return $count;
        } catch (Throwable $e) {
            Logger::error('cleanOrphanedStatuses failed: ' . $e->getMessage());
            return 0;
        }
    }
}
