<?php

/**
 * Coin - سیستم سکه بهبود یافته
 * - تراکنش‌های امن
 * - تاریخچه کامل
 * - جوایز و بونوس‌ها
 */
class Coin
{
    private static function tableExists(): bool
    {
        static $exists = null;
        if ($exists !== null) return $exists;

        try {
            $exists = Database::tableExists('coins');
        } catch (Throwable $e) {
            $exists = false;
        }
        return $exists;
    }

    public static function getBalance(int $userId): int
    {
        if (!self::tableExists()) return START_BONUS;

        try {
            $row = Database::fetch('SELECT balance FROM coins WHERE user_id = ?', [$userId]);
            if (!$row) {
                // اگر کاربر رکورد ندارد، بساز
                Database::execute(
                    'INSERT IGNORE INTO coins (user_id, balance) VALUES (?, ?)',
                    [$userId, START_BONUS]
                );
                return START_BONUS;
            }
            return (int) $row['balance'];
        } catch (Throwable $e) {
            Logger::error('Coin getBalance failed: ' . $e->getMessage());
            return 0;
        }
    }

    public static function add(int $userId, int $amount, string $description = '', ?int $adminId = null): void
    {
        if ($amount <= 0) return;

        Database::execute(
            'INSERT INTO coins (user_id, balance) VALUES (?, ?) ON DUPLICATE KEY UPDATE balance = balance + ?',
            [$userId, $amount, $amount]
        );
        
        try {
            Database::execute(
                'INSERT INTO coin_transactions (user_id, amount, type, description, admin_id) VALUES (?, ?, "add", ?, ?)',
                [$userId, $amount, $description, $adminId]
            );
        } catch (Throwable $e) {
            // اگر جدول transactions وجود ندارد
        }

        Logger::logUserAction($userId, 'coin_add', ['amount' => $amount, 'desc' => $description]);
    }

    public static function deduct(int $userId, int $amount, string $description = ''): bool
    {
        if ($amount <= 0) return true;
        if (!self::tableExists()) return false;

        try {
            return Database::transaction(function() use ($userId, $amount, $description) {
                // قفل کردن ردیف برای جلوگیری از race condition
                $row = Database::fetch('SELECT balance FROM coins WHERE user_id = ? FOR UPDATE', [$userId]);
                $balance = $row ? (int) $row['balance'] : 0;

                if ($balance < $amount) {
                    return false;
                }

                Database::execute(
                    'UPDATE coins SET balance = balance - ? WHERE user_id = ?',
                    [$amount, $userId]
                );

                try {
                    Database::execute(
                        'INSERT INTO coin_transactions (user_id, amount, type, description) VALUES (?, ?, "deduct", ?)',
                        [$userId, $amount, $description]
                    );
                } catch (Throwable $e) {}

                Logger::logUserAction($userId, 'coin_deduct', ['amount' => $amount, 'desc' => $description]);
                return true;
            });
        } catch (Throwable $e) {
            Logger::error('Coin deduct failed: ' . $e->getMessage());
            return false;
        }
    }

    public static function set(int $userId, int $amount, ?int $adminId = null): void
    {
        $current = self::getBalance($userId);
        Database::execute(
            'INSERT INTO coins (user_id, balance) VALUES (?, ?) ON DUPLICATE KEY UPDATE balance = ?',
            [$userId, $amount, $amount]
        );
        $diff = $amount - $current;
        try {
            Database::execute(
                'INSERT INTO coin_transactions (user_id, amount, type, description, admin_id) VALUES (?, ?, "set", ?, ?)',
                [$userId, $diff, 'تنظیم مستقیم توسط ادمین به ' . $amount, $adminId]
            );
        } catch (Throwable $e) {}
    }

    public static function getTransactions(int $userId, int $limit = 20): array
    {
        try {
            return Database::fetchAll(
                'SELECT * FROM coin_transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT ?',
                [$userId, $limit]
            );
        } catch (Throwable $e) {
            return [];
        }
    }

    public static function getTopUsers(int $limit = 10): array
    {
        try {
            return Database::fetchAll(
                'SELECT c.*, p.name, u.bale_id FROM coins c JOIN users u ON c.user_id = u.id LEFT JOIN profiles p ON p.user_id = c.user_id ORDER BY c.balance DESC LIMIT ?',
                [$limit]
            );
        } catch (Throwable $e) {
            return [];
        }
    }

    public static function transfer(int $fromUserId, int $toUserId, int $amount, string $description = 'هدیه'): bool
    {
        if ($fromUserId === $toUserId) return false;
        if ($amount <= 0) return false;

        try {
            return Database::transaction(function() use ($fromUserId, $toUserId, $amount, $description) {
                $fromBalance = self::getBalance($fromUserId);
                if ($fromBalance < $amount) return false;

                Database::execute(
                    'UPDATE coins SET balance = balance - ? WHERE user_id = ?',
                    [$amount, $fromUserId]
                );
                Database::execute(
                    'INSERT INTO coins (user_id, balance) VALUES (?, ?) ON DUPLICATE KEY UPDATE balance = balance + ?',
                    [$toUserId, $amount, $amount]
                );

                try {
                    Database::execute(
                        'INSERT INTO coin_transactions (user_id, amount, type, description) VALUES (?, ?, "gift_sent", ?)',
                        [$fromUserId, $amount, "هدیه به $toUserId: $description"]
                    );
                    Database::execute(
                        'INSERT INTO coin_transactions (user_id, amount, type, description) VALUES (?, ?, "gift_received", ?)',
                        [$toUserId, $amount, "هدیه از $fromUserId: $description"]
                    );
                } catch (Throwable $e) {}

                Logger::info("Coin transfer: $fromUserId -> $toUserId: $amount", ['desc' => $description]);
                return true;
            });
        } catch (Throwable $e) {
            Logger::error("Coin transfer failed: " . $e->getMessage());
            return false;
        }
    }

    public static function formatBalance(int $balance): string
    {
        if ($balance >= 1000000) {
            return round($balance / 1000000, 1) . 'M';
        }
        if ($balance >= 1000) {
            return round($balance / 1000, 1) . 'K';
        }
        return (string) $balance;
    }

    public static function getShopItems(): array
    {
        return [
            ['id' => 'vip_monthly', 'name' => '⭐ اشتراک یک ماهه VIP', 'price' => 100, 'icon' => '💎'],
            ['id' => 'boost_profile', 'name' => '🚀 بوست پروفایل (۲۴ ساعت)', 'price' => 20, 'icon' => '🚀'],
            ['id' => 'super_like', 'name' => '💘 سوپر لایک (۵ عدد)', 'price' => 15, 'icon' => '💘'],
            ['id' => 'secret_extra', 'name' => '🕶 ۵ چت مخفیانه اضافه', 'price' => 10, 'icon' => '🕶'],
        ];
    }
}
